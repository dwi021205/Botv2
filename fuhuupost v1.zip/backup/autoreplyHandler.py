import selfcord
from selfcord.ext import commands
import asyncio
import json
import os
from datetime import datetime, timezone, timedelta
import logging
import weakref
import gc
import uuid
import random
from typing import Dict, Optional, Any, List

logger = logging.getLogger(__name__)

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

class AutoReplyHandler:
    def __init__(self, database_instance):
        self.db = database_instance
        self.active_clients = {}
        self.client_configs = {}
        self.message_queues = {}
        self.queue_workers = {}
        self._shutdown_event = asyncio.Event()
        
    def get_autoreply_config_path(self, user_id: str, account_id: str) -> str:
        autoreply_folder = os.path.join(self.db.data_folder, 'autoreply')
        os.makedirs(autoreply_folder, exist_ok=True)
        return os.path.join(autoreply_folder, f"{user_id}_{account_id}.json")
        
    def get_dm_history_folder(self, user_id: str) -> str:
        user_folder = self.db.get_user_data_folder(user_id)
        dm_history_folder = os.path.join(user_folder, 'dm_history')
        os.makedirs(dm_history_folder, exist_ok=True)
        return dm_history_folder
        
    def get_dm_history_path(self, user_id: str, account_id: str) -> str:
        dm_history_folder = self.get_dm_history_folder(user_id)
        return os.path.join(dm_history_folder, f"{account_id}.json")
        
    def get_queue_path(self, user_id: str, account_id: str) -> str:
        dm_history_folder = self.get_dm_history_folder(user_id)
        return os.path.join(dm_history_folder, f"{account_id}_queue.json")
        
    def load_autoreply_config(self, user_id: str, account_id: str) -> Dict[str, Any]:
        config_path = self.get_autoreply_config_path(user_id, account_id)
        
        default_config = {
            "status": "offline",
            "presenceStatus": "online",
            "replyText": "📩 Auto-reply: Hai! Terima kasih atas pesanmu. Saya akan membalas segera.",
            "createdAt": get_wib_time().isoformat(),
            "lastStarted": None,
            "lastStopped": None
        }
        
        try:
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    return config
            else:
                return default_config
        except Exception as e:
            logger.error(f"Error loading autoreply config: {e}")
            return default_config
            
    def save_autoreply_config(self, user_id: str, account_id: str, config: Dict[str, Any]) -> bool:
        try:
            config_path = self.get_autoreply_config_path(user_id, account_id)
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Error saving autoreply config: {e}")
            return False
            
    def load_dm_history(self, user_id: str, account_id: str) -> Dict[str, Any]:
        dm_history_path = self.get_dm_history_path(user_id, account_id)
        
        default_history = {
            "repliedChannels": {},
            "lastCleanup": get_wib_time().isoformat()
        }
        
        try:
            if os.path.exists(dm_history_path):
                with open(dm_history_path, 'r', encoding='utf-8') as f:
                    history = json.load(f)
                    
                    if "repliedChannels" not in history:
                        if "repliedUsers" in history:
                            history["repliedChannels"] = history["repliedUsers"]
                            del history["repliedUsers"]
                        else:
                            history["repliedChannels"] = {}
                    elif not isinstance(history["repliedChannels"], dict):
                        history["repliedChannels"] = {}
                    
                    if "lastCleanup" not in history:
                        history["lastCleanup"] = get_wib_time().isoformat()
                    
                    return history
            else:
                return default_history
        except Exception as e:
            logger.error(f"Error loading DM history: {e}")
            return default_history
            
    def save_dm_history(self, user_id: str, account_id: str, history: Dict[str, Any]) -> bool:
        try:
            if not isinstance(history.get("repliedChannels"), dict):
                history["repliedChannels"] = {}
            
            dm_history_path = self.get_dm_history_path(user_id, account_id)
            with open(dm_history_path, 'w', encoding='utf-8') as f:
                json.dump(history, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Error saving DM history: {e}")
            return False
            
    def load_message_queue(self, user_id: str, account_id: str) -> List[Dict[str, Any]]:
        queue_path = self.get_queue_path(user_id, account_id)
        
        try:
            if os.path.exists(queue_path):
                with open(queue_path, 'r', encoding='utf-8') as f:
                    queue_data = json.load(f)
                    return queue_data.get("queue", [])
            else:
                return []
        except Exception as e:
            logger.error(f"Error loading message queue: {e}")
            return []
            
    def save_message_queue(self, user_id: str, account_id: str, queue: List[Dict[str, Any]]) -> bool:
        try:
            queue_path = self.get_queue_path(user_id, account_id)
            queue_data = {
                "queue": queue,
                "lastUpdated": get_wib_time().isoformat()
            }
            with open(queue_path, 'w', encoding='utf-8') as f:
                json.dump(queue_data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Error saving message queue: {e}")
            return False
            
    def add_to_queue(self, user_id: str, account_id: str, channel_id: str):
        try:
            client_key = f"{user_id}_{account_id}"
            
            if client_key not in self.message_queues:
                self.message_queues[client_key] = []
            
            queue_item = {
                "channel_id": channel_id,
                "timestamp": get_wib_time().isoformat(),
                "delay": random.uniform(2, 5)
            }
            
            existing_item = next((item for item in self.message_queues[client_key] if item["channel_id"] == channel_id), None)
            if not existing_item:
                self.message_queues[client_key].append(queue_item)
                self.save_message_queue(user_id, account_id, self.message_queues[client_key])
                
        except Exception as e:
            logger.error(f"Error adding to queue: {e}")
            
    def cleanup_old_dm_entries(self, user_id: str, account_id: str):
        try:
            dm_history = self.load_dm_history(user_id, account_id)
            current_time = get_wib_time()
            current_date = current_time.strftime('%Y-%m-%d')
            
            cleaned_channels = {}
            replied_channels = dm_history.get("repliedChannels", {})
            
            if isinstance(replied_channels, dict):
                for channel_id, reply_date in replied_channels.items():
                    if reply_date == current_date:
                        cleaned_channels[channel_id] = reply_date
            
            dm_history["repliedChannels"] = cleaned_channels
            dm_history["lastCleanup"] = current_time.isoformat()
            
            self.save_dm_history(user_id, account_id, dm_history)
            
        except Exception as e:
            logger.error(f"Error cleaning up DM entries: {e}")
            
    def has_replied_today(self, user_id: str, account_id: str, channel_id: str) -> bool:
        try:
            dm_history = self.load_dm_history(user_id, account_id)
            current_date = get_wib_time().strftime('%Y-%m-%d')
            
            replied_channels = dm_history.get("repliedChannels", {})
            if isinstance(replied_channels, dict):
                return replied_channels.get(channel_id) == current_date
            
            return False
        except Exception as e:
            logger.error(f"Error checking if replied today: {e}")
            return False
            
    def mark_channel_replied(self, user_id: str, account_id: str, channel_id: str):
        try:
            dm_history = self.load_dm_history(user_id, account_id)
            current_date = get_wib_time().strftime('%Y-%m-%d')
            
            if "repliedChannels" not in dm_history or not isinstance(dm_history["repliedChannels"], dict):
                dm_history["repliedChannels"] = {}
                
            dm_history["repliedChannels"][channel_id] = current_date
            
            self.save_dm_history(user_id, account_id, dm_history)
            
        except Exception as e:
            logger.error(f"Error marking channel as replied: {e}")
            
    def create_selfcord_client(self, token: str, presence_status: str = "online") -> commands.Bot:
        from selfcord.http import HTTPClient
        old_static_login = HTTPClient.static_login

        def mobile_static_login(self, token):
            self._user_agent = "Discord/153018; Samsung SM-G991B; Android 12; Scale/2.00"
            self._super_properties = {
                "os": "Android",
                "browser": "Discord Android",
                "device": "Samsung SM-G991B",
                "system_locale": "en-US",
                "browser_user_agent": self._user_agent,
                "browser_version": "153.0",
                "os_version": "12",
                "referrer": "",
                "referring_domain": "",
                "referrer_current": "",
                "referring_domain_current": "",
                "release_channel": "stable",
                "client_build_number": 153018,
                "client_event_source": None
            }
            return old_static_login(self, token)

        HTTPClient.static_login = mobile_static_login

        bot = commands.Bot(
            command_prefix=".",
            self_bot=True,
            help_command=None,
            chunk_guilds_at_startup=False,
            fetch_offline_members=False,
            members_cache_flags=selfcord.MemberCacheFlags.none(),
            cache=False
        )
        
        return bot
        
    async def start_queue_worker(self, user_id: str, account_id: str, bot: commands.Bot):
        client_key = f"{user_id}_{account_id}"
        
        async def queue_worker():
            while client_key in self.active_clients and not bot.is_closed():
                try:
                    if client_key in self.message_queues and self.message_queues[client_key]:
                        queue_item = self.message_queues[client_key].pop(0)
                        
                        channel_id = queue_item["channel_id"]
                        delay = queue_item["delay"]
                        
                        if not self.has_replied_today(user_id, account_id, channel_id):
                            try:
                                await asyncio.sleep(delay)
                                
                                if client_key in self.active_clients and not bot.is_closed():
                                    current_config = self.load_autoreply_config(user_id, account_id)
                                    reply_text = current_config.get("replyText", "📩 Auto-reply: Hai! Terima kasih atas pesanmu. Saya akan membalas segera.")
                                    
                                    channel = bot.get_channel(int(channel_id))
                                    if channel:
                                        async with channel.typing():
                                            await asyncio.sleep(random.uniform(1, 3))
                                            
                                        await channel.send(reply_text)
                                        self.mark_channel_replied(user_id, account_id, channel_id)
                                        
                                        logger.info(f"Auto reply sent to channel {channel_id} from account {account_id} via queue")
                                        
                            except Exception as e:
                                logger.error(f"Error sending queued reply: {e}")
                        
                        self.save_message_queue(user_id, account_id, self.message_queues[client_key])
                        
                    await asyncio.sleep(0.5)
                    
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error in queue worker: {e}")
                    await asyncio.sleep(1)
        
        self.queue_workers[client_key] = asyncio.create_task(queue_worker())
        
    async def check_and_process_pending_dms(self, user_id: str, account_id: str, bot: commands.Bot):
        try:
            dm_history = self.load_dm_history(user_id, account_id)
            current_date = get_wib_time().strftime('%Y-%m-%d')
            replied_channels = dm_history.get("repliedChannels", {})
            
            pending_channels = []
            
            for channel in bot.private_channels:
                if isinstance(channel, selfcord.DMChannel):
                    channel_id = str(channel.id)
                    
                    if channel_id not in replied_channels or replied_channels[channel_id] != current_date:
                        try:
                            async for message in channel.history(limit=1):
                                if message.author.id != bot.user.id:
                                    message_date = message.created_at.strftime('%Y-%m-%d')
                                    if message_date == current_date:
                                        pending_channels.append(channel_id)
                                break
                        except:
                            continue
            
            for channel_id in pending_channels:
                self.add_to_queue(user_id, account_id, channel_id)
                
            logger.info(f"Found {len(pending_channels)} pending DMs for account {account_id}")
            
        except Exception as e:
            logger.error(f"Error checking pending DMs: {e}")
        
    async def start_autoreply_client(self, user_id: str, account_id: str, token: str) -> bool:
        try:
            client_key = f"{user_id}_{account_id}"
            
            if client_key in self.active_clients:
                await self.stop_autoreply_client(user_id, account_id)
                
            config = self.load_autoreply_config(user_id, account_id)
            
            bot = self.create_selfcord_client(token, config.get("presenceStatus", "online"))
            
            self.message_queues[client_key] = self.load_message_queue(user_id, account_id)
            
            @bot.event
            async def on_ready():
                logger.info(f"Auto reply client ready for {account_id}: {bot.user}")
                
                status_map = {
                    "online": selfcord.Status.online,
                    "idle": selfcord.Status.idle,
                    "dnd": selfcord.Status.dnd,
                    "off": selfcord.Status.invisible,
                    "invisible": selfcord.Status.invisible
                }
                
                target_status = status_map.get(config.get("presenceStatus", "online").lower(), selfcord.Status.online)
                await bot.change_presence(status=target_status)
                
                await asyncio.sleep(3)
                await self.check_and_process_pending_dms(user_id, account_id, bot)
                await self.start_queue_worker(user_id, account_id, bot)
                
            @bot.event
            async def on_message(message):
                if message.author.id == bot.user.id:
                    return
                    
                if isinstance(message.channel, selfcord.DMChannel):
                    channel_id = str(message.channel.id)
                    
                    if not self.has_replied_today(user_id, account_id, channel_id):
                        self.add_to_queue(user_id, account_id, channel_id)
                        
                await bot.process_commands(message)
                
            self.active_clients[client_key] = bot
            self.client_configs[client_key] = {
                "user_id": user_id,
                "account_id": account_id,
                "token": token
            }
            
            config["status"] = "online"
            config["lastStarted"] = get_wib_time().isoformat()
            self.save_autoreply_config(user_id, account_id, config)
            
            asyncio.create_task(self._run_client(bot, token, client_key))
            
            return True
            
        except Exception as e:
            logger.error(f"Error starting autoreply client: {e}")
            return False
            
    async def _run_client(self, bot: commands.Bot, token: str, client_key: str):
        try:
            await bot.start(token)
        except Exception as e:
            logger.error(f"Error running client {client_key}: {e}")
        finally:
            if client_key in self.active_clients:
                del self.active_clients[client_key]
            if client_key in self.client_configs:
                config_info = self.client_configs[client_key]
                del self.client_configs[client_key]
                
                config = self.load_autoreply_config(config_info["user_id"], config_info["account_id"])
                config["status"] = "offline"
                config["lastStopped"] = get_wib_time().isoformat()
                self.save_autoreply_config(config_info["user_id"], config_info["account_id"], config)
                
            if client_key in self.queue_workers:
                try:
                    self.queue_workers[client_key].cancel()
                except:
                    pass
                del self.queue_workers[client_key]
                
            if client_key in self.message_queues:
                if client_key in self.client_configs:
                    config_info = self.client_configs[client_key]
                    self.save_message_queue(config_info["user_id"], config_info["account_id"], self.message_queues[client_key])
                del self.message_queues[client_key]
                
    async def stop_autoreply_client(self, user_id: str, account_id: str) -> bool:
        try:
            client_key = f"{user_id}_{account_id}"
            
            if client_key in self.queue_workers:
                try:
                    self.queue_workers[client_key].cancel()
                except:
                    pass
                del self.queue_workers[client_key]
            
            if client_key in self.active_clients:
                bot = self.active_clients[client_key]
                
                try:
                    if not bot.is_closed():
                        await bot.close()
                except Exception as e:
                    logger.error(f"Error closing bot: {e}")
                    
                del self.active_clients[client_key]
                
            if client_key in self.client_configs:
                del self.client_configs[client_key]
                
            if client_key in self.message_queues:
                self.save_message_queue(user_id, account_id, self.message_queues[client_key])
                del self.message_queues[client_key]
                
            config = self.load_autoreply_config(user_id, account_id)
            config["status"] = "offline"
            config["lastStopped"] = get_wib_time().isoformat()
            self.save_autoreply_config(user_id, account_id, config)
            
            return True
            
        except Exception as e:
            logger.error(f"Error stopping autoreply client: {e}")
            return False
            
    def is_client_active(self, user_id: str, account_id: str) -> bool:
        client_key = f"{user_id}_{account_id}"
        
        if client_key not in self.active_clients:
            return False
            
        bot = self.active_clients[client_key]
        return not bot.is_closed()
        
    def update_reply_text(self, user_id: str, account_id: str, new_text: str) -> bool:
        try:
            config = self.load_autoreply_config(user_id, account_id)
            config["replyText"] = new_text
            return self.save_autoreply_config(user_id, account_id, config)
        except Exception as e:
            logger.error(f"Error updating reply text: {e}")
            return False
            
    def update_presence_status(self, user_id: str, account_id: str, presence: str) -> bool:
        try:
            config = self.load_autoreply_config(user_id, account_id)
            config["presenceStatus"] = presence
            
            result = self.save_autoreply_config(user_id, account_id, config)
            
            client_key = f"{user_id}_{account_id}"
            if client_key in self.active_clients:
                bot = self.active_clients[client_key]
                
                status_map = {
                    "online": selfcord.Status.online,
                    "idle": selfcord.Status.idle,
                    "dnd": selfcord.Status.dnd,
                    "off": selfcord.Status.invisible,
                    "invisible": selfcord.Status.invisible
                }
                
                target_status = status_map.get(presence.lower(), selfcord.Status.online)
                
                async def update_presence():
                    try:
                        await bot.change_presence(status=target_status)
                    except Exception as e:
                        logger.error(f"Error updating presence: {e}")
                        
                asyncio.create_task(update_presence())
                
            return result
            
        except Exception as e:
            logger.error(f"Error updating presence status: {e}")
            return False
            
    def get_autoreply_stats(self, user_id: str, account_id: str) -> Dict[str, Any]:
        try:
            config = self.load_autoreply_config(user_id, account_id)
            dm_history = self.load_dm_history(user_id, account_id)
            
            is_active = self.is_client_active(user_id, account_id)
            
            today_replies = 0
            current_date = get_wib_time().strftime('%Y-%m-%d')
            
            replied_channels = dm_history.get("repliedChannels", {})
            
            if isinstance(replied_channels, dict):
                for reply_date in replied_channels.values():
                    if reply_date == current_date:
                        today_replies += 1
            
            total_users = len(replied_channels) if isinstance(replied_channels, dict) else 0
                    
            return {
                "isActive": is_active,
                "status": config.get("status", "offline"),
                "presenceStatus": config.get("presenceStatus", "online"),
                "replyText": config.get("replyText", ""),
                "todayReplies": today_replies,
                "totalUsers": total_users,
                "lastStarted": config.get("lastStarted"),
                "lastStopped": config.get("lastStopped")
            }
            
        except Exception as e:
            logger.error(f"Error getting autoreply stats: {e}")
            return {
                "isActive": False,
                "status": "offline",
                "presenceStatus": "online",
                "replyText": "",
                "todayReplies": 0,
                "totalUsers": 0,
                "lastStarted": None,
                "lastStopped": None
            }
            
    async def cleanup_all_clients(self):
        try:
            self._shutdown_event.set()
            
            cleanup_tasks = []
            for client_key in list(self.active_clients.keys()):
                config_info = self.client_configs.get(client_key)
                if config_info:
                    task = asyncio.create_task(
                        self.stop_autoreply_client(config_info["user_id"], config_info["account_id"])
                    )
                    cleanup_tasks.append(task)
                    
            if cleanup_tasks:
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*cleanup_tasks, return_exceptions=True),
                        timeout=10.0
                    )
                except asyncio.TimeoutError:
                    logger.warning("Some autoreply clients failed to stop within timeout")
                    
            self.active_clients.clear()
            self.client_configs.clear()
            self.message_queues.clear()
            self.queue_workers.clear()
            
            gc.collect()
            
        except Exception as e:
            logger.error(f"Error cleaning up autoreply clients: {e}")
            
    async def start_daily_cleanup_task(self):
        async def daily_cleanup():
            while not self._shutdown_event.is_set():
                try:
                    await asyncio.sleep(86400)
                    
                    if not self._shutdown_event.is_set():
                        users = self.db.load_users()
                        for user in users:
                            user_id = user["id"]
                            dm_history_folder = self.get_dm_history_folder(user_id)
                            
                            if os.path.exists(dm_history_folder):
                                for filename in os.listdir(dm_history_folder):
                                    if filename.endswith('.json') and not filename.endswith('_queue.json'):
                                        account_id = filename[:-5]
                                        self.cleanup_old_dm_entries(user_id, account_id)
                                        
                        logger.info("Daily DM history cleanup completed")
                        
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error in daily cleanup: {e}")
                    
        asyncio.create_task(daily_cleanup())
        
    def list_all_autoreply_accounts(self, user_id: str) -> list:
        try:
            accounts = self.db.get_accounts(user_id)
            autoreply_accounts = []
            
            for account in accounts:
                account_id = account["id"]
                config = self.load_autoreply_config(user_id, account_id)
                stats = self.get_autoreply_stats(user_id, account_id)
                
                autoreply_accounts.append({
                    "accountId": account_id,
                    "accountData": account,
                    "config": config,
                    "stats": stats
                })
                    
            return autoreply_accounts
            
        except Exception as e:
            logger.error(f"Error listing autoreply accounts: {e}")
            return []
            
    def delete_autoreply_data(self, user_id: str, account_id: str) -> bool:
        try:
            config_path = self.get_autoreply_config_path(user_id, account_id)
            dm_history_path = self.get_dm_history_path(user_id, account_id)
            queue_path = self.get_queue_path(user_id, account_id)
            
            if os.path.exists(config_path):
                os.remove(config_path)
                
            if os.path.exists(dm_history_path):
                os.remove(dm_history_path)
                
            if os.path.exists(queue_path):
                os.remove(queue_path)
                
            client_key = f"{user_id}_{account_id}"
            if client_key in self.active_clients:
                asyncio.create_task(self.stop_autoreply_client(user_id, account_id))
                
            return True
            
        except Exception as e:
            logger.error(f"Error deleting autoreply data: {e}")
            return False
            
    def delete_user_autoreply_data(self, user_id: str) -> bool:
        try:
            dm_history_folder = self.get_dm_history_folder(user_id)
            if os.path.exists(dm_history_folder):
                import shutil
                shutil.rmtree(dm_history_folder)
                
            autoreply_folder = os.path.join(self.db.data_folder, 'autoreply')
            if os.path.exists(autoreply_folder):
                for filename in os.listdir(autoreply_folder):
                    if filename.startswith(f"{user_id}_") and filename.endswith('.json'):
                        file_path = os.path.join(autoreply_folder, filename)
                        os.remove(file_path)
                        
            for client_key in list(self.active_clients.keys()):
                if client_key.startswith(f"{user_id}_"):
                    config_info = self.client_configs.get(client_key)
                    if config_info:
                        asyncio.create_task(self.stop_autoreply_client(user_id, config_info["account_id"]))
                        
            return True
            
        except Exception as e:
            logger.error(f"Error deleting user autoreply data: {e}")
            return False