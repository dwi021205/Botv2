import discord
from discord.ext import commands
import asyncio
import os
import sys
import logging
import signal
import gc
import warnings
import ssl
import mimetypes
from database import Database, clean_log_file
from config import config
from datetime import datetime, timezone, timedelta

try:
    from pythonping import ping
    import requests
    NETWORK_MODULES_AVAILABLE = True
    print("✅ Network modules (pythonping, requests) loaded successfully")
except ImportError as e:
    NETWORK_MODULES_AVAILABLE = False
    print(f"⚠️ Network modules not available: {e}")
    print("   Run: pip install pythonping requests")

warnings.filterwarnings("ignore", category=ResourceWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", message=".*SSL.*")

mimetypes.init()
mimetypes.add_type('image/jpeg', '.jpg')
mimetypes.add_type('image/jpeg', '.jpeg')
mimetypes.add_type('image/png', '.png')
mimetypes.add_type('image/gif', '.gif')
mimetypes.add_type('image/webp', '.webp')

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "Discord Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

if config.is_debug:
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('bot.log'),
            logging.StreamHandler()
        ]
    )
else:
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[logging.FileHandler('bot.log')]
    )

logger = logging.getLogger(__name__)

clean_log_file()

try:
    intents = discord.Intents.default()
    intents.guilds = True
    intents.messages = True
    intents.message_content = True
    intents.members = True
    intents.dm_messages = True
except AttributeError:
    intents = discord.Intents.all()

bot = commands.Bot(
    command_prefix='!',
    intents=intents,
    help_command=None,
    chunk_guilds_at_startup=False,
    member_cache_flags=discord.MemberCacheFlags.none() if hasattr(discord, 'MemberCacheFlags') else None,
    max_messages=1000
)

data_folder = os.path.join(os.path.dirname(__file__), 'data')
os.makedirs(data_folder, exist_ok=True)

database_instance = Database(data_folder)

import database
database.db = database_instance

global global_db
global_db = database_instance

shutdown_initiated = False

async def load_extensions():
    commands_folder = os.path.join(os.path.dirname(__file__), 'commands')
    if os.path.exists(commands_folder):
        python_commands = [
            'backup', 'bdownload', 'ccode', 'redeem', 
            'checkid', 'setwebhook', 'stats', 'stop', 'copychannel', 'autoreply', 'listchannel'
        ]
        
        for filename in os.listdir(commands_folder):
            if filename.endswith('.py') and not filename.startswith('__'):
                command_name = filename[:-3]
                try:
                    extension_name = f'commands.{command_name}'
                    if extension_name in bot.extensions:
                        await bot.unload_extension(extension_name)
                        if config.is_debug:
                            logger.info(f'Unloaded existing extension: {command_name}')
                    
                    await bot.load_extension(extension_name)
                    if config.is_debug:
                        logger.info(f'Loaded extension: {command_name}')
                except Exception as e:
                    logger.error(f'Failed to load extension {command_name}: {e}', exc_info=True)
        
        loaded_python_commands = []
        for cmd in python_commands:
            if f'commands.{cmd}' in bot.extensions:
                loaded_python_commands.append(cmd)
        
        if config.is_debug:
            logger.info(f'Python commands loaded: {loaded_python_commands}')
            logger.info(f'Total extensions loaded: {len(bot.extensions)}')

@bot.event
async def on_ready():
    if config.is_debug:
        print(f'✅ Ready! Logged in as {bot.user}')
        print(f'🔗 GitHub Backup: {config.github.get("owner", "N/A")}/{config.github.get("repo", "N/A")}')
        print(f'🐛 Debug Mode: {config.is_debug}')
        print(f'🛡️ Enhanced Rate Limiting: Active')
        print(f'⚡ Session Pooling: Enabled')
        print(f'🧹 Auto Log Cleaning: Enabled')
        print(f'🤖 AutoReply System: Initialized')
        print(f'🌐 Network Monitoring: {"Enabled" if NETWORK_MODULES_AVAILABLE else "Disabled (missing pythonping/requests)"}')

    try:
        await bot.change_presence(
            status=discord.Status.online,
            activity=discord.Activity(
                type=discord.ActivityType.playing,
                name='FuHuu AutoPost'
            )
        )
    except Exception as e:
        logger.error(f'Error setting presence: {e}')

    try:
        synced = await bot.tree.sync()
        if config.is_debug:
            logger.info(f'Synced {len(synced)} command(s)')
    except Exception as e:
        logger.error(f'Failed to sync commands: {e}')

    await database_instance.init(bot)

    await asyncio.sleep(5)
    try:
        await database_instance.init_bot_monitoring()
        if config.is_debug:
            logger.info('✅ Bot monitoring system initialized with network testing and AutoReply')
    except Exception as e:
        logger.error(f'❌ Failed to initialize bot monitoring: {e}')

@bot.event
async def on_error(event, *args, **kwargs):
    logger.error(f'Error in event {event}: {args}', exc_info=True)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    logger.error(f'Command error in {ctx.command}: {error}', exc_info=True)

@bot.event
async def on_application_command_error(interaction, error):
    logger.error(f'Application command error: {error}', exc_info=True)
    
    error_message = '❌ Terjadi kesalahan saat menjalankan perintah ini!'
    try:
        if interaction.response.is_done():
            await interaction.followup.send(error_message, ephemeral=True)
        else:
            await interaction.response.send_message(error_message, ephemeral=True)
    except:
        pass

@bot.event 
async def on_interaction(interaction):
    if interaction.type == discord.InteractionType.application_command:
        command_name = interaction.data.get('name')
        user_id = str(interaction.user.id)
        
        public_commands = ["buy", "redeem"]
        
        if command_name not in public_commands and user_id != config.owner_id:
            if not global_db.has_active_subscription(user_id):
                embed_data = {
                    "title": "⚠️ Langganan Diperlukan",
                    "description": "Anda tidak memiliki langganan aktif. Gunakan `/buy` untuk membeli langganan.",
                    "color": 0xFFAA00
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                
                try:
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
                except:
                    pass
        
        owner_only_commands = ["backup", "backdown", "ccode", "stop"]
        if command_name in owner_only_commands and user_id != config.owner_id:
            try:
                await interaction.response.send_message("⛔ Perintah ini dibatasi hanya untuk pemilik bot.", ephemeral=True)
                return
            except:
                pass

async def shutdown_handler():
    global shutdown_initiated

    if shutdown_initiated:
        return

    shutdown_initiated = True

    if config.is_debug:
        print('🛑 Shutting down system...')

    try:
        if database_instance:
            await database_instance.force_stop_all_services(hard_stop=True)
            
            try:
                await asyncio.wait_for(
                    database_instance.cleanup_all_resources(), 
                    timeout=10.0
                )
            except asyncio.TimeoutError:
                logger.warning("Database cleanup timed out")

        if bot and not bot.is_closed():
            try:
                await asyncio.wait_for(bot.close(), timeout=5.0)
            except asyncio.TimeoutError:
                logger.warning("Bot close timed out")

        pending_tasks = [task for task in asyncio.all_tasks() if not task.done()]
        if pending_tasks:
            for task in pending_tasks:
                if not task.cancelled():
                    task.cancel()
            
            try:
                await asyncio.wait_for(
                    asyncio.gather(*pending_tasks, return_exceptions=True),
                    timeout=5.0
                )
            except asyncio.TimeoutError:
                logger.warning("Some tasks failed to complete during shutdown")

        clean_log_file()
        
        gc.collect()
        
        if config.is_debug:
            print('✅ Shutdown completed')
            
    except Exception as e:
        logger.error(f'Error during shutdown: {e}')

def signal_handler(signum, frame):
    loop = asyncio.get_event_loop()
    if loop.is_running():
        loop.create_task(shutdown_handler())
    else:
        asyncio.run(shutdown_handler())

def exception_handler(loop, context):
    exception = context.get('exception')
    if exception:
        if any(err in str(exception) for err in [
            'Unclosed connector', 
            'Fatal error on SSL transport', 
            'SSL handshake', 
            'SSL error',
            'Connection reset by peer',
            'Broken pipe'
        ]):
            if config.is_debug:
                logger.debug(f'Suppressed connection warning: {exception}')
        else:
            logger.error(f'Async exception: {context}')
    else:
        logger.error(f'Async exception: {context}')

async def main():
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    
    loop = asyncio.get_event_loop()
    
    loop.set_exception_handler(exception_handler)

    for sig in [signal.SIGINT, signal.SIGTERM]:
        try:
            loop.add_signal_handler(sig, lambda s=sig: asyncio.create_task(shutdown_handler()))
        except NotImplementedError:
            signal.signal(sig, signal_handler)
    
    autoreply_folder = os.path.join(os.path.dirname(__file__), 'autoreply')
    os.makedirs(autoreply_folder, exist_ok=True)
    
    handler_path = os.path.join(autoreply_folder, 'autoreplyHandler.py')
    init_path = os.path.join(autoreply_folder, '__init__.py')
    
    if not os.path.exists(handler_path):
        print("⚠️ autoreplyHandler.py not found in autoreply folder")
        print(f"   Expected location: {handler_path}")
        print("   Please ensure autoreplyHandler.py is in the autoreply/ folder")
    elif not os.path.exists(init_path):
        print("⚠️ __init__.py not found in autoreply folder")
        print(f"   Expected location: {init_path}")
        print("   Please ensure __init__.py is in the autoreply/ folder")
    else:
        if config.is_debug:
            print("✅ AutoReply handler files found")

    try:
        import selfcord
        print("✅ selfcord module available for AutoReply functionality")
    except ImportError:
        print("⚠️ selfcord module not found. AutoReply features may not work.")
        print("   Run: pip install selfcord")

    await load_extensions()

    try:
        if config.is_debug:
            print('🚀 Starting bot with enhanced features, network monitoring and AutoReply system...')
        
        await bot.start(config.token)
    except KeyboardInterrupt:
        await shutdown_handler()
    except discord.LoginFailure:
        logger.error('Invalid bot token provided')
        await shutdown_handler()
        sys.exit(1)
    except Exception as e:
        logger.error(f'Failed to start bot: {e}', exc_info=True)
        await shutdown_handler()
        sys.exit(1)

if __name__ == '__main__':
    try:
        if sys.platform == 'win32':
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        asyncio.run(main())
    except KeyboardInterrupt:
        if config.is_debug:
            print("Bot stopped by user.")
    except Exception as e:
        logger.error(f"Critical error: {e}", exc_info=True)
        sys.exit(1)