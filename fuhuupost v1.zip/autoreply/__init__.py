try:
    from .autoreplyHandler import AutoReplyHandler
    __all__ = ['AutoReplyHandler']
except ImportError as e:
    print(f"Warning: Could not import AutoReplyHandler: {e}")
    AutoReplyHandler = None
    __all__ = []