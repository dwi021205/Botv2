import selfcord
import asyncio
import json
import os
from datetime import datetime, timezone, timedelta
import logging
import uuid
import random
from typing import Dict, Any, List, Optional
from pathlib import Path
import shutil
import base64
import re

logger = logging.getLogger(__name__)
WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

class AutoReplyHandler:
    def __init__(self, database_instance):
        self.db = database_instance
        self.active_clients: Dict[str, Dict[str, Any]] = {}
        self.client_configs: Dict[str, Dict[str, Any]] = {}
        self.reply_counters: Dict[str, int] = {}
        self._shutdown_event = asyncio.Event()
        self.cleanup_task = None

    def get_autoreply_config_path(self, user_id: str, account_id: str) -> Path:
        autoreply_folder = Path(self.db.data_folder) / 'autoreply'
        autoreply_folder.mkdir(exist_ok=True)
        return autoreply_folder / f"{user_id}_{account_id}.json"

    def get_dm_history_folder(self, user_id: str) -> Path:
        user_folder = Path(self.db.get_user_data_folder(user_id))
        dm_history_folder = user_folder / 'dm_history'
        dm_history_folder.mkdir(exist_ok=True)
        return dm_history_folder

    def load_autoreply_config(self, user_id: str, account_id: str) -> Dict[str, Any]:
        config_path = self.get_autoreply_config_path(user_id, account_id)
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return {}
        return {"replyText": "Maaf, saya sedang offline.", "presenceStatus": "online"}

    def save_autoreply_config(self, user_id: str, account_id: str, data: Dict[str, Any]):
        config_path = self.get_autoreply_config_path(user_id, account_id)
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)
        except IOError as e:
            logger.error(f"Failed to save autoreply config for {user_id}_{account_id}: {e}")

    def update_reply_text(self, user_id: str, account_id: str, text: str) -> bool:
        config = self.load_autoreply_config(user_id, account_id)
        config['replyText'] = text
        self.save_autoreply_config(user_id, account_id, config)
        return True

    def update_presence_status(self, user_id: str, account_id: str, status: str) -> bool:
        config = self.load_autoreply_config(user_id, account_id)
        config['presenceStatus'] = status
        self.save_autoreply_config(user_id, account_id, config)
        return True

    def is_client_active(self, user_id: str, account_id: str) -> bool:
        client_key = f"{user_id}_{account_id}"
        client_info = self.active_clients.get(client_key)
        if not client_info:
            return False
        task = client_info.get("task")
        return task is not None and not task.done()

    def get_autoreply_stats(self, user_id: str, account_id: str) -> Dict[str, Any]:
        config = self.load_autoreply_config(user_id, account_id)
        return {
            "isActive": self.is_client_active(user_id, account_id),
            "replyText": config.get("replyText", ""),
            "presenceStatus": config.get("presenceStatus", "online"),
            "replyCount": self.reply_counters.get(f"{user_id}_{account_id}", 0)
        }

    async def start_autoreply_client(self, user_id: str, account_id: str, token: str):
        client_key = f"{user_id}_{account_id}"
        if self.is_client_active(user_id, account_id):
            return

        config = self.load_autoreply_config(user_id, account_id)
        autoreply_message = config.get("replyText", "Maaf, saya sedang tidak tersedia saat ini.")
        presence_status = config.get("presenceStatus", "online")

        self.client_configs[client_key] = {
            "user_id": user_id,
            "account_id": account_id,
            "token": token,
            "autoreply_message": autoreply_message,
            "presence_status": presence_status
        }
        self.reply_counters[client_key] = self.reply_counters.get(client_key, 0)
        
        dm_history_folder = self.get_dm_history_folder(user_id)

        client = selfcord.Client(
            max_messages=None,
            guild_subscriptions=False,
            fetch_offline_members=False,
            chunk_guilds_at_startup=False,
            member_cache_flags=selfcord.MemberCacheFlags.none()
        )
        
        @client.event
        async def on_ready():
            status_map = {
                "online": selfcord.Status.online,
                "idle": selfcord.Status.idle,
                "dnd": selfcord.Status.dnd,
                "invisible": selfcord.Status.invisible
            }
            await client.change_presence(status=status_map.get(presence_status, selfcord.Status.online))
            logger.info(f"Auto-reply client ready for {client_key}")

        @client.event
        async def on_message(message):
            if isinstance(message.channel, selfcord.DMChannel) and message.author.id != client.user.id and message.content:
                dm_history_file = dm_history_folder / f"{message.author.id}.json"
                if not dm_history_file.exists():
                    try:
                        logger.info(f"Menerima DM dari '{message.author}' ({message.author.id}): {message.content}")
                        
                        async with message.channel.typing():
                            typing_duration = random.uniform(2, 3)
                            await asyncio.sleep(typing_duration)
                        
                        await message.reply(autoreply_message)
                        logger.info(f"Berhasil membalas ke '{message.author}' ({message.author.id}) dari {client_key}")
                        
                        self.reply_counters[client_key] = self.reply_counters.get(client_key, 0) + 1

                        with open(dm_history_file, 'w', encoding='utf-8') as f:
                            json.dump({"timestamp": get_wib_time().isoformat()}, f)

                        if self.reply_counters.get(client_key, 0) % 5 == 0:
                            await asyncio.sleep(random.uniform(5, 15))

                    except selfcord.errors.Forbidden:
                        logger.error(f"Tidak dapat mengirim pesan ke {message.author} ({message.author.id}). Mungkin DM diblokir atau ada masalah pertemanan.")
                    except Exception as e:
                        logger.error(f"Auto-reply failed for {client_key} to {message.author.id}: {e}")

        async def run_client():
            try:
                await client.start(token)
            except Exception as e:
                logger.error(f"Self-bot client failed for {client_key}: {e}")
                if client_key in self.active_clients:
                    del self.active_clients[client_key]

        task = asyncio.create_task(run_client())
        self.active_clients[client_key] = {"task": task, "client": client}

    async def stop_autoreply_client(self, user_id: str, account_id: str):
        client_key = f"{user_id}_{account_id}"
        client_info = self.active_clients.pop(client_key, None)

        if client_info:
            client = client_info.get("client")
            task = client_info.get("task")

            if client and not client.is_closed():
                try:
                    await client.close()
                    logger.info(f"Successfully closed client for {client_key}")
                except Exception as e:
                    logger.error(f"Error closing client for {client_key}: {e}")

            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass 

        if client_key in self.client_configs:
            del self.client_configs[client_key]

    async def daily_cleanup_task(self):
        while not self._shutdown_event.is_set():
            await asyncio.sleep(24 * 60 * 60)
            if self._shutdown_event.is_set():
                break
            
            logger.info("Starting daily DM history cleanup...")
            try:
                users_folder = Path(self.db.users_folder)
                if not users_folder.exists():
                    continue
                
                for user_dir in users_folder.iterdir():
                    if user_dir.is_dir():
                        dm_history_folder = user_dir / 'dm_history'
                        if dm_history_folder.exists():
                            shutil.rmtree(dm_history_folder)
                            dm_history_folder.mkdir(exist_ok=True) 
                logger.info("Daily DM history cleanup finished.")
            except Exception as e:
                logger.error(f"Error during daily DM history cleanup: {e}")

    async def start_daily_cleanup_task(self):
        if self.cleanup_task is None or self.cleanup_task.done():
            self.cleanup_task = asyncio.create_task(self.daily_cleanup_task())

    async def cleanup_all_clients(self):
        self._shutdown_event.set()
        if self.cleanup_task and not self.cleanup_task.done():
            self.cleanup_task.cancel()

        for key in list(self.active_clients.keys()):
            user_id, account_id = key.split('_', 1)
            await self.stop_autoreply_client(user_id, account_id)

    def delete_autoreply_data(self, user_id: str, account_id: str) -> bool:
        try:
            config_path = self.get_autoreply_config_path(user_id, account_id)
            if config_path.exists():
                config_path.unlink()
            
            asyncio.create_task(self.stop_autoreply_client(user_id, account_id))
            return True
        except Exception as e:
            logger.error(f"Error deleting autoreply data for {user_id}_{account_id}: {e}")
            return False
            
    def delete_user_autoreply_data(self, user_id: str) -> bool:
        try:
            dm_history_folder = self.get_dm_history_folder(user_id)
            if dm_history_folder.exists():
                shutil.rmtree(dm_history_folder)
                
            autoreply_folder = Path(self.db.data_folder) / 'autoreply'
            if autoreply_folder.exists():
                for f in autoreply_folder.glob(f"{user_id}_*.json"):
                    f.unlink()
                            
            for client_key in list(self.active_clients.keys()):
                if client_key.startswith(f"{user_id}_"):
                    u_id, acc_id = client_key.split('_', 1)
                    asyncio.create_task(self.stop_autoreply_client(u_id, acc_id))
            return True
        except Exception as e:
            logger.error(f"Error deleting all autoreply data for user {user_id}: {e}")
            return False
