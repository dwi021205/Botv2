import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import re
from datetime import datetime
from typing import Dict, Any, List, Optional
from config import config
from database import enhance_embed

class DeleteUserCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db

    @app_commands.command(name="delete_user", description="Hapus pengguna dan semua data mereka")
    async def delete_user(self, interaction: discord.Interaction):
        if str(interaction.user.id) != config.owner_id:
            await interaction.response.send_message(
                "⛔ Perintah ini dibatasi hanya untuk pemilik bot.", 
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        
        try:
            embed, view = await self.generate_delete_user_page(0)
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

    def smart_search(self, users: List[Dict], query: str) -> List[Dict]:
        if not query or query.strip() == '':
            return users
        
        search_query = query.lower().strip()
        search_words = search_query.split()
        
        filtered_users = []
        for user in users:
            username = user['username'].lower()
            
            if username == search_query:
                filtered_users.append((user, 100))
                continue
            
            if search_query in username:
                filtered_users.append((user, 90))
                continue
                
            username_words = re.split(r'[-_\s]+', username)
            match_count = sum(1 for word in search_words 
                            if any(word in user_word for user_word in username_words))
            
            if match_count > 0:
                score = match_count * 10
                if username.startswith(search_query):
                    score += 50
                filtered_users.append((user, score))
        
        filtered_users.sort(key=lambda x: x[1], reverse=True)
        return [user for user, score in filtered_users]

    async def generate_delete_user_page(self, page: int = 0, search_query: str = '') -> tuple:
        all_users = self.db.load_users()
        
        if len(all_users) == 0:
            embed_data = {
                "title": "⚠️ No Users Found",
                "description": "Tidak ada pengguna yang terdaftar.",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            return embed, None
        
        users_to_show = [user for user in all_users if user['id'] != config.owner_id]
        
        if search_query:
            users_to_show = self.smart_search(users_to_show, search_query)
        
        if len(users_to_show) == 0:
            embed_data = {
                "title": "⚠️ No Users Found",
                "description": search_query and f'Tidak ditemukan pengguna dengan username "{search_query}". Gunakan tombol pencarian untuk mencoba lagi.' or 'Tidak ada pengguna yang dapat dihapus (Anda tidak dapat menghapus akun pemilik).',
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            view = DeleteUserView(self, page, search_query, [], 1, show_search_only=True)
            return embed, view
        
        users_per_page = 20
        page_count = (len(users_to_show) + users_per_page - 1) // users_per_page
        
        page = max(0, min(page, page_count - 1))
        
        start_index = page * users_per_page
        end_index = min(start_index + users_per_page, len(users_to_show))
        users_on_page = users_to_show[start_index:end_index]
        
        embed_data = {
            "title": "🗑️ Delete User",
            "description": "Semua data untuk pengguna yang dipilih akan dihapus secara permanen, termasuk akun, saluran, dan konfigurasi.",
            "color": 0xFF0000,
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        
        if search_query:
            embed_data["fields"] = [{
                "name": "🔍 Hasil Pencarian",
                "value": f'Menampilkan {len(users_to_show)} hasil untuk "{search_query}"',
                "inline": False
            }]
        
        if page_count > 1:
            embed_data["footer"]["text"] = f"Halaman {page + 1} dari {page_count} • FuHuu Auto Post"
        
        embed = discord.Embed.from_dict(enhance_embed(embed_data))
        view = DeleteUserView(self, page, search_query, users_on_page, page_count)
        return embed, view

    async def show_delete_confirmation(self, interaction: discord.Interaction, user_id: str):
        user = self.db.get_user_by_id(user_id)
        
        if not user:
            await interaction.response.send_message('Pengguna tidak ditemukan. Pengguna mungkin telah dihapus.', ephemeral=True)
            return
        
        if user_id == config.owner_id:
            embed_data = {
                "title": "❌ Cannot Delete Owner",
                "description": "Anda tidak dapat menghapus akun pemilik.",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.response.edit_message(embed=embed, view=None)
            return
        
        modal = DeleteUserModal(self, user_id, user)
        await interaction.response.send_modal(modal)

class DeleteUserView(discord.ui.View):
    def __init__(self, command_instance, page: int, search_query: str, users_on_page: List[Dict], page_count: int, show_search_only: bool = False):
        super().__init__(timeout=300)
        self.command = command_instance
        self.page = page
        self.search_query = search_query
        self.page_count = page_count
        
        if not show_search_only and users_on_page:
            user_options = []
            for user in users_on_page:
                is_active = self.command.db.has_active_subscription(user['id'])
                
                option = discord.SelectOption(
                    label=user['username'][:100],
                    description=f"ID: {user['id']} | Tipe: {user['subscriptionType']} | {'Aktif' if is_active else 'Tidak Aktif'}"[:100],
                    value=user['id'],
                    emoji="✅" if is_active else "❌"
                )
                user_options.append(option)
            
            if user_options:
                select = discord.ui.Select(placeholder="Pilih pengguna untuk dihapus", options=user_options)
                select.callback = self.select_callback
                self.add_item(select)
        
        self.add_item(SearchButton())
        
        if page_count > 1:
            if page > 0:
                self.add_item(PrevPageButton())
            if page < page_count - 1:
                self.add_item(NextPageButton())
    
    async def select_callback(self, interaction: discord.Interaction):
        try:
            user_id = interaction.data['values'][0]
            await self.command.show_delete_confirmation(interaction, user_id)
        except Exception as e:
            await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)

class SearchButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="🔍 Cari Pengguna", style=discord.ButtonStyle.primary)
    
    async def callback(self, interaction: discord.Interaction):
        modal = SearchModal(self.view.command)
        await interaction.response.send_modal(modal)

class PrevPageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="⬅️ Sebelumnya", style=discord.ButtonStyle.secondary)
    
    async def callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            view = self.view
            new_page = view.page - 1
            embed, new_view = await view.command.generate_delete_user_page(new_page, view.search_query)
            await interaction.edit_original_response(embed=embed, view=new_view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class NextPageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="➡️ Selanjutnya", style=discord.ButtonStyle.secondary)
    
    async def callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            view = self.view
            new_page = view.page + 1
            embed, new_view = await view.command.generate_delete_user_page(new_page, view.search_query)
            await interaction.edit_original_response(embed=embed, view=new_view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class SearchModal(discord.ui.Modal):
    def __init__(self, command_instance):
        super().__init__(title="Cari Pengguna")
        self.command = command_instance
        
        self.search_query = discord.ui.TextInput(
            label="Username Pengguna",
            style=discord.TextStyle.short,
            placeholder="Masukkan username yang ingin dicari",
            required=True
        )
        self.add_item(self.search_query)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            
            search_query = self.search_query.value
            embed, view = await self.command.generate_delete_user_page(0, search_query)
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class DeleteUserModal(discord.ui.Modal):
    def __init__(self, command_instance, user_id: str, user: Dict[str, Any]):
        super().__init__(title=f"Hapus Pengguna: {user['username'][:45]}")
        self.command = command_instance
        self.user_id = user_id
        self.user = user
        
        self.confirmation = discord.ui.TextInput(
            label='Ketik "confirm" untuk hapus',
            style=discord.TextStyle.short,
            required=True,
            placeholder="confirm"
        )
        self.add_item(self.confirmation)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            user = self.command.db.get_user_by_id(self.user_id)
            if not user:
                await interaction.response.send_message('Pengguna tidak ditemukan. Pengguna mungkin sudah dihapus.', ephemeral=True)
                return
            
            confirmation = self.confirmation.value
            if confirmation != 'confirm':
                embed_data = {
                    "title": "❌ Deletion Cancelled",
                    "description": 'Anda harus mengetik "confirm" untuk melanjutkan penghapusan.',
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.response.edit_message(embed=embed, view=None)
                return
            
            await interaction.response.defer()
            
            processing_embed_data = {
                "title": "⏳ Deletion In Progress",
                "description": f"Mulai menghapus **{user['username']}** dan semua data mereka...",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            processing_embed = discord.Embed.from_dict(enhance_embed(processing_embed_data))
            await interaction.edit_original_response(embed=processing_embed, view=None)
            
            account_count = self.command.db.get_account_count_for_user(self.user_id)
            
            await self.command.db.stop_all_services_for_user(self.user_id)
            
            try:
                discord_user = await self.command.bot.fetch_user(int(self.user_id))
                notification_embed_data = {
                    "title": "❌ Subscription Terminated",
                    "description": f"Langganan Anda untuk **{self.command.bot.user.name}** telah dihentikan.",
                    "color": 0xFF5555,
                    "timestamp": datetime.now().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                notification_embed = discord.Embed.from_dict(enhance_embed(notification_embed_data))
                try:
                    await discord_user.send(embed=notification_embed)
                except:
                    pass
            except Exception:
                pass
            
            await asyncio.sleep(3)
            
            success = self.command.db.delete_user(self.user_id)
            
            if success:
                success_embed_data = {
                    "title": "✅ User Successfully Deleted",
                    "description": f"Pengguna **{user['username']}** dan semua data mereka telah dihapus.",
                    "fields": [
                        {"name": "🆔 ID Pengguna", "value": self.user_id, "inline": True},
                        {"name": "📊 Akun Dihapus", "value": str(account_count), "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": datetime.now().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                success_embed = discord.Embed.from_dict(enhance_embed(success_embed_data))
                await interaction.edit_original_response(embed=success_embed, view=None)
            else:
                failure_embed_data = {
                    "title": "❌ Deletion Failed",
                    "description": "Sistem mengalami kesalahan saat menghapus data pengguna.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                failure_embed = discord.Embed.from_dict(enhance_embed(failure_embed_data))
                await interaction.edit_original_response(embed=failure_embed, view=None)
        except Exception as e:
            error_embed_data = {
                "title": "❌ Error During Deletion",
                "description": f"Sistem mengalami kesalahan: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
            if interaction.response.is_done():
                await interaction.edit_original_response(embed=error_embed, view=None)
            else:
                await interaction.response.edit_message(embed=error_embed, view=None)

async def setup(bot):
    await bot.add_cog(DeleteUserCommand(bot))