import discord
from discord.ext import commands
import aiohttp
import database
from datetime import datetime, timezone, timedelta
from config import config

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

async def validate_token(token):
    headers = {
        'Authorization': token,
        'User-Agent': 'Discord-Android/126021;RNA'
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get('https://discord.com/api/v10/users/@me', headers=headers) as response:
                if response.status == 200:
                    return {"valid": True, "user": await response.json()}
                else:
                    return {"valid": False, "error": await response.text()}
    except Exception as e:
        return {"valid": False, "error": str(e)}

class StatsView(discord.ui.View):
    def __init__(self, accounts, user_id, page=0):
        super().__init__(timeout=300)
        self.accounts = accounts
        self.user_id = user_id
        self.page = page
        self.accounts_per_page = 3
        self.page_count = (len(accounts) + self.accounts_per_page - 1) // self.accounts_per_page
        
        if self.page > 0:
            prev_button = discord.ui.Button(
                label="Sebelumnya",
                style=discord.ButtonStyle.primary,
                emoji="◀️",
                custom_id=f"prev_{page}"
            )
            prev_button.callback = self.prev_page
            self.add_item(prev_button)
        
        if self.page < self.page_count - 1:
            next_button = discord.ui.Button(
                label="Selanjutnya", 
                style=discord.ButtonStyle.primary,
                emoji="▶️",
                custom_id=f"next_{page}"
            )
            next_button.callback = self.next_page
            self.add_item(next_button)

    async def prev_page(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
            return

        new_page = max(0, self.page - 1)
        embed, view = await self.generate_stats_embed(new_page)
        await interaction.response.edit_message(embeds=[embed], view=view)

    async def next_page(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
            return

        new_page = min(self.page_count - 1, self.page + 1)
        embed, view = await self.generate_stats_embed(new_page)
        await interaction.response.edit_message(embeds=[embed], view=view)

    async def generate_stats_embed(self, page=0):
        if not self.accounts:
            embed_data = {
                "title": "📊 Account Status List",
                "description": "Lihat status akun yang telah Anda konfigurasi",
                "fields": [
                    {"name": "⚠️ No Accounts", "value": "Tidak ada akun yang terdaftar.", "inline": False}
                ],
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            return discord.Embed.from_dict(embed_data), None

        start_index = page * self.accounts_per_page
        end_index = min(start_index + self.accounts_per_page, len(self.accounts))
        accounts_on_page = self.accounts[start_index:end_index]

        embed_data = {
            "title": "📊 Account Status List",
            "description": "Lihat status akun yang telah Anda konfigurasi",
            "color": 0x00FFFF,
            "timestamp": get_wib_time().isoformat(),
            "footer": {
                "text": f"Halaman {page + 1} dari {self.page_count} • FuHuu Auto Post",
                "icon_url": config.images.get("footerIcon")
            },
            "fields": []
        }

        for account in accounts_on_page:
            validation = await validate_token(account['token'])
            
            total_channels = len(account.get('channels', []))
            active_channels = len([ch for ch in account.get('channels', []) if ch.get('status') == 'online'])
            inactive_channels = total_channels - active_channels
            
            auto_reply_status = "Aktif" if account.get('autoReply', {}).get('enabled') else "Tidak Aktif"
            token_status = "Valid" if validation['valid'] else "Tidak Valid"
            
            user_id_display = "Tidak Diketahui"
            if validation['valid']:
                user_id_display = validation['user'].get('id', 'Tidak Diketahui')

            field_value = (
                f"🆔 User ID: {user_id_display}\n"
                f"✅ Token Status: {token_status}\n"
                f"📊 Configured Channels: {total_channels}\n"
                f"🟢 Active Channels: {active_channels}\n"
                f"🔴 Inactive Channels: {inactive_channels}\n"
                f"💬 Auto Reply: {auto_reply_status}"
            )
            
            embed_data["fields"].append({
                "name": f"{account.get('username', 'Unknown')} - {account.get('name', 'Tidak Diketahui')}",
                "value": field_value,
                "inline": False
            })

        if config.images.get("globalEmbed"):
            embed_data["image"] = {"url": config.images["globalEmbed"]}

        embed = discord.Embed.from_dict(embed_data)
        
        new_view = StatsView(self.accounts, self.user_id, page) if self.page_count > 1 else None
        return embed, new_view

class StatsCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="stats", description="Tampilkan status akun selfbot")
    async def stats(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        if not database.db.has_active_subscription(user_id):
            await interaction.response.send_message("⚠️ Anda tidak memiliki langganan aktif. Gunakan `/buy` untuk membeli langganan.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        accounts = database.db.get_accounts(user_id)
        
        view = StatsView(accounts, interaction.user.id)
        embed, _ = await view.generate_stats_embed()
        
        if len(accounts) > 3:
            await interaction.followup.send(embeds=[embed], view=view)
        else:
            await interaction.followup.send(embeds=[embed])

async def setup(bot):
    await bot.add_cog(StatsCommand(bot))