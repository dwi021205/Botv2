import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta
from typing import Dict, Any
from config import config
from database import enhance_embed

async def assign_role_for_user(guild: discord.Guild, user_id: str, plan_type: str) -> bool:
    try:
        if not guild:
            return False
        
        member = await guild.fetch_member(int(user_id))
        if not member:
            return False
        
        global_role_id = 1301011003554926672
        perma_role_id = 1327543532206035076
        trial_role_id = 1327543942190862336
        
        role_mapping = {
            'trial_limited': trial_role_id,
            'trial_unlimited': trial_role_id,
            'perma_limited': perma_role_id,
            'perma_unlimited': perma_role_id
        }
        
        global_role = guild.get_role(global_role_id)
        if global_role and global_role not in member.roles:
            await member.add_roles(global_role)
        
        specific_role_id = role_mapping.get(plan_type)
        if not specific_role_id:
            return False
        
        specific_role = guild.get_role(specific_role_id)
        if not specific_role:
            return False
        
        await member.add_roles(specific_role)
        return True
    except Exception as e:
        if config.is_debug:
            print(f'Error assigning role: {e}')
        return False

class AddUserCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db

    @app_commands.command(name="add_user", description="Tambahkan pengguna baru ke sistem langganan")
    @app_commands.describe(
        user="Pengguna Discord yang akan ditambahkan",
        subscription_type="Tipe langganan",
        limit="Batas akun (hanya untuk paket limited)"
    )
    async def add_user(self, interaction: discord.Interaction, user: discord.User, 
                      subscription_type: str, limit: int = None):
        try:
            if str(interaction.user.id) != config.owner_id:
                await interaction.response.send_message(
                    "❌ Access Denied. Perintah ini dibatasi hanya untuk owner.", 
                    ephemeral=True
                )
                return

            await interaction.response.defer(ephemeral=True)

            final_account_limit = None
            if subscription_type in ['perma_limited', 'trial_limited']:
                if not limit or limit <= 0:
                    embed_data = {
                        "title": "⚠️ Limit Required",
                        "description": "Untuk paket terbatas, Anda harus mengisi batas akun yang valid",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.edit_original_response(embed=embed)
                    return
                final_account_limit = limit

            expires_at = None
            if subscription_type.startswith('trial_'):
                expiry_date = datetime.now() + timedelta(days=30)
                expires_at = expiry_date.isoformat()

            existing_user = self.db.get_user_by_id(str(user.id))
            if existing_user:
                embed_data = {
                    "title": "❌ User Already Exists",
                    "description": f"User {user.name} sudah terdaftar dalam sistem.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return

            user_data = {
                "id": str(user.id),
                "username": user.name,
                "subscriptionType": subscription_type,
                "accountLimit": final_account_limit,
                "createdAt": datetime.now().isoformat(),
                "expiresAt": expires_at,
                "notes": "",
                "active": True,
                "addedBy": str(interaction.user.id)
            }

            success = self.db.add_user(user_data)

            if success:
                role_assigned = await assign_role_for_user(interaction.guild, str(user.id), subscription_type)

                notification_embed_data = {
                    "title": "✅ Subscription Activated",
                    "description": f"Subscription untuk **{self.bot.user.name}** telah diaktifkan.",
                    "fields": [
                        {"name": "📦 Subscription Type", "value": self.format_subscription_type(subscription_type), "inline": True},
                        {"name": "🔢 Account Limit", "value": str(final_account_limit) if final_account_limit else "Tidak Terbatas", "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": datetime.now().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                if expires_at:
                    notification_embed_data["fields"].append({
                        "name": "⏰ Expires At",
                        "value": datetime.fromisoformat(expires_at).strftime('%Y-%m-%d'),
                        "inline": True
                    })
                
                if role_assigned:
                    notification_embed_data["fields"].append({
                        "name": "🎭 Role Status",
                        "value": "Role telah ditambahkan",
                        "inline": True
                    })
                
                notification_embed = discord.Embed.from_dict(enhance_embed(notification_embed_data))
                try:
                    await user.send(embed=notification_embed)
                except:
                    pass

                response_embed_data = {
                    "title": "✅ User Added Successfully",
                    "description": f"User **{user.name}** telah ditambahkan dengan tipe subscription **{self.format_subscription_type(subscription_type)}**",
                    "fields": [
                        {"name": "🆔 User ID", "value": str(user.id), "inline": True},
                        {"name": "📦 Subscription Type", "value": self.format_subscription_type(subscription_type), "inline": True},
                        {"name": "🔢 Account Limit", "value": str(final_account_limit) if final_account_limit else "Tidak Terbatas", "inline": True},
                        {"name": "⏰ Expires At", "value": datetime.fromisoformat(expires_at).strftime('%Y-%m-%d') if expires_at else "Tidak Pernah", "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": datetime.now().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }

                if role_assigned:
                    response_embed_data["fields"].append({
                        "name": "🎭 Role Status",
                        "value": "Role berhasil ditambahkan",
                        "inline": True
                    })
                else:
                    response_embed_data["fields"].append({
                        "name": "🎭 Role Status",
                        "value": "Gagal menambahkan role",
                        "inline": True
                    })

                embed = discord.Embed.from_dict(enhance_embed(response_embed_data))
                await interaction.edit_original_response(embed=embed)
            else:
                embed_data = {
                    "title": "❌ Failed to Add User",
                    "description": "Terjadi kesalahan saat menyimpan data pengguna.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
        except Exception as e:
            if config.is_debug:
                print(f'Error in add_user command: {e}')
            embed_data = {
                "title": "❌ Error",
                "description": f"Terjadi kesalahan tak terduga: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed)
    
    def format_subscription_type(self, sub_type: str) -> str:
        format_map = {
            'perma_unlimited': '♾️ Unlimited Permanent',
            'perma_limited': '🔒 Limited Permanent',
            'trial_unlimited': '🆓 Trial Unlimited',
            'trial_limited': '⏳ Trial Limited'
        }
        return format_map.get(sub_type, sub_type)

    @add_user.autocomplete('subscription_type')
    async def subscription_type_autocomplete(self, interaction: discord.Interaction, current: str):
        choices = [
            app_commands.Choice(name='Perma Limited', value='perma_limited'),
            app_commands.Choice(name='Trial Limited', value='trial_limited'),
            app_commands.Choice(name='Perma Unlimited', value='perma_unlimited'),
            app_commands.Choice(name='Trial Unlimited', value='trial_unlimited')
        ]
        return [choice for choice in choices if current.lower() in choice.name.lower()]

async def setup(bot):
    await bot.add_cog(AddUserCommand(bot))