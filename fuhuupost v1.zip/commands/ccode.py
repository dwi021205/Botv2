import discord
from discord.ext import commands
import json
import os
from datetime import datetime, timezone, timedelta
from config import config

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

def get_codes_file_path():
    return os.path.join(os.path.dirname(__file__), '..', 'data', 'codes.json')

def ensure_codes_file_exists():
    file_path = get_codes_file_path()
    if not os.path.exists(file_path):
        try:
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump({"codes": []}, f, indent=2)
            return True
        except Exception:
            return False
    return True

def load_codes():
    ensure_codes_file_exists()
    file_path = get_codes_file_path()
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('codes', [])
    except Exception:
        return []

def save_codes(codes):
    file_path = get_codes_file_path()
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump({"codes": codes}, f, indent=2)
        return True
    except Exception:
        return False

def code_exists(code_string):
    codes = load_codes()
    return any(code['code'].lower() == code_string.lower() for code in codes)

def save_code(code_data):
    codes = load_codes()
    codes.append(code_data)
    return save_codes(codes)

class CCodeCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="ccode", description="Buat kode redeem untuk langganan")
    @discord.app_commands.describe(
        code="Kode redeem yang akan dibuat",
        subscription_type="Tipe langganan",
        expiry_days="Masa berlaku kode dalam hari (0 = tidak pernah kadaluarsa)",
        trial_days="Masa berlaku langganan trial dalam hari",
        limit="Batas akun (hanya untuk paket limited)",
        max_uses="Batas maksimum pengguna yang dapat menggunakan kode ini (0 = tidak terbatas)"
    )
    @discord.app_commands.choices(subscription_type=[
        discord.app_commands.Choice(name='Perma Limited', value='perma_limited'),
        discord.app_commands.Choice(name='Trial Limited', value='trial_limited'),
        discord.app_commands.Choice(name='Perma Unlimited', value='perma_unlimited'),
        discord.app_commands.Choice(name='Trial Unlimited', value='trial_unlimited')
    ])
    async def ccode(
        self, 
        interaction: discord.Interaction, 
        code: str,
        subscription_type: str,
        expiry_days: int = 0,
        trial_days: int = 30,
        limit: int = None,
        max_uses: int = 0
    ):
        if interaction.user.id != int(config.owner_id):
            await interaction.response.send_message("⛔ Perintah ini dibatasi hanya untuk pemilik bot.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)
        
        try:
            if 'limited' in subscription_type and not limit:
                embed_data = {
                    "title": "❌ Account Limit Required",
                    "description": "Untuk paket terbatas, Anda harus mengisi batas akun",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
                return

            if code_exists(code):
                embed_data = {
                    "title": "❌ Code Already Exists",
                    "description": f"Kode redeem **{code}** sudah ada dalam sistem",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
                return

            code_expiry_date = None
            if expiry_days > 0:
                expiry_date = get_wib_time() + timedelta(days=expiry_days)
                code_expiry_date = expiry_date.isoformat()
            
            code_data = {
                "code": code,
                "subscriptionType": subscription_type,
                "codeExpiryDate": code_expiry_date,
                "trialDays": trial_days,
                "accountLimit": limit if 'limited' in subscription_type else None,
                "maxUses": max_uses,
                "createdAt": get_wib_time().isoformat(),
                "createdBy": str(interaction.user.id),
                "redeemedBy": []
            }
            
            if not save_code(code_data):
                embed_data = {
                    "title": "❌ Failed to Save Code",
                    "description": "Terjadi kesalahan saat menyimpan kode redeem",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
                return
            
            subscription_names = {
                'perma_unlimited': '♾️ Permanen Tidak Terbatas',
                'perma_limited': '🔒 Permanen Terbatas',
                'trial_unlimited': '🆓 Uji Coba Tidak Terbatas',
                'trial_limited': '⏳ Uji Coba Terbatas'
            }
            
            formatted_subscription_type = subscription_names.get(subscription_type, subscription_type)
            
            embed_data = {
                "title": "✅ Redeem Code Created Successfully",
                "description": f"Kode redeem **{code}** telah berhasil dibuat",
                "fields": [
                    {
                        "name": "📦 Subscription Type",
                        "value": formatted_subscription_type,
                        "inline": True
                    },
                    {
                        "name": "🔢 Account Limit",
                        "value": str(limit) if 'limited' in subscription_type else "Tidak Terbatas",
                        "inline": True
                    },
                    {
                        "name": "👥 Maximum Users",
                        "value": str(max_uses) if max_uses > 0 else "Tidak Terbatas",
                        "inline": True
                    }
                ],
                "color": 0x00FF00,
                "timestamp": get_wib_time().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            if code_expiry_date:
                embed_data["fields"].append({
                    "name": "⏰ Code Valid Until",
                    "value": datetime.fromisoformat(code_expiry_date).strftime('%d-%m-%Y'),
                    "inline": True
                })
            else:
                embed_data["fields"].append({
                    "name": "⏰ Code Validity",
                    "value": "Selamanya",
                    "inline": True
                })
            
            if subscription_type.startswith('trial_'):
                embed_data["fields"].append({
                    "name": "📅 Trial Period",
                    "value": f"{trial_days} hari",
                    "inline": True
                })
            
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed])
            
        except Exception as e:
            embed_data = {
                "title": "❌ Error",
                "description": f"Terjadi kesalahan tak terduga: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed])

async def setup(bot):
    await bot.add_cog(CCodeCommand(bot))