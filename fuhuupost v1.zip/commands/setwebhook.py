import discord
from discord.ext import commands
import aiohttp
import database
from datetime import datetime, timezone, timedelta
from config import config

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

async def validate_webhook(webhook_url):
    try:
        test_embed = {
            "embeds": [{
                "title": "🔔 Webhook Test",
                "description": "Ini adalah pesan test untuk validasi webhook URL Anda.",
                "color": 0x00FF00,
                "timestamp": get_wib_time().isoformat()
            }]
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(webhook_url, json=test_embed, headers={'Content-Type': 'application/json'}) as response:
                return {"valid": True, "status": response.status}
    except Exception as e:
        return {"valid": False, "error": str(e)}

class SetWebhookModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title="Pengaturan Webhook Pribadi")

        self.webhook_url = discord.ui.TextInput(
            label="Webhook URL Discord",
            placeholder="Masukkan link webhook atau ketik 'delete' untuk hapus",
            required=True,
            max_length=500
        )
        self.add_item(self.webhook_url)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        user_id = str(interaction.user.id)
        user = database.db.get_user_by_id(user_id)
        
        if not user:
            embed_data = {
                "title": "❌ User Not Found",
                "description": "Anda belum terdaftar dalam sistem.",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)
            return

        webhook_input = self.webhook_url.value.strip().lower()
        
        if webhook_input == "delete":
            success = database.db.delete_user_webhook(user_id)
            
            if success:
                embed_data = {
                    "title": "🗑️ Webhook Deleted Successfully",
                    "description": "Webhook pribadi Anda telah dihapus. Sekarang semua log akun Anda akan dikirim ke webhook global.",
                    "fields": [
                        {"name": "📋 Status", "value": "Kembali menggunakan webhook global", "inline": False}
                    ],
                    "color": 0xFFA500,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed], ephemeral=True)
            else:
                embed_data = {
                    "title": "❌ Failed to Delete Webhook",
                    "description": "Terjadi kesalahan saat menghapus webhook.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed], ephemeral=True)
            return
        
        webhook_url = self.webhook_url.value
        
        if 'discord.com/api/webhooks/' not in webhook_url:
            embed_data = {
                "title": "❌ Invalid Webhook URL",
                "description": "URL webhook harus merupakan webhook Discord yang valid.",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)
            return

        validation = await validate_webhook(webhook_url)
        
        if not validation['valid']:
            embed_data = {
                "title": "❌ Webhook Validation Failed",
                "description": f"Error: {validation['error']}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)
            return

        success = database.db.set_user_webhook(user_id, webhook_url)
        
        if success:
            embed_data = {
                "title": "✅ Webhook Set Successfully",
                "description": "Webhook pribadi Anda telah diatur dan divalidasi. Sekarang semua log akun Anda akan dikirim ke webhook pribadi Anda.",
                "fields": [
                    {"name": "📝 Webhook URL", "value": f"{webhook_url[:50]}...", "inline": False},
                    {"name": "📋 Status", "value": "Log akan dikirim ke webhook pribadi", "inline": False}
                ],
                "color": 0x00FF00,
                "timestamp": get_wib_time().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)
        else:
            embed_data = {
                "title": "❌ Failed to Save Webhook",
                "description": "Terjadi kesalahan saat menyimpan webhook.",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)

class SetWebhookCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="setwebhook", description="Atur URL webhook pribadi untuk log akun Anda")
    async def setwebhook(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        if not database.db.has_active_subscription(user_id):
            await interaction.response.send_message("⚠️ Anda tidak memiliki langganan aktif. Gunakan `/buy` untuk membeli langganan.", ephemeral=True)
            return

        modal = SetWebhookModal()
        await interaction.response.send_modal(modal)

async def setup(bot):
    await bot.add_cog(SetWebhookCommand(bot))