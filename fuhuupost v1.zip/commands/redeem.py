import discord
from discord.ext import commands
import json
import os
import database
from datetime import datetime, timezone, timedelta
from config import config

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

def get_codes_file_path():
    return os.path.join(os.path.dirname(__file__), '..', 'data', 'codes.json')

def load_codes():
    file_path = get_codes_file_path()
    try:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('codes', [])
    except Exception:
        pass
    return []

def save_codes(codes):
    file_path = get_codes_file_path()
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump({"codes": codes}, f, indent=2)
        return True
    except Exception:
        return False

def get_code_by_string(code_string):
    codes = load_codes()
    return next((code for code in codes if code['code'].lower() == code_string.lower()), None)

def is_code_expired(code_data):
    if not code_data.get('codeExpiryDate'):
        return False
    
    expiry_date = datetime.fromisoformat(code_data['codeExpiryDate'])
    return expiry_date < get_wib_time()

def has_maximum_uses(code_data):
    if code_data.get('maxUses', 0) == 0:
        return False
    
    redeemed_count = len(code_data.get('redeemedBy', []))
    return redeemed_count >= code_data['maxUses']

def has_user_redeemed_code(code_data, user_id):
    return str(user_id) in code_data.get('redeemedBy', [])

def add_user_to_redeemed_list(code_data, user_id):
    codes = load_codes()
    code_index = next((i for i, code in enumerate(codes) if code['code'].lower() == code_data['code'].lower()), -1)
    
    if code_index == -1:
        return False
    
    if 'redeemedBy' not in codes[code_index]:
        codes[code_index]['redeemedBy'] = []
    
    if str(user_id) not in codes[code_index]['redeemedBy']:
        codes[code_index]['redeemedBy'].append(str(user_id))
    
    return save_codes(codes)

def format_subscription_type(subscription_type):
    types = {
        'perma_unlimited': '♾️ Permanen Tidak Terbatas',
        'perma_limited': '🔒 Permanen Terbatas',
        'trial_unlimited': '🆓 Uji Coba Tidak Terbatas',
        'trial_limited': '⏳ Uji Coba Terbatas'
    }
    return types.get(subscription_type, subscription_type)

class RedeemCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="redeem", description="Redeem kode untuk langganan")
    @discord.app_commands.describe(code="Kode redeem yang akan digunakan")
    async def redeem(self, interaction: discord.Interaction, code: str):
        await interaction.response.defer(ephemeral=True)
        
        try:
            user_id = str(interaction.user.id)
            user = database.db.get_user_by_id(user_id)
            
            code_data = get_code_by_string(code)
            
            if not code_data:
                embed_data = {
                    "title": "❌ Invalid Code",
                    "description": f"Kode redeem **{code}** tidak ditemukan atau tidak valid",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
                return
            
            if is_code_expired(code_data):
                embed_data = {
                    "title": "⏰ Code Expired",
                    "description": f"Kode redeem **{code}** telah kadaluarsa",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
                return
            
            if has_maximum_uses(code_data):
                embed_data = {
                    "title": "🚫 Code Exhausted",
                    "description": f"Kode redeem **{code}** telah mencapai batas penggunaan maksimum",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
                return
            
            if has_user_redeemed_code(code_data, user_id):
                embed_data = {
                    "title": "⚠️ Already Used",
                    "description": f"Anda telah menggunakan kode redeem **{code}** sebelumnya",
                    "color": 0xFF5555,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
                return
            
            if user:
                if user['subscriptionType'] != code_data['subscriptionType']:
                    embed_data = {
                        "title": "⚠️ Subscription Type Mismatch",
                        "description": f"Paket Anda ({format_subscription_type(user['subscriptionType'])}) tidak sama dengan paket kode redeem ({format_subscription_type(code_data['subscriptionType'])}). Kode redeem hanya dapat digunakan untuk paket yang sama.",
                        "color": 0xFF5555,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    enhance_embed(embed_data)
                    embed = discord.Embed.from_dict(embed_data)
                    await interaction.followup.send(embeds=[embed])
                    return
                
                updated_user_data = user.copy()
                
                if 'limited' in user['subscriptionType'] and code_data.get('accountLimit'):
                    updated_user_data['accountLimit'] = (user.get('accountLimit', 0) or 0) + code_data['accountLimit']
                
                if user['subscriptionType'].startswith('trial_') and user.get('expiresAt') and code_data.get('trialDays'):
                    current_expiry = datetime.fromisoformat(user['expiresAt'])
                    new_expiry = current_expiry + timedelta(days=code_data['trialDays'])
                    updated_user_data['expiresAt'] = new_expiry.isoformat()
                
                if not database.db.update_user(user_id, updated_user_data):
                    embed_data = {
                        "title": "❌ Subscription Update Failed",
                        "description": "Terjadi kesalahan saat memperbarui data pengguna",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    enhance_embed(embed_data)
                    embed = discord.Embed.from_dict(embed_data)
                    await interaction.followup.send(embeds=[embed])
                    return
                
                add_user_to_redeemed_list(code_data, user_id)
                
                embed_data = {
                    "title": "✅ Code Redeemed Successfully",
                    "description": f"Anda telah berhasil menggunakan kode redeem **{code}**",
                    "color": 0x00FF00,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                if 'limited' in updated_user_data['subscriptionType']:
                    embed_data.setdefault("fields", []).append({
                        "name": "🔢 New Account Limit",
                        "value": str(updated_user_data['accountLimit']),
                        "inline": True
                    })
                    
                    if code_data.get('accountLimit'):
                        embed_data["fields"].append({
                            "name": "➕ Limit Addition",
                            "value": f"+{code_data['accountLimit']}",
                            "inline": True
                        })
                
                if updated_user_data['subscriptionType'].startswith('trial_') and updated_user_data.get('expiresAt'):
                    embed_data.setdefault("fields", []).append({
                        "name": "⏰ Expires On",
                        "value": datetime.fromisoformat(updated_user_data['expiresAt']).strftime('%d-%m-%Y'),
                        "inline": True
                    })
                    
                    if code_data.get('trialDays'):
                        embed_data["fields"].append({
                            "name": "➕ Duration Addition",
                            "value": f"+{code_data['trialDays']} hari",
                            "inline": True
                        })
                
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
            else:
                user_data = {
                    "id": user_id,
                    "username": interaction.user.name,
                    "subscriptionType": code_data['subscriptionType'],
                    "accountLimit": code_data.get('accountLimit') if 'limited' in code_data['subscriptionType'] else None,
                    "createdAt": get_wib_time().isoformat(),
                    "expiresAt": None,
                    "notes": f"Dibuat melalui kode redeem: {code}",
                    "active": True,
                    "addedBy": "redeem"
                }
                
                if code_data['subscriptionType'].startswith('trial_'):
                    expiry_date = get_wib_time() + timedelta(days=code_data.get('trialDays', 30))
                    user_data['expiresAt'] = expiry_date.isoformat()
                
                if not database.db.add_user(user_data):
                    embed_data = {
                        "title": "❌ Subscription Application Failed",
                        "description": "Terjadi kesalahan saat membuat data pengguna",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    enhance_embed(embed_data)
                    embed = discord.Embed.from_dict(embed_data)
                    await interaction.followup.send(embeds=[embed])
                    return
                
                add_user_to_redeemed_list(code_data, user_id)
                
                embed_data = {
                    "title": "✅ Code Redeemed Successfully",
                    "description": f"Anda telah berhasil menggunakan kode redeem **{code}**",
                    "fields": [
                        {
                            "name": "📦 Subscription Type",
                            "value": format_subscription_type(code_data['subscriptionType']),
                            "inline": True
                        }
                    ],
                    "color": 0x00FF00,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                if 'limited' in code_data['subscriptionType']:
                    embed_data["fields"].append({
                        "name": "🔢 Account Limit",
                        "value": str(code_data.get('accountLimit', 0)),
                        "inline": True
                    })
                
                if code_data['subscriptionType'].startswith('trial_'):
                    embed_data["fields"].append({
                        "name": "⏰ Expires On",
                        "value": datetime.fromisoformat(user_data['expiresAt']).strftime('%d-%m-%Y'),
                        "inline": True
                    })
                
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed])
                
        except Exception as e:
            embed_data = {
                "title": "❌ Error",
                "description": f"Terjadi kesalahan tak terduga: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed])

async def setup(bot):
    await bot.add_cog(RedeemCommand(bot))