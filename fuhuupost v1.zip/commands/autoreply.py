import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import httpx
from typing import Optional, List
import sys
import os
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import db, enhance_embed
from config import config

async def validate_token(token: str) -> dict:
    try:
        headers = {'Authorization': token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get('https://discord.com/api/v10/users/@me', headers=headers)
            if response.status_code == 200:
                return {"valid": True, "user": response.json()}
            else:
                return {"valid": False, "error": response.text}
    except Exception as e:
        return {"valid": False, "error": str(e)}

def truncate_label(text: str, max_length: int = 50) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def truncate_description(text: str, max_length: int = 100) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def truncate_text(text: str, max_length: int = 200) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

class AutoReplyAccountSelectView(discord.ui.View):
    def __init__(self, command_instance, account_options: List[discord.SelectOption]):
        super().__init__(timeout=300)
        self.command = command_instance
        
        select = discord.ui.Select(
            placeholder="Pilih akun untuk auto reply",
            options=account_options,
            custom_id="autoreply_account_select"
        )
        select.callback = self.select_callback
        self.add_item(select)
    
    async def select_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            account_id = interaction.data['values'][0]
            user_id = str(interaction.user.id)
            await self.command.show_autoreply_manager(interaction, account_id, user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception as follow_error:
                print(f"Error in select_callback: {e}, Follow error: {follow_error}")
    
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

class AutoReplyManagerView(discord.ui.View):
    def __init__(self, command_instance, user_id: str, account_id: str, is_active: bool):
        super().__init__(timeout=300)
        self.command = command_instance
        self.user_id = user_id
        self.account_id = account_id
        
        toggle_button = discord.ui.Button(
            label="⏹️ Stop" if is_active else "▶️ Start",
            style=discord.ButtonStyle.danger if is_active else discord.ButtonStyle.success,
            custom_id="toggle_autoreply"
        )
        toggle_button.callback = self.toggle_callback
        self.add_item(toggle_button)
        
        text_button = discord.ui.Button(
            label="✏️ Set Text",
            style=discord.ButtonStyle.primary,
            custom_id="set_text"
        )
        text_button.callback = self.text_callback
        self.add_item(text_button)
        
        presence_button = discord.ui.Button(
            label="👤 Presence",
            style=discord.ButtonStyle.secondary,
            custom_id="set_presence"
        )
        presence_button.callback = self.presence_callback
        self.add_item(presence_button)
    
    async def toggle_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            await self.command.handle_toggle_autoreply(interaction, self.account_id, self.user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception as follow_error:
                print(f"Error in toggle_callback: {e}, Follow error: {follow_error}")
    
    async def text_callback(self, interaction: discord.Interaction):
        try:
            await self.command.show_text_modal(interaction, self.account_id, self.user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception as follow_error:
                print(f"Error in text_callback: {e}, Follow error: {follow_error}")
    
    async def presence_callback(self, interaction: discord.Interaction):
        try:
            await self.command.show_presence_modal(interaction, self.account_id, self.user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception as follow_error:
                print(f"Error in presence_callback: {e}, Follow error: {follow_error}")
    
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

class AutoReplyTextModal(discord.ui.Modal):
    def __init__(self, command_instance, user_id: str, account_id: str, current_text: str):
        super().__init__(title="Set Auto Reply Text")
        self.command = command_instance
        self.user_id = user_id
        self.account_id = account_id
        
        self.text_input = discord.ui.TextInput(
            label="Auto Reply Text",
            style=discord.TextStyle.paragraph,
            placeholder="Masukkan pesan auto reply...",
            default=current_text,
            max_length=2000,
            required=True
        )
        self.add_item(self.text_input)
        
    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            
            if not db.autoreply_handler:
                embed_data = {
                    "title": "❌ Auto Reply Unavailable",
                    "description": "Auto reply handler tidak tersedia",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            success = db.autoreply_handler.update_reply_text(
                self.user_id, self.account_id, self.text_input.value
            )
            
            if success:
                await self.command.refresh_autoreply_manager(interaction, self.account_id, self.user_id)
            else:
                embed_data = {
                    "title": "❌ Failed to Update",
                    "description": "Gagal memperbarui text auto reply",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                
        except Exception as e:
            embed_data = {
                "title": "❌ Error",
                "description": f"Error: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                else:
                    await interaction.edit_original_response(embed=embed, view=None)
            except Exception as follow_error:
                print(f"Error in text modal submit: {e}, Follow error: {follow_error}")

class AutoReplyPresenceModal(discord.ui.Modal):
    def __init__(self, command_instance, user_id: str, account_id: str, current_presence: str):
        super().__init__(title="Set Presence Status")
        self.command = command_instance
        self.user_id = user_id
        self.account_id = account_id
        
        self.presence_input = discord.ui.TextInput(
            label="Presence Status",
            style=discord.TextStyle.short,
            placeholder="online/idle/dnd/invisible",
            default=current_presence,
            max_length=20,
            required=True
        )
        self.add_item(self.presence_input)
        
    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            
            if not db.autoreply_handler:
                embed_data = {
                    "title": "❌ Auto Reply Unavailable",
                    "description": "Auto reply handler tidak tersedia",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            presence_value = self.presence_input.value.lower().strip()
            
            valid_presence = {
                "online": "online",
                "idle": "idle",
                "dnd": "dnd",
                "invisible": "invisible"
            }
            
            if presence_value not in valid_presence:
                embed_data = {
                    "title": "⚠️ Invalid Presence",
                    "description": "Presence tidak valid. Gunakan: online, idle, dnd, atau invisible",
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            success = db.autoreply_handler.update_presence_status(
                self.user_id, self.account_id, presence_value
            )
            
            if success:
                await self.command.refresh_autoreply_manager(interaction, self.account_id, self.user_id)
            else:
                embed_data = {
                    "title": "❌ Failed to Update",
                    "description": "Gagal memperbarui presence status",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                
        except Exception as e:
            embed_data = {
                "title": "❌ Error",
                "description": f"Error: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                else:
                    await interaction.edit_original_response(embed=embed, view=None)
            except Exception as follow_error:
                print(f"Error in presence modal submit: {e}, Follow error: {follow_error}")

class AutoReplyCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    @app_commands.command(name="autoreply", description="Kelola auto reply untuk akun Discord")
    async def autoreply(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            
            user_id = str(interaction.user.id)
            
            if not db.has_active_subscription(user_id) and user_id != config.owner_id:
                embed_data = {
                    "title": "💎 Subscription Required",
                    "description": "Anda perlu langganan aktif untuk menggunakan fitur auto reply.",
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
                
            if not db.autoreply_handler:
                embed_data = {
                    "title": "❌ Auto Reply Unavailable",
                    "description": "Sistem auto reply belum diinisialisasi.",
                    "color": 0xFF0000,
                    "fields": [
                        {
                            "name": "⚠️ Kemungkinan Penyebab",
                            "value": "• Selfcord module belum diinstall\n• AutoReply handler tidak berjalan\n• Konfigurasi sistem error",
                            "inline": False
                        }
                    ],
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
                
            accounts = db.get_accounts(user_id)
            
            if not accounts:
                embed_data = {
                    "title": "⚠️ No Accounts Found",
                    "description": "Tambahkan akun terlebih dahulu dengan `/add_account`",
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            account_options = []
            for account in accounts:
                validation = await validate_token(account["token"])
                status = "Valid" if validation["valid"] else "Tidak Valid"
                
                account_options.append(discord.SelectOption(
                    label=truncate_label(f"{account['username']} ({account['name']})"),
                    description=truncate_description(f"Status: {status}"),
                    value=account["id"],
                    emoji="✅" if validation["valid"] else "❌"
                ))
            
            if not account_options:
                embed_data = {
                    "title": "⚠️ No Valid Accounts",
                    "description": "Semua akun tidak valid atau tidak dapat diakses",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            embed_data = {
                "title": "🤖 Auto Reply Manager",
                "description": "Pilih akun untuk mengkonfigurasi auto reply",
                "color": 0x0099FF,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            view = AutoReplyAccountSelectView(self, account_options)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
            
        except Exception as e:
            try:
                error_embed_data = {
                    "title": "❌ Error",
                    "description": f"Error: {str(e)}",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
                
                if interaction.response.is_done():
                    await interaction.edit_original_response(embed=error_embed, view=None)
                else:
                    await interaction.response.send_message(embed=error_embed, ephemeral=True)
            except Exception as follow_error:
                print(f"Error in autoreply command: {e}, Follow error: {follow_error}")
    
    async def show_autoreply_manager(self, interaction: discord.Interaction, account_id: str, user_id: str):
        try:
            if not db.autoreply_handler:
                embed_data = {
                    "title": "❌ Auto Reply Unavailable",
                    "description": "Auto reply handler tidak tersedia",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            account = db.get_account_by_id(account_id, user_id)
            if not account:
                embed_data = {
                    "title": "❌ Account Not Found",
                    "description": "Akun tidak ditemukan",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            validation = await validate_token(account['token'])
            if not validation["valid"]:
                embed_data = {
                    "title": "❌ Invalid Token",
                    "description": f"Token untuk akun {account['username']} sudah tidak valid.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            stats = db.autoreply_handler.get_autoreply_stats(user_id, account_id)
            config_data = db.autoreply_handler.load_autoreply_config(user_id, account_id)
            
            user_data = validation["user"]
            username = user_data.get('username', 'Unknown')
            user_discord_id = user_data.get('id', 'Unknown')
            
            is_active = stats["isActive"]
            status_emoji = "✅" if is_active else "❌"
            status_text = "Online" if is_active else "Offline"
            
            presence_map = {
                "online": "Online",
                "idle": "Idle", 
                "dnd": "Do Not Disturb",
                "invisible": "Invisible"
            }
            presence_display = presence_map.get(stats["presenceStatus"], stats["presenceStatus"])
            
            reply_text = stats["replyText"] or "Belum diatur"
            reply_text_preview = truncate_text(reply_text, 300)
            
            embed_data = {
                "title": "🤖 Auto Reply Manager",
                "description": "Kontrol auto reply dan edit konfigurasi",
                "color": 0x00FF00 if is_active else 0xFF0000,
                "fields": [
                    {
                        "name": "👤 Info Account",
                        "value": f"**Username:** {username}\n**ID:** {user_discord_id}",
                        "inline": False
                    },
                    {
                        "name": "⚙️ Status Auto Reply",
                        "value": f"**Status:** {status_emoji} {status_text}\n**Presence:** {presence_display}",
                        "inline": False
                    },
                    {
                        "name": "💬 Text Reply",
                        "value": f"```{reply_text_preview}```",
                        "inline": False
                    }
                ],
                "timestamp": datetime.now().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            view = AutoReplyManagerView(self, user_id, account_id, is_active)
            
            await interaction.edit_original_response(embed=embed, view=view)
            
        except Exception as e:
            embed_data = {
                "title": "❌ Error",
                "description": f"Error: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=None)
    
    async def handle_toggle_autoreply(self, interaction: discord.Interaction, account_id: str, user_id: str):
        try:
            if not db.autoreply_handler:
                embed_data = {
                    "title": "❌ Auto Reply Unavailable",
                    "description": "Auto reply handler tidak tersedia",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            account = db.get_account_by_id(account_id, user_id)
            if not account:
                embed_data = {
                    "title": "❌ Account Not Found",
                    "description": "Akun tidak ditemukan",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            is_active = db.autoreply_handler.is_client_active(user_id, account_id)
            
            if is_active:
                await db.autoreply_handler.stop_autoreply_client(user_id, account_id)
            else:
                await db.autoreply_handler.start_autoreply_client(user_id, account_id, account['token'])
            
            await self.refresh_autoreply_manager(interaction, account_id, user_id)
            
        except Exception as e:
            embed_data = {
                "title": "❌ Error",
                "description": f"Error: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=None)
    
    async def show_text_modal(self, interaction: discord.Interaction, account_id: str, user_id: str):
        try:
            if not db.autoreply_handler:
                embed_data = {
                    "title": "❌ Auto Reply Unavailable",
                    "description": "Auto reply handler tidak tersedia",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            config_data = db.autoreply_handler.load_autoreply_config(user_id, account_id)
            current_text = config_data.get("replyText", "")
            
            modal = AutoReplyTextModal(self, user_id, account_id, current_text)
            await interaction.response.send_modal(modal)
            
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Error: {str(e)}", view=None)
            except Exception as follow_error:
                print(f"Error in show_text_modal: {e}, Follow error: {follow_error}")
    
    async def show_presence_modal(self, interaction: discord.Interaction, account_id: str, user_id: str):
        try:
            if not db.autoreply_handler:
                embed_data = {
                    "title": "❌ Auto Reply Unavailable",
                    "description": "Auto reply handler tidak tersedia",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            config_data = db.autoreply_handler.load_autoreply_config(user_id, account_id)
            current_presence = config_data.get("presenceStatus", "online")
            
            modal = AutoReplyPresenceModal(self, user_id, account_id, current_presence)
            await interaction.response.send_modal(modal)
            
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Error: {str(e)}", view=None)
            except Exception as follow_error:
                print(f"Error in show_presence_modal: {e}, Follow error: {follow_error}")
    
    async def refresh_autoreply_manager(self, interaction: discord.Interaction, account_id: str, user_id: str):
        try:
            await self.show_autoreply_manager(interaction, account_id, user_id)
        except Exception as e:
            pass

async def setup(bot):
    await bot.add_cog(AutoReplyCog(bot))