import discord
from discord.ext import commands
import os
import zipfile
import base64
import asyncio
import aiohttp
from datetime import datetime, timezone, timedelta
from config import config

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

async def create_backup():
    try:
        now = get_wib_time()
        time_str = now.strftime("%H:%M") + "WIB"
        date_str = now.strftime("%d-%m-%Y")
        filename = f"BackupPada_{time_str}_{date_str}.zip"
        
        data_folder = os.path.join(os.path.dirname(__file__), '..', 'data')
        zip_path = os.path.join(os.path.dirname(__file__), '..', filename)
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(data_folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, os.path.dirname(data_folder))
                    zipf.write(file_path, arcname)
        
        file_size = os.path.getsize(zip_path)
        if file_size < 1024:
            size_str = f"{file_size} bytes"
        elif file_size < 1024 * 1024:
            size_str = f"{file_size / 1024:.2f} KB"
        else:
            size_str = f"{file_size / (1024 * 1024):.2f} MB"
        
        await delete_old_backups()
        
        with open(zip_path, 'rb') as f:
            file_content = f.read()
        
        base64_content = base64.b64encode(file_content).decode()
        
        headers = {
            'Authorization': f'token {config.github["token"]}',
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'Discord-Bot-Backup'
        }
        
        upload_url = f'https://api.github.com/repos/{config.github["owner"]}/{config.github["repo"]}/contents/backups/{filename}'
        
        payload = {
            'message': f'Upload backup: {filename}',
            'content': base64_content,
            'committer': {
                'name': 'Discord Bot',
                'email': 'bot@discord.backup'
            },
            'author': {
                'name': 'Discord Bot', 
                'email': 'bot@discord.backup'
            }
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.put(upload_url, headers=headers, json=payload) as response:
                if response.status not in [200, 201]:
                    response_text = await response.text()
                    raise Exception(f"GitHub upload failed: {response.status} - {response_text}")
        
        os.remove(zip_path)
        
        return {
            'success': True,
            'filename': filename,
            'size': size_str
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

async def delete_old_backups():
    try:
        headers = {
            'Authorization': f'token {config.github["token"]}',
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'Discord-Bot-Backup'
        }
        
        url = f'https://api.github.com/repos/{config.github["owner"]}/{config.github["repo"]}/contents/backups'
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as response:
                if response.status == 200:
                    files = await response.json()
                    
                    for file in files:
                        delete_url = f'https://api.github.com/repos/{config.github["owner"]}/{config.github["repo"]}/contents/backups/{file["name"]}'
                        delete_payload = {
                            'message': f'Delete old backup: {file["name"]}',
                            'sha': file['sha']
                        }
                        
                        async with session.delete(delete_url, headers=headers, json=delete_payload) as delete_response:
                            pass
                elif response.status != 404:
                    response_text = await response.text()
                    raise Exception(f"Failed to list backups: {response.status} - {response_text}")
        
        return True
    except Exception as e:
        raise e

class BackupCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="backup", description="Membuat backup data dan menyimpannya di GitHub Repository")
    async def backup(self, interaction: discord.Interaction):
        if interaction.user.id != int(config.owner_id):
            await interaction.response.send_message("❌ Perintah ini dibatasi hanya untuk pemilik bot.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)
        
        try:
            backup_result = await create_backup()
            
            if backup_result['success']:
                embed_data = {
                    "title": "✅ Backup Success",
                    "description": f"Backup telah dibuat dan disimpan di GitHub Repository",
                    "fields": [
                        {"name": "📁 File Name", "value": backup_result['filename'], "inline": True},
                        {"name": "📊 File Size", "value": backup_result['size'], "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                
                await interaction.followup.send(embeds=[embed])
            else:
                embed_data = {
                    "title": "❌ Backup Failed",
                    "description": f"Terjadi kesalahan saat membuat backup",
                    "fields": [
                        {"name": "⚠️ Error Details", "value": backup_result['error'], "inline": False}
                    ],
                    "color": 0xFF0000,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                
                await interaction.followup.send(embeds=[embed])
        except Exception as e:
            embed_data = {
                "title": "❌ Backup Failed",
                "description": "Terjadi kesalahan saat membuat backup",
                "fields": [
                    {"name": "⚠️ Error Details", "value": str(e), "inline": False}
                ],
                "color": 0xFF0000,
                "timestamp": get_wib_time().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            
            await interaction.followup.send(embeds=[embed])

async def setup(bot):
    await bot.add_cog(BackupCommand(bot))