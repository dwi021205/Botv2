import discord
from discord.ext import commands
from discord import app_commands
import httpx
import re
import asyncio
import aiohttp
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, List
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import config
import database

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

async def validate_token(token: str) -> Dict[str, Any]:
    try:
        headers = {'Authorization': token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get('https://discord.com/api/v10/users/@me', headers=headers)
            if response.status_code == 200:
                return {"valid": True, "user": response.json()}
            else:
                return {"valid": False, "error": response.text}
    except Exception as e:
        return {"valid": False, "error": str(e)}

async def fetch_guild_name_from_channel(channel_id: str, user_token: str) -> str:
    try:
        headers = {'Authorization': user_token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            channel_res = await client.get(f'https://discord.com/api/v10/channels/{channel_id}', headers=headers)
            if channel_res.status_code != 200:
                return 'Server Tidak Diketahui'
            
            channel_data = channel_res.json()
            guild_id = channel_data.get("guild_id")
            if not guild_id:
                return 'Server Tidak Diketahui'
            
            guild_res = await client.get(f'https://discord.com/api/v10/guilds/{guild_id}', headers=headers)
            if guild_res.status_code == 200:
                guild_data = guild_res.json()
                return guild_data.get("name", "Server Tidak Diketahui")
            else:
                return 'Server Tidak Diketahui'
    except Exception:
        return 'Server Tidak Diketahui'

async def fetch_channel_data(channel_id: str, user_token: str) -> Dict[str, Any]:
    try:
        headers = {'Authorization': user_token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f'https://discord.com/api/v10/channels/{channel_id}', headers=headers)
            if response.status_code == 200:
                data = response.json()
                return {
                    "name": data.get("name", f"Channel {channel_id}"),
                    "guildId": data.get("guild_id"),
                    "success": True,
                    "data": data
                }
            else:
                return {
                    "name": f"Channel {channel_id}",
                    "success": False
                }
    except Exception:
        return {
            "name": f"Channel {channel_id}",
            "success": False
        }

def parse_delay(delay_str: str) -> Optional[int]:
    pattern = r'^(\d+)([smhdj])$'
    match = re.match(pattern, delay_str.strip())
    
    if not match:
        return None
    
    value = int(match.group(1))
    unit = match.group(2)
    
    if unit in ['s', 'd']:
        return value * 1000
    elif unit == 'm':
        return value * 60 * 1000
    elif unit in ['h', 'j']:
        return value * 60 * 60 * 1000
    
    return None

def format_delay(ms: int) -> str:
    if ms < 60000:
        return f"{ms // 1000}d"
    elif ms < 3600000:
        return f"{ms // 60000}m"
    else:
        return f"{ms // 3600000}j"

def truncate_text(text: str, max_length: int = 1000) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def truncate_label(text: str, max_length: int = 50) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def truncate_description(text: str, max_length: int = 100) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def is_channel_in_account(account: Dict[str, Any], channel_id: str) -> bool:
    channels = account.get("channels", [])
    return any(channel.get("id") == channel_id for channel in channels)

class AddChannelCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db

    @app_commands.command(name="add_channel", description="Tambahkan saluran baru ke akun selfbot")
    async def add_channel(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            
            user_id = str(interaction.user.id)
            
            if not self.db.has_active_subscription(user_id):
                embed_data = {
                    "title": "⚠️ Subscription Required",
                    "description": "Anda tidak memiliki langganan aktif. Gunakan `/buy` untuk membeli langganan.",
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            accounts = self.db.get_accounts(user_id)
            
            if not accounts:
                embed_data = {
                    "title": "⚠️ No Accounts Found",
                    "description": "Tambahkan akun terlebih dahulu dengan `/add_account`",
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            account_options = []
            for account in accounts:
                try:
                    validation = await validate_token(account["token"])
                    status = "Valid" if validation["valid"] else "Tidak Valid"
                    channel_count = len(account.get("channels", []))
                    
                    account_options.append(discord.SelectOption(
                        label=truncate_label(f"{account['username']} ({account['name']})"),
                        description=truncate_description(f"Status: {status} | Saluran: {channel_count}"),
                        value=account["id"],
                        emoji="✅" if validation["valid"] else "❌"
                    ))
                except Exception as e:
                    account_options.append(discord.SelectOption(
                        label=truncate_label(f"{account.get('username', 'Unknown')} ({account.get('name', 'Unknown')})"),
                        description=truncate_description(f"Status: Error | Saluran: {len(account.get('channels', []))}"),
                        value=account["id"],
                        emoji="❌"
                    ))
            
            if not account_options:
                embed_data = {
                    "title": "⚠️ No Valid Accounts",
                    "description": "Semua akun tidak valid atau tidak dapat diakses",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            embed_data = {
                "title": "📥 Add Channel",
                "description": "Pilih akun selfbot untuk menambahkan saluran",
                "color": 0x0099FF,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            view = AddChannelSelectView(self, account_options, str(interaction.user.id))
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
            
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")
            except Exception as follow_error:
                print(f"Error in add_channel: {e}, Follow error: {follow_error}")

    async def show_add_channel_form(self, interaction: discord.Interaction, account: Dict[str, Any], user_id: str):
        try:
            embed_data = {
                "title": "📥 Add New Channel",
                "description": f"Tambahkan saluran baru ke akun **{account.get('username', 'Unknown')}**",
                "fields": [
                    {
                        "name": "📋 Informasi Akun",
                        "value": f"**Username:** {account.get('username', 'Unknown')}\n**Nama:** {account.get('name', 'Unknown')}\n**Total Saluran:** {len(account.get('channels', []))}",
                        "inline": False
                    },
                    {
                        "name": "📝 Cara Menambah Saluran",
                        "value": "Klik tombol **Tambah Saluran** di bawah untuk mengisi form dan menambahkan saluran baru ke akun ini.",
                        "inline": False
                    }
                ],
                "color": 0x00FF88,
                "timestamp": get_wib_time().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            view = AddChannelButtonView(self, account, user_id)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
            
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)

class AddChannelSelectView(discord.ui.View):
    def __init__(self, command_instance, account_options: List[discord.SelectOption], user_id: str):
        super().__init__(timeout=300)
        self.command = command_instance
        self.user_id = user_id
        
        select = discord.ui.Select(
            placeholder="Pilih akun selfbot",
            options=account_options,
            custom_id="addChannel_select"
        )
        select.callback = self.select_callback
        self.add_item(select)
    
    async def select_callback(self, interaction: discord.Interaction):
        try:
            if str(interaction.user.id) != self.user_id:
                await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
                return
                
            await interaction.response.defer()
            
            account_id = interaction.data['values'][0]
            user_id = str(interaction.user.id)
            
            account = self.command.db.get_account_by_id(account_id, user_id)
            if not account:
                await interaction.edit_original_response(content="❌ Akun tidak ditemukan.", view=None)
                return
            
            validation = await validate_token(account["token"])
            if not validation["valid"]:
                embed_data = {
                    "title": "❌ Invalid Token",
                    "description": f"Token untuk akun {account['username']} sudah tidak valid.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            await self.command.show_add_channel_form(interaction, account, user_id)
            
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception as follow_error:
                print(f"Error in select_callback: {e}, Follow error: {follow_error}")
    
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

class AddChannelButtonView(discord.ui.View):
    def __init__(self, command_instance, account: Dict[str, Any], user_id: str):
        super().__init__(timeout=300)
        self.command = command_instance
        self.account = account
        self.user_id = user_id
        
        add_button = discord.ui.Button(
            label="📥 Tambah Saluran",
            style=discord.ButtonStyle.success,
            custom_id="add_channel_button"
        )
        add_button.callback = self.add_channel_callback
        self.add_item(add_button)
    
    async def add_channel_callback(self, interaction: discord.Interaction):
        try:
            if str(interaction.user.id) != self.user_id:
                await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
                return
            
            modal = AddChannelModal(self.command, self.account, self.user_id)
            await interaction.response.send_modal(modal)
            
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception as follow_error:
                print(f"Error in add_channel_callback: {e}, Follow error: {follow_error}")
    
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

class AddChannelModal(discord.ui.Modal):
    def __init__(self, command_instance, account: Dict[str, Any], user_id: str):
        super().__init__(title="Tambah Saluran")
        self.command = command_instance
        self.account = account
        self.user_id = user_id
        
        self.channel_id = discord.ui.TextInput(
            label="ID Saluran",
            placeholder="Masukkan ID saluran Discord",
            required=True,
            max_length=20
        )
        self.add_item(self.channel_id)
        
        self.base_delay = discord.ui.TextInput(
            label="Jeda Dasar (mis., 5d/5s, 1m, 2j/2h)",
            placeholder="Format: 5d/5s, 1m, 2j/2h",
            required=False,
            max_length=20
        )
        self.add_item(self.base_delay)
        
        self.additional_delay = discord.ui.TextInput(
            label="Jeda Tambahan (dipisahkan koma)",
            placeholder="Contoh: 5d,10d,1m",
            required=False,
            max_length=100
        )
        self.add_item(self.additional_delay)
        
        self.image_urls = discord.ui.TextInput(
            label="URL Gambar (dipisahkan koma)",
            placeholder="https://example.com/image1.jpg,https://example.com/image2.png",
            required=False,
            max_length=4000,
            style=discord.TextStyle.paragraph
        )
        self.add_item(self.image_urls)
        
        self.message = discord.ui.TextInput(
            label="Pesan (maks 2500 karakter)",
            placeholder="Teks pesan yang akan dikirim otomatis",
            required=True,
            max_length=2500,
            style=discord.TextStyle.paragraph
        )
        self.add_item(self.message)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            if str(interaction.user.id) != self.user_id:
                await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
                return
            
            await interaction.response.defer(ephemeral=True)
            
            channel_id = self.channel_id.value.strip()
            base_delay_input = self.base_delay.value.strip()
            additional_delay_input = self.additional_delay.value.strip()
            image_urls_input = self.image_urls.value.strip()
            message = self.message.value.strip()
            
            if not message:
                await interaction.followup.send(content='❌ Pesan tidak boleh kosong.', ephemeral=True)
                return
            
            if not channel_id:
                await interaction.followup.send(content='❌ ID Saluran tidak boleh kosong.', ephemeral=True)
                return
            
            if is_channel_in_account(self.account, channel_id):
                embed_data = {
                    "title": "❌ Channel Already Registered",
                    "description": "ID saluran ini sudah terdaftar pada akun ini. Setiap saluran hanya dapat ditambahkan sekali per akun.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            
            try:
                channel_data = await fetch_channel_data(channel_id, self.account["token"])
                if not channel_data["success"]:
                    embed_data = {
                        "title": "❌ Invalid Channel",
                        "description": f"Tidak dapat mengakses saluran dengan ID: {channel_id}. Pastikan ID benar dan token memiliki akses.",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.followup.send(embed=embed, ephemeral=True)
                    return
                
                guild_name = await fetch_guild_name_from_channel(channel_id, self.account["token"])
                
                slowmode = channel_data["data"].get('rate_limit_per_user', 0)
                base_delay = 120000
                
                if slowmode > 0:
                    base_delay = slowmode * 1000
                
                if base_delay_input:
                    parsed_delay = parse_delay(base_delay_input)
                    if parsed_delay is None:
                        embed_data = {
                            "title": "❌ Invalid Delay Format",
                            "description": "Format jeda harus: 5d/5s, 1m, 2j/2h",
                            "color": 0xFF0000,
                            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                        }
                        embed = discord.Embed.from_dict(enhance_embed(embed_data))
                        await interaction.followup.send(embed=embed, ephemeral=True)
                        return
                    
                    base_delay = max(parsed_delay, 5000)
                
                additional_delays = []
                if additional_delay_input:
                    delay_parts = [d.strip() for d in additional_delay_input.split(',')]
                    for delay_part in delay_parts:
                        parsed = parse_delay(delay_part)
                        if parsed is not None:
                            additional_delays.append(max(parsed, 5000))
                    
                    if additional_delay_input and not additional_delays:
                        embed_data = {
                            "title": "❌ Invalid Additional Delay Format",
                            "description": "Jeda tambahan harus berupa daftar yang dipisahkan koma: 5d/5s,10d/10s,1m",
                            "color": 0xFF0000,
                            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                        }
                        embed = discord.Embed.from_dict(enhance_embed(embed_data))
                        await interaction.followup.send(embed=embed, ephemeral=True)
                        return
                
                image_urls_list = []
                if image_urls_input:
                    urls = [url.strip() for url in image_urls_input.split(',') if url.strip()]
                    for url in urls:
                        if url.startswith(('http://', 'https://')):
                            image_urls_list.append(url)
                
                new_channel = {
                    "id": channel_id,
                    "baseDelay": base_delay,
                    "additionalDelays": additional_delays,
                    "imageUrls": image_urls_list,
                    "message": message,
                    "status": "offline",
                    "guildName": guild_name,
                    "channelName": channel_data["name"],
                    "lastMessageTime": None,
                    "createdAt": get_wib_time().isoformat()
                }
                
                result = self.command.db.add_channel(self.account['id'], new_channel, self.user_id)
                
                if result:
                    if image_urls_list:
                        try:
                            await self.command.db.download_channel_images(self.user_id, channel_id, image_urls_list)
                        except Exception as e:
                            if config.is_debug:
                                print(f"Error downloading images: {e}")
                    
                    message_preview = message[:200] + ('...' if len(message) > 200 else '')
                    
                    embed_data = {
                        "title": "✅ Channel Successfully Added",
                        "description": f"Saluran <#{channel_id}> telah ditambahkan ke akun **{self.account.get('username', 'Unknown')}**",
                        "fields": [
                            {"name": "🌍 Server", "value": guild_name, "inline": True},
                            {"name": "⏱️ Jeda Dasar", "value": format_delay(base_delay), "inline": True},
                            {"name": "⏳ Jeda Tambahan", "value": ', '.join(format_delay(d) for d in additional_delays) if additional_delays else "Tidak Ada", "inline": True}
                        ],
                        "color": 0x00FF00,
                        "timestamp": get_wib_time().isoformat(),
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    
                    if image_urls_list:
                        image_links = '\n'.join(f"[Link Ke Gambar {i+1}]({url})" for i, url in enumerate(image_urls_list))
                        embed_data["fields"].append({"name": "🖼️ Gambar", "value": image_links, "inline": False})
                    
                    embed_data["fields"].append({"name": "💬 Pesan", "value": f"```{message_preview}```", "inline": False})
                    
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.followup.send(embed=embed, ephemeral=True)
                else:
                    embed_data = {
                        "title": "❌ Failed to Add Channel",
                        "description": "Terjadi kesalahan saat menambahkan saluran",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.followup.send(embed=embed, ephemeral=True)
                    
            except Exception as e:
                embed_data = {
                    "title": "❌ Error",
                    "description": f"Terjadi kesalahan: {str(e)}",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.followup.send(embed=embed, ephemeral=True)
                
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.followup.send(content=f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
            except Exception as follow_error:
                print(f"Error in AddChannelModal: {e}, Follow error: {follow_error}")

async def setup(bot):
    cog = AddChannelCommand(bot)
    if hasattr(bot, 'get_cog') and bot.get_cog('AddChannelCommand'):
        await bot.remove_cog('AddChannelCommand')
    await bot.add_cog(cog)