import discord
from discord.ext import commands
from discord import app_commands
import httpx
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List
from config import config
from database import enhance_embed

async def validate_token(token: str) -> Dict[str, Any]:
    try:
        headers = {'Authorization': token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get('https://discord.com/api/v10/users/@me', headers=headers)
            if response.status_code == 200:
                return {"valid": True, "user": response.json()}
            else:
                return {"valid": False, "error": response.text}
    except Exception as e:
        return {"valid": False, "error": str(e)}

def create_main_embed() -> Dict[str, Any]:
    return {
        "title": "⚙️ Account Management",
        "description": "Pilih tindakan yang ingin Anda lakukan:",
        "fields": [
            {"name": "➕ Add Account", "value": "Tambahkan akun selfbot baru", "inline": True},
            {"name": "✏️ Edit Account", "value": "Perbarui token akun yang ada", "inline": True},
            {"name": "🗑️ Delete Account", "value": "Hapus akun selfbot yang ada", "inline": True}
        ],
        "color": 0x0099FF,
        "timestamp": datetime.now().isoformat(),
        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
    }

class AddAccountCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db
    
    @app_commands.command(name="add_account", description="Kelola akun selfbot")
    async def add_account(self, interaction: discord.Interaction):
        try:
            user_id = str(interaction.user.id)
            
            if user_id != config.owner_id:
                has_subscription = self.db.has_active_subscription(user_id)
                if not has_subscription:
                    embed_data = {
                        "title": "❌ Access Denied",
                        "description": "Anda tidak memiliki langganan aktif.",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
            
            embed_data = create_main_embed()
            view = MainAccountView(self, user_id)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)

class MainAccountView(discord.ui.View):
    def __init__(self, command_instance, user_id: str):
        super().__init__(timeout=300)
        self.command = command_instance
        self.user_id = user_id
    
    @discord.ui.button(label="Add Akun", emoji="🤖", style=discord.ButtonStyle.success, custom_id="accountManager_add")
    async def add_account_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            user = self.command.db.get_user_by_id(self.user_id)
            
            if self.user_id != config.owner_id and user and user["subscriptionType"].find("limited") != -1:
                can_add_more = self.command.db.can_add_more_accounts(self.user_id)
                if not can_add_more:
                    embed_data = {
                        "title": "⚠️ Account Limit Reached",
                        "description": "Anda telah mencapai jumlah maksimum akun yang diizinkan untuk tier langganan Anda.",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
            
            modal = AddAccountModal(self.command, self.user_id)
            await interaction.response.send_modal(modal)
        except Exception as e:
            await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
    
    @discord.ui.button(label="Edit Akun", emoji="✏️", style=discord.ButtonStyle.primary, custom_id="accountManager_edit")
    async def edit_account_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            accounts = self.command.db.get_accounts(self.user_id)
            
            if not accounts:
                await interaction.response.send_message(
                    '⚠️ Tidak ada akun terdaftar. Tambahkan akun terlebih dahulu.',
                    ephemeral=True
                )
                return
            
            await interaction.response.defer()
            
            account_options = []
            for account in accounts:
                validation = await validate_token(account["token"])
                status = "Valid" if validation["valid"] else "Tidak Valid"
                channel_count = len(account.get("channels", []))
                
                account_options.append(discord.SelectOption(
                    label=f"{account['username']} ({account['name']})"[:100],
                    description=f"Status: {status} | Saluran: {channel_count}"[:100],
                    value=account["id"],
                    emoji="✅" if validation["valid"] else "❌"
                ))
            
            embed_data = {
                "title": "✏️ Edit Account",
                "description": "Pilih akun untuk memperbarui tokennya:",
                "color": 0x0099FF,
                "timestamp": datetime.now().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            view = EditAccountSelectView(self.command, self.user_id, account_options)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")
    
    @discord.ui.button(label="Delete Akun", emoji="🗑️", style=discord.ButtonStyle.danger, custom_id="accountManager_delete")
    async def delete_account_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            accounts = self.command.db.get_accounts(self.user_id)
            
            if not accounts:
                await interaction.response.send_message(
                    '⚠️ Tidak ada akun terdaftar. Tambahkan akun terlebih dahulu.',
                    ephemeral=True
                )
                return
            
            await interaction.response.defer()
            
            account_options = []
            for account in accounts:
                validation = await validate_token(account["token"])
                status = "Valid" if validation["valid"] else "Tidak Valid"
                channel_count = len(account.get("channels", []))
                
                account_options.append(discord.SelectOption(
                    label=f"{account['username']} ({account['name']})"[:100],
                    description=f"Status: {status} | Saluran: {channel_count}"[:100],
                    value=account["id"],
                    emoji="✅" if validation["valid"] else "❌"
                ))
            
            embed_data = {
                "title": "🗑️ Delete Account",
                "description": "**PERINGATAN**: Semua saluran dan konfigurasi untuk akun yang dipilih akan dihapus secara permanen.",
                "color": 0xFF0000,
                "timestamp": datetime.now().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            view = DeleteAccountSelectView(self.command, self.user_id, account_options)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class AddAccountModal(discord.ui.Modal):
    def __init__(self, command_instance, user_id: str):
        super().__init__(title="Add New Account")
        self.command = command_instance
        self.user_id = user_id
        
        self.token = discord.ui.TextInput(
            label="Token",
            style=discord.TextStyle.paragraph,
            required=True
        )
        self.add_item(self.token)
        
        self.cover_name = discord.ui.TextInput(
            label="Cover Name",
            style=discord.TextStyle.short,
            required=False
        )
        self.add_item(self.cover_name)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            token = self.token.value.strip()
            cover_name = self.cover_name.value.strip()
            
            await interaction.response.defer(ephemeral=True)
            
            if not token:
                embed_data = {
                    "title": "❌ Token Empty",
                    "description": "Token tidak boleh kosong.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            
            if self.command.db.is_token_duplicate(token):
                embed_data = {
                    "title": "❌ Token Already Exists",
                    "description": "Token ini sudah terdaftar dalam sistem. Setiap token hanya dapat digunakan sekali.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            
            validation = await validate_token(token)
            
            if not validation["valid"]:
                embed_data = {
                    "title": "❌ Invalid Token",
                    "description": f"Token yang Anda masukkan tidak valid: {validation['error']}",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            
            user = validation["user"]
            account_count = self.command.db.get_account_count_for_user(self.user_id)
            account_name = cover_name or f"akun_{account_count + 1}"
            
            account = {
                "id": str(uuid.uuid4()).replace('-', '')[:16],
                "name": account_name,
                "token": token,
                "username": user["username"],
                "globalName": user.get("global_name"),
                "avatar": user.get("avatar"),
                "userId": user["id"],
                "createdAt": datetime.now().isoformat(),
                "channels": []
            }
            
            result = self.command.db.add_account(self.user_id, account)
            
            if not result:
                embed_data = {
                    "title": "❌ Failed to Add Account",
                    "description": "Terjadi kesalahan saat menyimpan data akun.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            
            main_embed_data = create_main_embed()
            main_view = MainAccountView(self.command, self.user_id)
            main_embed = discord.Embed.from_dict(enhance_embed(main_embed_data))
            await interaction.edit_original_response(embed=main_embed, view=main_view)
            
            success_embed_data = {
                "title": "✅ Account Added Successfully",
                "description": f"Akun **{user['username']}** telah berhasil ditambahkan.",
                "fields": [
                    {"name": "👤 Username", "value": user["username"], "inline": True},
                    {"name": "🏷️ Display Name", "value": user.get("global_name", "Tidak Ada"), "inline": True},
                    {"name": "🎭 Cover Name", "value": account_name, "inline": True},
                    {"name": "🆔 User ID", "value": user["id"], "inline": True},
                    {"name": "✅ Status", "value": "Valid", "inline": True},
                    {"name": "📊 Channel Count", "value": "0", "inline": True}
                ],
                "color": 0x00FF00,
                "timestamp": datetime.now().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            if user.get("avatar"):
                success_embed_data["thumbnail"] = {"url": f"https://cdn.discordapp.com/avatars/{user['id']}/{user['avatar']}.png"}
            
            success_embed = discord.Embed.from_dict(enhance_embed(success_embed_data))
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            
        except Exception as e:
            error_embed_data = {
                "title": "❌ Error",
                "description": f"Error: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
            await interaction.followup.send(embed=error_embed, ephemeral=True)

class EditAccountSelectView(discord.ui.View):
    def __init__(self, command_instance, user_id: str, account_options: List[discord.SelectOption]):
        super().__init__(timeout=300)
        self.command = command_instance
        self.user_id = user_id
        
        select = discord.ui.Select(
            placeholder="Select Account",
            options=account_options,
            custom_id="accountSelector_edit"
        )
        select.callback = self.select_callback
        self.add_item(select)
    
    async def select_callback(self, interaction: discord.Interaction):
        try:
            account_id = interaction.data['values'][0]
            
            account = self.command.db.get_account_by_id(account_id, self.user_id)
            if not account:
                await interaction.response.send_message('Account not found', ephemeral=True)
                return
            
            modal = EditAccountModal(self.command, self.user_id, account_id, account)
            await interaction.response.send_modal(modal)
        except Exception as e:
            await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)

class EditAccountModal(discord.ui.Modal):
    def __init__(self, command_instance, user_id: str, account_id: str, account: Dict[str, Any]):
        super().__init__(title=f"Edit Account: {account['username'][:30]}")
        self.command = command_instance
        self.user_id = user_id
        self.account_id = account_id
        self.account = account
        
        self.new_token = discord.ui.TextInput(
            label="New Token",
            style=discord.TextStyle.paragraph,
            required=True
        )
        self.add_item(self.new_token)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            new_token = self.new_token.value.strip()
            
            await interaction.response.defer()
            
            main_embed_data = create_main_embed()
            main_view = MainAccountView(self.command, self.user_id)
            main_embed = discord.Embed.from_dict(enhance_embed(main_embed_data))
            await interaction.edit_original_response(embed=main_embed, view=main_view)
            
            if not new_token:
                error_embed_data = {
                    "title": "❌ Token Empty",
                    "description": "Token tidak boleh kosong.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
                await interaction.followup.send(embed=error_embed, ephemeral=True)
                return
            
            if self.command.db.is_token_duplicate(new_token) and new_token != self.account["token"]:
                error_embed_data = {
                    "title": "❌ Token Already Exists",
                    "description": "Token ini sudah terdaftar untuk akun lain. Setiap token hanya dapat digunakan sekali.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
                await interaction.followup.send(embed=error_embed, ephemeral=True)
                return
            
            validation = await validate_token(new_token)
            
            if not validation["valid"]:
                error_embed_data = {
                    "title": "❌ Invalid Token",
                    "description": f"Token yang Anda masukkan tidak valid: {validation['error']}",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
                await interaction.followup.send(embed=error_embed, ephemeral=True)
                return
            
            user = validation["user"]
            
            self.account.update({
                "token": new_token,
                "username": user["username"],
                "globalName": user.get("global_name"),
                "avatar": user.get("avatar"),
                "userId": user["id"],
                "updatedAt": datetime.now().isoformat()
            })
            
            success = self.command.db.save_account(self.user_id, self.account)
            
            if not success:
                error_embed_data = {
                    "title": "❌ Update Failed",
                    "description": "Terjadi kesalahan saat menyimpan data akun.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
                await interaction.followup.send(embed=error_embed, ephemeral=True)
                return
            
            success_embed_data = {
                "title": "✅ Account Updated Successfully",
                "description": f"Akun **{user['username']}** telah berhasil diperbarui.",
                "fields": [
                    {"name": "👤 Username", "value": user["username"], "inline": True},
                    {"name": "🏷️ Display Name", "value": user.get("global_name", "Tidak Ada"), "inline": True},
                    {"name": "🎭 Cover Name", "value": self.account.get('name', 'Tidak Ada'), "inline": True},
                    {"name": "🆔 User ID", "value": user["id"], "inline": True},
                    {"name": "✅ Status", "value": "Valid", "inline": True},
                    {"name": "📊 Channel Count", "value": str(len(self.account.get('channels', []))), "inline": True}
                ],
                "color": 0x00FF00,
                "timestamp": datetime.now().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            if user.get("avatar"):
                success_embed_data["thumbnail"] = {"url": f"https://cdn.discordapp.com/avatars/{user['id']}/{user['avatar']}.png"}
            
            success_embed = discord.Embed.from_dict(enhance_embed(success_embed_data))
            await interaction.followup.send(embed=success_embed, ephemeral=True)
            
        except Exception as e:
            error_embed_data = {
                "title": "❌ Error",
                "description": f"Error: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
            await interaction.followup.send(embed=error_embed, ephemeral=True)

class DeleteAccountSelectView(discord.ui.View):
    def __init__(self, command_instance, user_id: str, account_options: List[discord.SelectOption]):
        super().__init__(timeout=300)
        self.command = command_instance
        self.user_id = user_id
        
        select = discord.ui.Select(
            placeholder="Select Account",
            options=account_options,
            custom_id="accountSelector_delete"
        )
        select.callback = self.select_callback
        self.add_item(select)
    
    async def select_callback(self, interaction: discord.Interaction):
        try:
            account_id = interaction.data['values'][0]
            
            account = self.command.db.get_account_by_id(account_id, self.user_id)
            if not account:
                await interaction.response.send_message('Account Not Found.', ephemeral=True)
                return
            
            modal = DeleteAccountModal(self.command, self.user_id, account_id, account)
            await interaction.response.send_modal(modal)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

class DeleteAccountModal(discord.ui.Modal):
    def __init__(self, command_instance, user_id: str, account_id: str, account: Dict[str, Any]):
        super().__init__(title=f"Delete Account: {account['username'][:30]}")
        self.command = command_instance
        self.user_id = user_id
        self.account_id = account_id
        self.account = account
        
        self.confirmation = discord.ui.TextInput(
            label='Type "confirm" to delete',
            style=discord.TextStyle.short,
            required=True,
            placeholder="confirm"
        )
        self.add_item(self.confirmation)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            confirmation = self.confirmation.value.strip()
            
            await interaction.response.defer()
            
            main_embed_data = create_main_embed()
            main_view = MainAccountView(self.command, self.user_id)
            main_embed = discord.Embed.from_dict(enhance_embed(main_embed_data))
            await interaction.edit_original_response(embed=main_embed, view=main_view)
            
            if confirmation.lower() != 'confirm':
                error_embed_data = {
                    "title": "❌ Deletion Cancelled",
                    "description": "Penghapusan dibatalkan. Ketik \"confirm\" untuk mengonfirmasi penghapusan.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
                await interaction.followup.send(embed=error_embed, ephemeral=True)
                return
            
            channel_count = len(self.account.get("channels", []))
            
            for channel in self.account.get("channels", []):
                self.command.db.cleanup_channel_images(self.user_id, channel["id"])
            
            success = self.command.db.delete_account(self.account_id, self.user_id)
            
            if success:
                success_embed_data = {
                    "title": "✅ Account Deleted Successfully",
                    "description": f"Account **{self.account['username']}** ({self.account['name']}) telah dihapus.",
                    "fields": [
                        {"name": "🆔 Account ID", "value": self.account_id, "inline": True},
                        {"name": "📊 Channels Deleted", "value": str(channel_count), "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": datetime.now().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                success_embed = discord.Embed.from_dict(enhance_embed(success_embed_data))
                await interaction.followup.send(embed=success_embed, ephemeral=True)
            else:
                error_embed_data = {
                    "title": "❌ Deletion Failed",
                    "description": "Terjadi kesalahan saat menghapus akun.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
                await interaction.followup.send(embed=error_embed, ephemeral=True)
                
        except Exception as e:
            error_embed_data = {
                "title": "❌ Error",
                "description": f"Error: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
            await interaction.followup.send(embed=error_embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(AddAccountCommand(bot))