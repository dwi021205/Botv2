import discord
from discord.ext import commands
from discord import app_commands
import re
from datetime import datetime
from typing import Dict, Any, List, Optional
from config import config
from database import enhance_embed

class ListUsersCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db

    @app_commands.command(name="list_users", description="Lihat semua pengguna dan status langganan mereka")
    async def list_users(self, interaction: discord.Interaction):
        if str(interaction.user.id) != config.owner_id:
            await interaction.response.send_message(
                "⛔ Perintah ini dibatasi hanya untuk pemilik bot.", 
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer(ephemeral=True)
            
            embed, view = await self.generate_users_embed(0)
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

    def smart_search(self, users: List[Dict], query: str) -> List[Dict]:
        if not query or query.strip() == '':
            return users
        
        search_query = query.lower().strip()
        search_words = search_query.split()
        
        filtered_users = []
        for user in users:
            username = user['username'].lower()
            
            if username == search_query:
                filtered_users.append((user, 100))
                continue
            
            if search_query in username:
                filtered_users.append((user, 90))
                continue
                
            username_words = re.split(r'[-_\s]+', username)
            match_count = sum(1 for word in search_words 
                            if any(word in user_word for user_word in username_words))
            
            if match_count > 0:
                score = match_count * 10
                if username.startswith(search_query):
                    score += 50
                filtered_users.append((user, score))
        
        filtered_users.sort(key=lambda x: x[1], reverse=True)
        return [user for user, score in filtered_users]

    async def generate_users_embed(self, page: int = 0, search_query: str = '') -> tuple:
        try:
            users = self.db.load_users()
            
            if len(users) == 0:
                embed_data = {
                    "title": "📋 Users List",
                    "description": "Tidak ada pengguna yang terdaftar.",
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                return embed, None
            
            if search_query:
                users = self.smart_search(users, search_query)
            
            if len(users) == 0 and search_query:
                embed_data = {
                    "title": "📋 Users List",
                    "description": f'Tidak ditemukan pengguna dengan username "{search_query}". Gunakan tombol pencarian untuk mencoba lagi.',
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                view = ListUsersView(self, page, search_query, 1, show_search_only=True)
                return embed, view
            
            users_per_page = 3
            page_count = (len(users) + users_per_page - 1) // users_per_page
            
            page = max(0, min(page, page_count - 1))
            
            start_index = page * users_per_page
            end_index = min(start_index + users_per_page, len(users))
            users_on_page = users[start_index:end_index]
            
            embed_data = {
                "title": "📋 Users List",
                "description": f"Total pengguna: {len(users)}",
                "color": 0x00FFFF,
                "timestamp": datetime.now().isoformat(),
                "fields": [],
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            if search_query:
                embed_data["fields"].append({
                    "name": "🔍 Hasil Pencarian",
                    "value": f'Menampilkan {len(users)} hasil untuk "{search_query}"',
                    "inline": False
                })
            
            for user in users_on_page:
                is_active = self.db.has_active_subscription(user['id'])
                account_count = self.db.get_account_count_for_user(user['id'])
                account_limit_text = f"{account_count}/{user.get('accountLimit', '∞')}" if user.get('accountLimit') else f"{account_count}/∞"
                
                expires_text = 'Tidak Pernah'
                if user.get('expiresAt'):
                    try:
                        expires_date = datetime.fromisoformat(user['expiresAt'])
                        now = datetime.now()
                        
                        diff_time = expires_date - now
                        diff_days = diff_time.days
                        
                        if diff_days > 0:
                            expires_text = f"{expires_date.strftime('%Y-%m-%d')} ({diff_days} hari lagi)"
                        else:
                            expires_text = f"{expires_date.strftime('%Y-%m-%d')} (Kedaluwarsa)"
                    except:
                        expires_text = 'Tidak Pernah'
                
                field_value = (
                    f"🆔 ID: {user['id']}\n"
                    f"📊 Tipe: {user['subscriptionType']}\n"
                    f"👥 Akun: {account_limit_text}\n"
                    f"📅 Dibuat: {datetime.fromisoformat(user['createdAt']).strftime('%Y-%m-%d')}\n"
                    f"⏰ Kedaluwarsa: {expires_text}"
                )
                
                embed_data["fields"].append({
                    "name": f"{user['username']} - {'✅ Aktif' if is_active else '❌ Tidak Aktif'}",
                    "value": field_value,
                    "inline": False
                })
            
            if page_count > 1:
                embed_data["footer"]["text"] = f"Halaman {page + 1} dari {page_count} • FuHuu Auto Post"
            
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            view = ListUsersView(self, page, search_query, page_count) if page_count > 1 or search_query else ListUsersView(self, page, search_query, page_count, True)
            return embed, view
        except Exception as e:
            if config.is_debug:
                print(f"Error in generate_users_embed: {e}")
            embed_data = {
                "title": "❌ Error",
                "description": f"Terjadi kesalahan: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            return embed, None

class ListUsersView(discord.ui.View):
    def __init__(self, command_instance, page: int, search_query: str, page_count: int, show_search_only: bool = False):
        super().__init__(timeout=300)
        self.command = command_instance
        self.page = page
        self.search_query = search_query
        self.page_count = page_count
        
        self.add_item(SearchButton())
        
        if not show_search_only and page_count > 1:
            if page > 0:
                self.add_item(PrevPageButton())
            if page < page_count - 1:
                self.add_item(NextPageButton())

class SearchButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="🔍 Cari Pengguna", style=discord.ButtonStyle.primary)
    
    async def callback(self, interaction: discord.Interaction):
        try:
            modal = SearchModal(self.view.command)
            await interaction.response.send_modal(modal)
        except Exception as e:
            await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)

class PrevPageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="⬅️ Sebelumnya", style=discord.ButtonStyle.secondary)
    
    async def callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            view = self.view
            new_page = view.page - 1
            embed, new_view = await view.command.generate_users_embed(new_page, view.search_query)
            await interaction.edit_original_response(embed=embed, view=new_view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class NextPageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="➡️ Selanjutnya", style=discord.ButtonStyle.secondary)
    
    async def callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            view = self.view
            new_page = view.page + 1
            embed, new_view = await view.command.generate_users_embed(new_page, view.search_query)
            await interaction.edit_original_response(embed=embed, view=new_view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class SearchModal(discord.ui.Modal):
    def __init__(self, command_instance):
        super().__init__(title="Cari Pengguna")
        self.command = command_instance
        
        self.search_query = discord.ui.TextInput(
            label="Username Pengguna",
            style=discord.TextStyle.short,
            placeholder="Masukkan username yang ingin dicari",
            required=True
        )
        self.add_item(self.search_query)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            
            search_query = self.search_query.value.strip()
            embed, view = await self.command.generate_users_embed(0, search_query)
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

async def setup(bot):
    await bot.add_cog(ListUsersCommand(bot))