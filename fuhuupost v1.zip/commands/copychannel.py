import discord
from discord.ext import commands
import difflib
import database
from datetime import datetime, timezone, timedelta
from config import config

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

def find_best_matching_accounts(accounts, target_usernames):
    matching_accounts = []
    
    for target in target_usernames:
        target = target.strip()
        if not target:
            continue
            
        best_match = None
        best_ratio = 0
        
        for account in accounts:
            username = account.get('username', '').lower()
            name = account.get('name', '').lower()
            target_lower = target.lower()
            
            username_ratio = difflib.SequenceMatcher(None, username, target_lower).ratio()
            name_ratio = difflib.SequenceMatcher(None, name, target_lower).ratio()
            
            max_ratio = max(username_ratio, name_ratio)
            
            if max_ratio > best_ratio and max_ratio >= 0.7:
                best_ratio = max_ratio
                best_match = account
        
        if best_match and best_match not in matching_accounts:
            matching_accounts.append(best_match)
    
    return matching_accounts

class CopyChannelView(discord.ui.View):
    def __init__(self, accounts, user_id):
        super().__init__(timeout=300)
        self.accounts = accounts
        self.user_id = user_id
        self.selected_source_account = None
        
        account_options = []
        for account in accounts[:25]:
            account_options.append(discord.SelectOption(
                label=f"{account.get('username', 'Unknown')} ({account.get('name', 'Unknown')})"[:100],
                description=f"ID: {account['id']} | Channels: {len(account.get('channels', []))}"[:100],
                value=account['id']
            ))
        
        if account_options:
            account_select = discord.ui.Select(
                placeholder="Pilih akun sumber untuk menyalin channel",
                options=account_options,
                custom_id="select_source_account"
            )
            account_select.callback = self.source_account_selected
            self.add_item(account_select)

    async def source_account_selected(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
            return

        account_id = interaction.data['values'][0]
        self.selected_source_account = next((acc for acc in self.accounts if acc['id'] == account_id), None)
        
        if not self.selected_source_account:
            await interaction.response.send_message("❌ Akun tidak ditemukan.", ephemeral=True)
            return

        channels_count = len(self.selected_source_account.get('channels', []))
        
        if channels_count == 0:
            embed_data = {
                "title": "⚠️ No Channels Found",
                "description": f"Akun **{self.selected_source_account.get('username', 'Unknown')}** tidak memiliki channel yang dikonfigurasi untuk disalin.",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.response.edit_message(embeds=[embed], view=None)
            return

        self.clear_items()
        
        copy_button = discord.ui.Button(
            label=f"Salin {channels_count} Channel",
            style=discord.ButtonStyle.primary,
            emoji="📋"
        )
        copy_button.callback = self.show_copy_modal
        self.add_item(copy_button)

        embed_data = {
            "title": "📋 Copy Channel Configuration",
            "description": f"Anda telah memilih akun **{self.selected_source_account.get('username', 'Unknown')}** sebagai sumber.",
            "fields": [
                {"name": "📊 Source Account Info", "value": f"**Username:** {self.selected_source_account.get('username', 'Unknown')}\n**Name:** {self.selected_source_account.get('name', 'Unknown')}\n**Total Channel:** {channels_count}", "inline": False},
                {"name": "📝 Next Step", "value": "Klik tombol di bawah untuk menentukan akun tujuan penyalinan channel.", "inline": False}
            ],
            "color": 0x0099FF,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        enhance_embed(embed_data)
        embed = discord.Embed.from_dict(embed_data)
        await interaction.response.edit_message(embeds=[embed], view=self)

    async def show_copy_modal(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
            return

        modal = CopyChannelModal(self.selected_source_account, self.accounts, self.user_id)
        await interaction.response.send_modal(modal)

class CopyChannelModal(discord.ui.Modal):
    def __init__(self, source_account, all_accounts, user_id):
        super().__init__(title="Target Akun Penyalinan")
        self.source_account = source_account
        self.all_accounts = all_accounts
        self.user_id = user_id

        self.target_input = discord.ui.TextInput(
            label="Target Akun (username atau 'all')",
            placeholder="Contoh: user1,user2,user3 atau ketik 'all' untuk semua akun",
            required=True,
            max_length=500,
            style=discord.TextStyle.paragraph
        )
        self.add_item(self.target_input)

    async def on_submit(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
            return

        await interaction.response.defer()

        target_input = self.target_input.value.strip()
        
        if target_input.lower() == 'all':
            target_accounts = [acc for acc in self.all_accounts if acc['id'] != self.source_account['id']]
        else:
            target_usernames = [username.strip() for username in target_input.split(',')]
            available_accounts = [acc for acc in self.all_accounts if acc['id'] != self.source_account['id']]
            target_accounts = find_best_matching_accounts(available_accounts, target_usernames)

        if not target_accounts:
            embed_data = {
                "title": "❌ No Target Found",
                "description": f"Tidak dapat menemukan akun target yang sesuai dengan input: **{target_input}**",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)
            return

        channels_to_copy = self.source_account.get('channels', [])
        
        if not channels_to_copy:
            embed_data = {
                "title": "❌ No Channels to Copy",
                "description": "Akun sumber tidak memiliki channel yang dikonfigurasi.",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)
            return

        success_accounts = []
        failed_accounts = []

        for target_account in target_accounts:
            try:
                success_count = 0
                
                for channel in channels_to_copy:
                    existing_channels = target_account.get('channels', [])
                    channel_exists = any(ch['id'] == channel['id'] for ch in existing_channels)
                    
                    if not channel_exists:
                        new_channel = channel.copy()
                        new_channel['createdAt'] = get_wib_time().isoformat()
                        new_channel['status'] = 'offline'
                        new_channel['lastMessageTime'] = None
                        
                        result = database.db.add_channel(target_account['id'], new_channel, str(self.user_id))
                        if result:
                            success_count += 1
                            
                            if new_channel.get('imageUrls'):
                                try:
                                    await database.db.download_channel_images(str(self.user_id), channel['id'], new_channel['imageUrls'])
                                except:
                                    pass
                
                if success_count > 0:
                    success_accounts.append({
                        'account': target_account,
                        'channels_copied': success_count
                    })
                else:
                    failed_accounts.append({
                        'account': target_account,
                        'reason': 'Semua channel sudah ada'
                    })
                    
            except Exception as e:
                failed_accounts.append({
                    'account': target_account,
                    'reason': str(e)
                })

        view = CopyChannelView([acc for acc in self.all_accounts], self.user_id)
        
        main_embed_data = {
            "title": "📋 Copy Channel Configuration",
            "description": "Pilih akun sumber untuk menyalin channel",
            "color": 0x0099FF,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        enhance_embed(main_embed_data)
        main_embed = discord.Embed.from_dict(main_embed_data)
        
        await interaction.followup.edit_message(interaction.message.id, embeds=[main_embed], view=view)

        if success_accounts:
            success_embed_data = {
                "title": "✅ Copy Channel Success",
                "description": f"Berhasil menyalin channel dari akun **{self.source_account.get('username', 'Unknown')}** ke {len(success_accounts)} akun target.",
                "fields": [],
                "color": 0x00FF00,
                "timestamp": get_wib_time().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            for success in success_accounts:
                account = success['account']
                channels_copied = success['channels_copied']
                success_embed_data["fields"].append({
                    "name": f"✅ {account.get('username', 'Unknown')}",
                    "value": f"**Username:** {account.get('username', 'Unknown')}\n**ID:** {account['id']}\n**Channel Disalin:** {channels_copied}",
                    "inline": True
                })
            
            enhance_embed(success_embed_data)
            success_embed = discord.Embed.from_dict(success_embed_data)
            await interaction.followup.send(embeds=[success_embed], ephemeral=True)

        if failed_accounts:
            failed_embed_data = {
                "title": "❌ Copy Channel Failed",
                "description": f"Beberapa akun gagal menerima copy channel dari **{self.source_account.get('username', 'Unknown')}**.",
                "fields": [],
                "color": 0xFF0000,
                "timestamp": get_wib_time().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            for failed in failed_accounts:
                account = failed['account']
                reason = failed['reason']
                failed_embed_data["fields"].append({
                    "name": f"❌ {account.get('username', 'Unknown')}",
                    "value": f"**Username:** {account.get('username', 'Unknown')}\n**ID:** {account['id']}\n**Alasan:** {reason}",
                    "inline": True
                })
            
            enhance_embed(failed_embed_data)
            failed_embed = discord.Embed.from_dict(failed_embed_data)
            await interaction.followup.send(embeds=[failed_embed], ephemeral=True)

class CopyChannelCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="copychannel", description="Copy semua channel dari suatu akun ke akun lain")
    async def copychannel(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        if not database.db.has_active_subscription(user_id):
            await interaction.response.send_message("⚠️ Anda tidak memiliki langganan aktif. Gunakan `/buy` untuk membeli langganan.", ephemeral=True)
            return

        accounts = database.db.get_accounts(user_id)
        
        if len(accounts) < 2:
            embed_data = {
                "title": "⚠️ Insufficient Accounts",
                "description": "Anda memerlukan setidaknya 2 akun untuk menggunakan fitur copy channel. Tambahkan akun terlebih dahulu dengan `/add_account`",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            await interaction.response.send_message(embeds=[embed], ephemeral=True)
            return

        view = CopyChannelView(accounts, interaction.user.id)
        
        embed_data = {
            "title": "📋 Copy Channel Configuration",
            "description": "Pilih akun sumber untuk menyalin channel",
            "color": 0x0099FF,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        enhance_embed(embed_data)
        embed = discord.Embed.from_dict(embed_data)
        
        await interaction.response.send_message(embeds=[embed], view=view, ephemeral=True)

async def setup(bot):
    await bot.add_cog(CopyChannelCommand(bot))