import discord
from discord.ext import commands
import asyncio
import aiohttp
import httpx
import database
from datetime import datetime, timezone, timedelta
from config import config

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

async def validate_token(token):
    try:
        headers = {'Authorization': token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get('https://discord.com/api/v10/users/@me', headers=headers)
            if response.status_code == 200:
                return {"valid": True, "user": response.json()}
            else:
                return {"valid": False, "error": response.text}
    except Exception as e:
        return {"valid": False, "error": str(e)}

async def get_guilds(token):
    headers = {
        'Authorization': token,
        'User-Agent': 'Discord-Android/126021;RNA',
        'Content-Type': 'application/json'
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get('https://discord.com/api/v10/users/@me/guilds', headers=headers) as response:
                if response.status == 200:
                    return {"success": True, "guilds": await response.json()}
                else:
                    return {"success": False, "error": await response.text()}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def get_guild_channels(token, guild_id):
    headers = {
        'Authorization': token,
        'User-Agent': 'Discord-Android/126021;RNA',
        'Content-Type': 'application/json'
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f'https://discord.com/api/v10/guilds/{guild_id}/channels', headers=headers) as response:
                if response.status == 200:
                    return {"success": True, "channels": await response.json()}
                else:
                    return {"success": False, "error": await response.text()}
    except Exception as e:
        return {"success": False, "error": str(e)}

def search_channels(channels, query):
    if not query or query.strip() == '':
        return channels
    
    query = query.lower().strip()
    query_words = query.split()
    
    filtered_channels = []
    for channel in channels:
        if not channel.get('name'):
            continue
        
        channel_name = channel['name'].lower()
        
        if channel_name == query:
            filtered_channels.append((channel, 100))
        elif channel_name.startswith(query):
            filtered_channels.append((channel, 90))
        elif query in channel_name:
            filtered_channels.append((channel, 80))
        else:
            channel_words = channel_name.replace('-', ' ').replace('_', ' ').split()
            match_count = sum(1 for word in query_words if any(word in ch_word for ch_word in channel_words))
            if match_count > 0:
                score = (match_count / len(query_words)) * 70
                filtered_channels.append((channel, score))
    
    filtered_channels.sort(key=lambda x: x[1], reverse=True)
    return [channel for channel, score in filtered_channels[:10]]

def get_channel_type_emoji(channel_type):
    emoji_map = {
        0: "💬", 1: "👤", 2: "🎧", 3: "👥", 4: "🔒",
        5: "📢", 10: "💻", 11: "🌐", 12: "🔑", 13: "🔊",
        14: "📨", 15: "📊"
    }
    return emoji_map.get(channel_type, "❓")

def get_channel_type_text(channel_type):
    type_map = {
        0: "Saluran Teks", 1: "DM", 2: "Saluran Suara", 3: "Grup DM",
        4: "Kategori", 5: "Saluran Pengumuman", 10: "Thread Pengumuman",
        11: "Thread Publik", 12: "Thread Privat", 13: "Saluran Stage",
        14: "Direktori", 15: "Forum"
    }
    return type_map.get(channel_type, "Tidak Diketahui")

def parse_delay(delay_str):
    import re
    regex = r'^(\d+)([smhdj])$'
    match = re.match(regex, delay_str.strip())
    
    if not match:
        return None
    
    value = int(match.group(1))
    unit = match.group(2)
    
    if unit in ['s', 'd']:
        return value * 1000
    elif unit == 'm':
        return value * 60 * 1000
    elif unit in ['h', 'j']:
        return value * 60 * 60 * 1000
    
    return None

def format_delay(ms):
    if ms < 60000:
        return f"{ms // 1000}d"
    elif ms < 3600000:
        return f"{ms // 60000}m"
    else:
        return f"{ms // 3600000}j"

def truncate_text(text, max_length=50):
    return text[:max_length-3] + '...' if len(text) > max_length else text

def truncate_label(text, max_length=50):
    return text[:max_length-3] + '...' if len(text) > max_length else text

def truncate_description(text, max_length=100):
    return text[:max_length-3] + '...' if len(text) > max_length else text

def is_channel_in_account(account, channel_id):
    if not account.get('channels'):
        return False
    return any(channel['id'] == channel_id for channel in account['channels'])

class CheckIdView(discord.ui.View):
    def __init__(self, accounts, user_id):
        super().__init__(timeout=300)
        self.accounts = accounts
        self.user_id = user_id
        self.selected_account = None
        self.selected_guild = None

    async def create_account_select(self):
        account_options = []
        for account in self.accounts[:25]:
            try:
                validation = await validate_token(account["token"])
                status = "Valid" if validation["valid"] else "Tidak Valid"
                channel_count = len(account.get("channels", []))
                
                account_options.append(discord.SelectOption(
                    label=truncate_label(f"{account.get('username', 'Unknown')} ({account.get('name', 'Unknown')})"),
                    description=truncate_description(f"Status: {status} | Saluran: {channel_count}"),
                    value=account['id'],
                    emoji="✅" if validation["valid"] else "❌"
                ))
            except Exception as e:
                account_options.append(discord.SelectOption(
                    label=truncate_label(f"{account.get('username', 'Unknown')} ({account.get('name', 'Unknown')})"),
                    description=truncate_description(f"Status: Error | Saluran: {len(account.get('channels', []))}"),
                    value=account['id'],
                    emoji="❌"
                ))
        
        if account_options:
            account_select = discord.ui.Select(
                placeholder="Pilih akun selfbot",
                options=account_options,
                custom_id="select_account"
            )
            account_select.callback = self.account_selected
            self.add_item(account_select)

    async def account_selected(self, interaction: discord.Interaction):
        account_id = interaction.data['values'][0]
        self.selected_account = next((acc for acc in self.accounts if acc['id'] == account_id), None)
        
        if not self.selected_account:
            await interaction.response.send_message("❌ Akun tidak ditemukan.", ephemeral=True)
            return

        await interaction.response.defer()
        
        validation = await validate_token(self.selected_account['token'])
        
        if not validation['valid']:
            embed_data = {
                "title": "❌ Invalid Token",
                "description": f"Token untuk akun **{self.selected_account.get('username', 'Unknown')}** tidak valid atau telah kedaluwarsa.",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.edit_message(interaction.message.id, embeds=[embed], view=None)
            return

        guilds_result = await get_guilds(self.selected_account['token'])
        
        if not guilds_result['success']:
            embed_data = {
                "title": "❌ Error",
                "description": f"Gagal mengambil daftar server: {guilds_result['error']}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.edit_message(interaction.message.id, embeds=[embed], view=None)
            return

        if not guilds_result['guilds']:
            embed_data = {
                "title": "❗ No Servers Found",
                "description": f"Akun **{self.selected_account.get('username', 'Unknown')}** tidak menjadi anggota server manapun.",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.edit_message(interaction.message.id, embeds=[embed], view=None)
            return

        self.clear_items()
        
        guild_options = []
        for guild in guilds_result['guilds'][:25]:
            guild_options.append(discord.SelectOption(
                label=truncate_text(guild['name']),
                description=truncate_text(f"ID: {guild['id']}"),
                value=guild['id']
            ))
        
        guild_select = discord.ui.Select(
            placeholder="Pilih server",
            options=guild_options,
            custom_id="select_guild"
        )
        guild_select.callback = self.guild_selected
        self.add_item(guild_select)

        embed_data = {
            "title": "🔍 Channel Search",
            "description": f"Pilih server tempat akun **{self.selected_account.get('username', 'Unknown')}** menjadi anggota",
            "color": 0x0099FF,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        embed = discord.Embed.from_dict(embed_data)
        await interaction.followup.edit_message(interaction.message.id, embeds=[embed], view=self)

    async def guild_selected(self, interaction: discord.Interaction):
        guild_id = interaction.data['values'][0]
        self.selected_guild = guild_id

        self.clear_items()
        
        search_button = discord.ui.Button(
            label="🔍 Cari Saluran",
            style=discord.ButtonStyle.primary,
            custom_id="search_channel"
        )
        search_button.callback = self.show_search_modal
        self.add_item(search_button)

        embed_data = {
            "title": "🔍 Channel Search",
            "description": "Klik tombol di bawah untuk mencari saluran",
            "fields": [
                {"name": "📊 Akun", "value": self.selected_account.get('username', 'Unknown'), "inline": True},
                {"name": "🆔 ID Server", "value": guild_id, "inline": True}
            ],
            "color": 0x0099FF,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        embed = discord.Embed.from_dict(embed_data)
        await interaction.response.edit_message(embeds=[embed], view=self)

    async def show_search_modal(self, interaction: discord.Interaction):
        modal = SearchModal(self.selected_account, self.selected_guild, self.user_id)
        await interaction.response.send_modal(modal)

class SearchModal(discord.ui.Modal):
    def __init__(self, account, guild_id, user_id):
        super().__init__(title="Cari Saluran")
        self.account = account
        self.guild_id = guild_id
        self.user_id = user_id

        self.channel_name = discord.ui.TextInput(
            label="Nama Saluran",
            placeholder="Masukkan nama saluran yang ingin dicari",
            required=True,
            max_length=100
        )
        self.add_item(self.channel_name)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        channels_result = await get_guild_channels(self.account['token'], self.guild_id)
        
        if not channels_result['success']:
            embed_data = {
                "title": "❌ Error",
                "description": f"Gagal mengambil daftar saluran: {channels_result['error']}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)
            return

        text_channels = [ch for ch in channels_result['channels'] if ch.get('type') in [0, 5, 10, 11, 12, 15]]
        
        search_results = search_channels(text_channels, self.channel_name.value)
        
        if not search_results:
            embed_data = {
                "title": "❗ Not Found",
                "description": f"Tidak ditemukan saluran dengan nama \"{self.channel_name.value}\"",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)
            return

        channel_options = []
        for channel in search_results[:25]:
            emoji = get_channel_type_emoji(channel.get('type', 0))
            channel_options.append(discord.SelectOption(
                label=truncate_text(f"{emoji} {channel['name']}"),
                description=truncate_text(f"ID: {channel['id']} | {get_channel_type_text(channel.get('type', 0))}"),
                value=channel['id']
            ))

        if channel_options:
            view = ChannelSelectView(channel_options, self.account, search_results, self.user_id)
            
            embed_data = {
                "title": "📋 Search Results",
                "description": f"Ditemukan {len(search_results)} saluran yang cocok dengan \"{self.channel_name.value}\"",
                "color": 0x00FF00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], view=view, ephemeral=True)

class ChannelSelectView(discord.ui.View):
    def __init__(self, channel_options, account, channels_data, user_id):
        super().__init__(timeout=300)
        self.account = account
        self.channels_data = channels_data
        self.user_id = user_id

        channel_select = discord.ui.Select(
            placeholder="Pilih saluran",
            options=channel_options,
            custom_id="select_channel"
        )
        channel_select.callback = self.channel_selected
        self.add_item(channel_select)

    async def channel_selected(self, interaction: discord.Interaction):
        channel_id = interaction.data['values'][0]
        selected_channel = next((ch for ch in self.channels_data if ch['id'] == channel_id), None)
        
        if not selected_channel:
            await interaction.response.send_message("❌ Saluran tidak ditemukan.", ephemeral=True)
            return

        if is_channel_in_account(self.account, channel_id):
            embed_data = {
                "title": "❌ Channel Already Registered",
                "description": "ID saluran ini sudah terdaftar pada akun ini. Setiap saluran hanya dapat ditambahkan sekali per akun.",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.response.send_message(embeds=[embed], ephemeral=True)
            return

        emoji = get_channel_type_emoji(selected_channel.get('type', 0))
        
        use_button = discord.ui.Button(
            label="📥 Gunakan untuk menambah saluran",
            style=discord.ButtonStyle.success,
            custom_id=f"use_channel_{channel_id}"
        )
        use_button.callback = lambda i: self.show_add_channel_modal(i, selected_channel)
        
        view = discord.ui.View(timeout=300)
        view.add_item(use_button)

        embed_data = {
            "title": f"{emoji} {selected_channel['name']}",
            "description": "Saluran ditemukan",
            "fields": [
                {"name": "🆔 ID Saluran", "value": selected_channel['id'], "inline": True},
                {"name": "🌐 Tipe", "value": get_channel_type_text(selected_channel.get('type', 0)), "inline": True},
                {"name": "📍 Lokasi", "value": f"Kategori: <#{selected_channel['parent_id']}>" if selected_channel.get('parent_id') else "Tidak dalam kategori", "inline": True}
            ],
            "color": 0x00FF00,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        embed = discord.Embed.from_dict(embed_data)
        await interaction.response.send_message(embeds=[embed], view=view, ephemeral=True)

    async def show_add_channel_modal(self, interaction: discord.Interaction, channel_data):
        modal = AddChannelModal(self.account, channel_data, self.user_id)
        await interaction.response.send_modal(modal)

class AddChannelModal(discord.ui.Modal):
    def __init__(self, account, channel_data, user_id):
        super().__init__(title="Tambah Saluran")
        self.account = account
        self.channel_data = channel_data
        self.user_id = user_id

        self.base_delay = discord.ui.TextInput(
            label="Jeda Dasar (mis., 5d/5s, 1m, 2j/2h)",
            placeholder="Format: 5d/5s, 1m, 2j/2h",
            required=False,
            max_length=20
        )
        self.add_item(self.base_delay)

        self.additional_delay = discord.ui.TextInput(
            label="Jeda Tambahan (dipisahkan koma)",
            placeholder="Contoh: 5d,10d,1m",
            required=False,
            max_length=100
        )
        self.add_item(self.additional_delay)

        self.image_urls = discord.ui.TextInput(
            label="URL Gambar (dipisahkan koma)",
            placeholder="https://example.com/image1.jpg,https://example.com/image2.png",
            required=False,
            max_length=4000,
            style=discord.TextStyle.paragraph
        )
        self.add_item(self.image_urls)

        self.message = discord.ui.TextInput(
            label="Pesan (maks 2500 karakter)",
            placeholder="Teks pesan yang akan dikirim otomatis",
            required=True,
            max_length=2500,
            style=discord.TextStyle.paragraph
        )
        self.add_item(self.message)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    'Authorization': self.account['token'],
                    'User-Agent': 'Discord-Android/126021;RNA'
                }
                async with session.get(f'https://discord.com/api/v10/channels/{self.channel_data["id"]}', headers=headers) as response:
                    if response.status != 200:
                        embed_data = {
                            "title": "❌ Invalid Channel",
                            "description": f"Tidak dapat mengakses saluran dengan ID: {self.channel_data['id']}. Pastikan ID benar dan token memiliki akses.",
                            "color": 0xFF0000,
                            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                        }
                        embed = discord.Embed.from_dict(embed_data)
                        await interaction.followup.send(embeds=[embed], ephemeral=True)
                        return
                    
                    channel_info = await response.json()

            guild_id = channel_info.get('guild_id')
            guild_name = "Unknown Server"
            
            if guild_id:
                try:
                    async with aiohttp.ClientSession() as session:
                        headers = {
                            'Authorization': self.account['token'],
                            'User-Agent': 'Discord-Android/126021;RNA'
                        }
                        async with session.get(f'https://discord.com/api/v10/guilds/{guild_id}', headers=headers) as response:
                            if response.status == 200:
                                guild_info = await response.json()
                                guild_name = guild_info.get('name', 'Unknown Server')
                except:
                    pass

            slowmode = channel_info.get('rate_limit_per_user', 0)
            base_delay = 120000

            if slowmode > 0:
                base_delay = slowmode * 1000

            if self.base_delay.value:
                parsed_delay = parse_delay(self.base_delay.value)
                if parsed_delay is None:
                    embed_data = {
                        "title": "❌ Invalid Delay Format",
                        "description": "Format jeda harus: 5d/5s, 1m, 2j/2h",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(embed_data)
                    await interaction.followup.send(embeds=[embed], ephemeral=True)
                    return
                
                base_delay = max(parsed_delay, 5000)

            additional_delays = []
            if self.additional_delay.value:
                delay_parts = [d.strip() for d in self.additional_delay.value.split(',')]
                for delay_part in delay_parts:
                    parsed = parse_delay(delay_part)
                    if parsed is not None:
                        additional_delays.append(parsed)
                
                if self.additional_delay.value and not additional_delays:
                    embed_data = {
                        "title": "❌ Invalid Additional Delay Format",
                        "description": "Jeda tambahan harus berupa daftar yang dipisahkan koma: 5d/5s,10d/10s,1m",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(embed_data)
                    await interaction.followup.send(embeds=[embed], ephemeral=True)
                    return

            image_urls_list = []
            if self.image_urls.value.strip():
                image_urls_list = [url.strip() for url in self.image_urls.value.split(',') if url.strip()]

            new_channel = {
                "id": self.channel_data['id'],
                "baseDelay": base_delay,
                "additionalDelays": additional_delays,
                "imageUrls": image_urls_list,
                "message": self.message.value,
                "status": "offline",
                "guildName": guild_name,
                "channelName": channel_info.get('name', 'Unknown Channel'),
                "lastMessageTime": None,
                "createdAt": get_wib_time().isoformat()
            }

            result = database.db.add_channel(self.account['id'], new_channel, str(self.user_id))
            
            if result:
                if image_urls_list:
                    try:
                        await database.db.download_channel_images(str(self.user_id), self.channel_data['id'], image_urls_list)
                    except Exception as e:
                        pass

                message_preview = self.message.value[:200] + ('...' if len(self.message.value) > 200 else '')

                embed_data = {
                    "title": "✅ Channel Successfully Added",
                    "description": f"Saluran <#{self.channel_data['id']}> telah ditambahkan ke akun **{self.account.get('username', 'Unknown')}**",
                    "fields": [
                        {"name": "🌍 Server", "value": guild_name, "inline": True},
                        {"name": "⏱️ Jeda Dasar", "value": format_delay(base_delay), "inline": True},
                        {"name": "⏳ Jeda Tambahan", "value": ', '.join(format_delay(d) for d in additional_delays) if additional_delays else "Tidak Ada", "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }

                if image_urls_list:
                    image_links = '\n'.join(f"[Link Ke Gambar {i+1}]({url})" for i, url in enumerate(image_urls_list))
                    embed_data["fields"].append({"name": "🖼️ Gambar", "value": image_links, "inline": False})

                embed_data["fields"].append({"name": "💬 Pesan", "value": f"```{message_preview}```", "inline": False})

                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed], ephemeral=True)
            else:
                embed_data = {
                    "title": "❌ Failed to Add Channel",
                    "description": "Terjadi kesalahan saat menambahkan saluran",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(embed_data)
                await interaction.followup.send(embeds=[embed], ephemeral=True)

        except Exception as e:
            embed_data = {
                "title": "❌ Error",
                "description": f"Terjadi kesalahan: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.followup.send(embeds=[embed], ephemeral=True)

class CheckIdCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="checkid", description="Cari saluran di server dan dapatkan ID-nya")
    async def checkid(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        if not database.db.has_active_subscription(user_id):
            await interaction.response.send_message("⚠️ Anda tidak memiliki langganan aktif. Gunakan `/buy` untuk membeli langganan.", ephemeral=True)
            return

        accounts = database.db.get_accounts(user_id)
        
        if not accounts:
            embed_data = {
                "title": "❗ No Accounts Found",
                "description": "Tambahkan akun terlebih dahulu dengan `/add_account`",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(embed_data)
            await interaction.response.send_message(embeds=[embed], ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        view = CheckIdView(accounts, interaction.user.id)
        await view.create_account_select()
        
        embed_data = {
            "title": "🔍 Channel Search",
            "description": "Pilih akun selfbot terlebih dahulu",
            "color": 0x0099FF,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        embed = discord.Embed.from_dict(embed_data)
        
        await interaction.edit_original_response(embeds=[embed], view=view)

async def setup(bot):
    await bot.add_cog(CheckIdCommand(bot))