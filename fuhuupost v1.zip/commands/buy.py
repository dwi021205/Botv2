import discord
from discord.ext import commands
from discord import app_commands
import requests
import json
import os
import asyncio
import base64
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from config import config
from database import enhance_embed

class MidtransClient:
    def __init__(self, server_key: str, client_key: str, is_production: bool = True):
        self.server_key = server_key
        self.client_key = client_key
        self.is_production = is_production
        self.base_url = "https://api.midtrans.com" if is_production else "https://api.sandbox.midtrans.com"
        
        auth_string = f"{server_key}:"
        self.auth_header = base64.b64encode(auth_string.encode()).decode()
    
    async def charge(self, parameter: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.base_url}/v2/charge"
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Basic {self.auth_header}"
        }
        
        response = requests.post(url, json=parameter, headers=headers)
        response.raise_for_status()
        return response.json()
    
    async def get_transaction_status(self, order_id: str) -> Dict[str, Any]:
        url = f"{self.base_url}/v2/{order_id}/status"
        headers = {
            "Accept": "application/json",
            "Authorization": f"Basic {self.auth_header}"
        }
        
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()

PRODUCTS = {
    "trial_limited": {
        "name": "Trial Limited (30 day)",
        "basePrice": 0,
        "limitPrice": 10000,
        "isLimited": True,
        "isTrial": True,
        "level": 1,
        "description": "Akses 30 hari dengan jumlah akun terbatas"
    },
    "trial_unlimited": {
        "name": "Trial Unlimited (30 hari)",
        "basePrice": 30000,
        "isLimited": False,
        "isTrial": True,
        "level": 2,
        "description": "Akses 30 hari dengan jumlah akun tidak terbatas"
    },
    "perma_limited": {
        "name": "Permanent Limited",
        "basePrice": 0,
        "limitPrice": 25000,
        "isLimited": True,
        "isTrial": False,
        "level": 3,
        "description": "Akses permanen dengan jumlah akun terbatas"
    },
    "perma_unlimited": {
        "name": "Permanent Unlimited",
        "basePrice": 150000,
        "isLimited": False,
        "isTrial": False,
        "level": 4,
        "description": "Akses permanen dengan jumlah akun tidak terbatas"
    }
}

class PendingOrderManager:
    def __init__(self):
        self.orders_file = os.path.join("data", "pending_orders.json")
        os.makedirs(os.path.dirname(self.orders_file), exist_ok=True)
    
    def save_order(self, order_id: str, order_data: Dict[str, Any]) -> bool:
        try:
            orders = {}
            if os.path.exists(self.orders_file):
                with open(self.orders_file, 'r') as f:
                    orders = json.load(f)
            
            orders[order_id] = order_data
            
            with open(self.orders_file, 'w') as f:
                json.dump(orders, f, indent=2)
            return True
        except Exception as e:
            if config.is_debug:
                print(f"Error saving order: {e}")
            return False
    
    def get_order(self, order_id: str) -> Optional[Dict[str, Any]]:
        try:
            if not os.path.exists(self.orders_file):
                return None
            
            with open(self.orders_file, 'r') as f:
                orders = json.load(f)
            
            return orders.get(order_id)
        except Exception as e:
            if config.is_debug:
                print(f"Error reading order: {e}")
            return None
    
    def delete_order(self, order_id: str) -> bool:
        try:
            if not os.path.exists(self.orders_file):
                return False
            
            with open(self.orders_file, 'r') as f:
                orders = json.load(f)
            
            if order_id not in orders:
                return False
            
            del orders[order_id]
            
            with open(self.orders_file, 'w') as f:
                json.dump(orders, f, indent=2)
            return True
        except Exception as e:
            if config.is_debug:
                print(f"Error deleting order: {e}")
            return False

class BuyCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db
        
        if config.midtrans.get("serverKey") and config.midtrans.get("clientKey"):
            self.midtrans = MidtransClient(
                config.midtrans["serverKey"],
                config.midtrans["clientKey"],
                config.midtrans.get("isProduction", False)
            )
        else:
            self.midtrans = None
        
        self.order_manager = PendingOrderManager()
        self.payment_checks = {}
    
    def calculate_discount(self, current_plan: str) -> float:
        discount_map = {
            "trial_limited": 0.5,
            "trial_unlimited": 0.4,
            "perma_limited": 0.3
        }
        return discount_map.get(current_plan, 0)
    
    def get_remaining_trial_days(self, expires_at: str) -> int:
        if not expires_at:
            return 0
        try:
            expiry = datetime.fromisoformat(expires_at)
            diff = expiry - datetime.now()
            return max(0, diff.days)
        except:
            return 0
    
    def get_days_inactive(self, deactivated_at: str) -> int:
        if not deactivated_at:
            return 0
        try:
            deactivation = datetime.fromisoformat(deactivated_at)
            diff = datetime.now() - deactivation
            return max(0, diff.days)
        except:
            return 0
    
    def get_remaining_days_before_deletion(self, deactivated_at: str) -> int:
        if not deactivated_at:
            return 0
        max_days = 3
        inactive_days = self.get_days_inactive(deactivated_at)
        remaining_days = max_days - inactive_days
        return max(0, remaining_days)
    
    def get_available_upgrades(self, current_plan: str) -> list:
        if not current_plan or current_plan not in PRODUCTS:
            return []
        
        current_level = PRODUCTS[current_plan]["level"]
        return [
            {"key": key, **product}
            for key, product in PRODUCTS.items()
            if product["level"] > current_level
        ]
    
    async def assign_role(self, guild: discord.Guild, user_id: int, plan_type: str, old_plan_type: str = None) -> bool:
        try:
            if not guild:
                return False
            
            member = await guild.fetch_member(user_id)
            if not member:
                return False
            
            global_role_id = 1301011003554926672
            perma_role_id = 1327543532206035076
            trial_role_id = 1327543942190862336
            
            role_mapping = {
                "trial_limited": trial_role_id,
                "trial_unlimited": trial_role_id,
                "perma_limited": perma_role_id,
                "perma_unlimited": perma_role_id
            }
            
            if old_plan_type and old_plan_type in role_mapping:
                old_role = guild.get_role(role_mapping[old_plan_type])
                if old_role and old_role in member.roles:
                    await member.remove_roles(old_role)
            
            global_role = guild.get_role(global_role_id)
            if global_role and global_role not in member.roles:
                await member.add_roles(global_role)
            
            new_role_id = role_mapping.get(plan_type)
            if not new_role_id:
                return False
            
            new_role = guild.get_role(new_role_id)
            if not new_role:
                return False
            
            await member.add_roles(new_role)
            return True
        except Exception as e:
            if config.is_debug:
                print(f"Error assigning role: {e}")
            return False
    
    async def remove_user_roles(self, guild: discord.Guild, user_id: int, plan_type: str) -> bool:
        try:
            if not guild:
                return False
            
            member = await guild.fetch_member(user_id)
            if not member:
                return False
            
            global_role_id = 1301011003554926672
            perma_role_id = 1327543532206035076
            trial_role_id = 1327543942190862336
            
            role_mapping = {
                "trial_limited": trial_role_id,
                "trial_unlimited": trial_role_id,
                "perma_limited": perma_role_id,
                "perma_unlimited": perma_role_id
            }
            
            global_role = guild.get_role(global_role_id)
            if global_role and global_role in member.roles:
                await member.remove_roles(global_role)
            
            specific_role_id = role_mapping.get(plan_type)
            if specific_role_id:
                specific_role = guild.get_role(specific_role_id)
                if specific_role and specific_role in member.roles:
                    await member.remove_roles(specific_role)
            
            return True
        except Exception as e:
            if config.is_debug:
                print(f"Error removing user roles: {e}")
            return False
    
    async def create_qris_payment(self, order_id: str, amount: int, user_id: str) -> Dict[str, Any]:
        if not self.midtrans:
            raise Exception("Midtrans not configured")
        
        parameter = {
            "payment_type": "qris",
            "transaction_details": {
                "order_id": order_id,
                "gross_amount": amount
            },
            "customer_details": {
                "first_name": user_id
            }
        }
        
        try:
            response = await self.midtrans.charge(parameter)
            
            return {
                "orderId": response["order_id"],
                "transactionId": response["transaction_id"],
                "qrCodeUrl": f"https://api.midtrans.com/v2/qris/{response['transaction_id']}/qr-code",
                "status": response["transaction_status"],
                "expiryTime": response["expiry_time"]
            }
        except Exception as e:
            if config.is_debug:
                print(f"Error creating QRIS payment: {e}")
            raise e
    
    async def check_payment_status(self, order_id: str) -> Dict[str, Any]:
        if not self.midtrans:
            raise Exception("Midtrans not configured")
        
        try:
            response = await self.midtrans.get_transaction_status(order_id)
            
            return {
                "orderId": response["order_id"],
                "transactionId": response["transaction_id"],
                "status": response["transaction_status"],
                "amount": response["gross_amount"],
                "paymentType": response["payment_type"],
                "transactionTime": response["transaction_time"]
            }
        except Exception as e:
            if config.is_debug:
                print(f"Error checking payment status: {e}")
            raise e
    
    async def schedule_payment_check(self, order_id: str, interaction: discord.Interaction):
        attempts = 0
        max_attempts = 20
        
        while attempts < max_attempts:
            await asyncio.sleep(30)
            attempts += 1
            
            try:
                order_data = self.order_manager.get_order(order_id)
                if not order_data:
                    break
                
                payment_status = await self.check_payment_status(order_id)
                
                if payment_status["status"] == "settlement":
                    await self.process_successful_payment(order_id, interaction)
                    break
                elif payment_status["status"] == "expire":
                    self.order_manager.delete_order(order_id)
                    
                    try:
                        embed = discord.Embed.from_dict(interaction.message.embeds[0].to_dict())
                        embed.add_field(
                            name="🚀 Status",
                            value="⏰ Payment Expired",
                            inline=True
                        )
                        embed = enhance_embed(embed)
                        
                        await interaction.edit_original_response(
                            embeds=[embed],
                            view=None
                        )
                    except Exception as e:
                        if config.is_debug:
                            print(f"Error updating expired payment: {e}")
                    break
                    
            except Exception as e:
                if config.is_debug:
                    print(f"Error in payment check: {e}")
                if attempts >= max_attempts:
                    break
    
    async def process_successful_payment(self, order_id: str, interaction: discord.Interaction):
        try:
            order_data = self.order_manager.get_order(order_id)
            if not order_data:
                return
            
            user_id = order_data["userId"]
            order_type = order_data["type"]
            plan_type = order_data["planType"]
            account_limit = order_data["accountLimit"]
            current_plan = order_data.get("currentPlan")
            
            user = self.db.get_user_by_id(user_id)
            
            if order_type in ["buy", "buyLimit"]:
                if user and user["subscriptionType"].find("limited") != -1:
                    new_limit = (user.get("accountLimit", 0)) + account_limit
                    self.db.update_user(user_id, {"accountLimit": new_limit})
                else:
                    new_user = {
                        "id": user_id,
                        "username": interaction.user.name,
                        "subscriptionType": plan_type,
                        "accountLimit": account_limit if account_limit > 0 else None,
                        "createdAt": datetime.now().isoformat(),
                        "expiresAt": (datetime.now() + timedelta(days=30)).isoformat() if PRODUCTS[plan_type]["isTrial"] else None,
                        "notes": "Dibeli melalui /buy",
                        "addedBy": str(interaction.client.user.id),
                        "active": True
                    }
                    
                    self.db.add_user(new_user)
                
                await self.assign_role(interaction.guild, int(user_id), plan_type)
                
            elif order_type == "update":
                new_expiry = (datetime.now() + timedelta(days=30)).isoformat()
                self.db.update_user(user_id, {
                    "active": True,
                    "expiresAt": new_expiry
                })
                
                await self.assign_role(interaction.guild, int(user_id), plan_type)
                
            elif order_type == "upgrade":
                update_data = {
                    "subscriptionType": plan_type,
                    "accountLimit": account_limit if account_limit > 0 else None,
                    "expiresAt": (datetime.now() + timedelta(days=30)).isoformat() if PRODUCTS[plan_type]["isTrial"] else None
                }
                
                self.db.update_user(user_id, update_data)
                
                await self.assign_role(interaction.guild, int(user_id), plan_type, current_plan)
                
            elif order_type == "reactivate":
                if not user or user["active"] or not user.get("deactivatedAt"):
                    return
                
                new_expiry = (datetime.now() + timedelta(days=30)).isoformat()
                self.db.update_user(user_id, {
                    "active": True,
                    "expiresAt": new_expiry,
                    "deactivatedAt": None
                })
                
                await self.assign_role(interaction.guild, int(user_id), plan_type)
            
            success_embed_data = {
                "title": "✅ Payment Successful",
                "description": "Langganan Anda telah diaktifkan!",
                "fields": [
                    {
                        "name": "📦 Type Subscribetion",
                        "value": PRODUCTS.get(plan_type, {}).get("name", plan_type),
                        "inline": True
                    },
                    {
                        "name": "📋 Order ID",
                        "value": order_id,
                        "inline": True
                    }
                ],
                "color": 0x00FF00,
                "timestamp": datetime.now().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            success_embed = discord.Embed.from_dict(enhance_embed(success_embed_data))
            
            await interaction.edit_original_response(
                embeds=[success_embed],
                view=None
            )
            
            try:
                owner = await interaction.client.fetch_user(int(config.owner_id))
                notif_embed_data = {
                    "title": "🔔 New Buyer",
                    "description": f"User <@{user_id}> melakukan pembelian",
                    "fields": [
                        {
                            "name": "📦 Type",
                            "value": order_type,
                            "inline": True
                        },
                        {
                            "name": "📊 Subscribetion Type",
                            "value": PRODUCTS.get(plan_type, {}).get("name", plan_type),
                            "inline": True
                        },
                        {
                            "name": "💰 Total",
                            "value": f"{order_data['totalAmount']} IDR",
                            "inline": True
                        }
                    ],
                    "color": 0x00FF00,
                    "timestamp": datetime.now().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                notif_embed = discord.Embed.from_dict(enhance_embed(notif_embed_data))
                await owner.send(embed=notif_embed)
            except Exception as e:
                if config.is_debug:
                    print(f"Error sending owner notification: {e}")
            
            self.order_manager.delete_order(order_id)
            
        except Exception as e:
            if config.is_debug:
                print(f"Error processing successful payment: {e}")

    @app_commands.command(name="buy", description="Beli langganan")
    async def buy(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            
            user_id = str(interaction.user.id)
            user = self.db.get_user_by_id(user_id)
            
            embed_data = {
                "title": "🛒 Buy Menu",
                "color": 0x00FFFF,
                "timestamp": datetime.now().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            if user and user["subscriptionType"] == "perma_unlimited" and user["active"]:
                embed_data["description"] = f"Halo {interaction.user.name}!\n\nAnda telah memiliki subscribetion type tertinggi: **{PRODUCTS[user['subscriptionType']]['name']}**.\n\nTidak ada lagi paket yang tersedia untuk Anda."
                embed_data["color"] = 0x00FF00
                
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            if user and not user["active"] and user["subscriptionType"].startswith("trial_") and user.get("deactivatedAt"):
                days_inactive = self.get_days_inactive(user["deactivatedAt"])
                days_remaining = self.get_remaining_days_before_deletion(user["deactivatedAt"])
                
                if days_inactive <= 3:
                    embed_data["description"] = f"Halo {interaction.user.name}!\n\nSubscribetion type Anda saat ini: **{PRODUCTS.get(user['subscriptionType'], {}).get('name', user['subscriptionType'])}** telah kedaluwarsa pada **{datetime.fromisoformat(user['deactivatedAt']).strftime('%d-%m-%Y %H:%M')}**.\n\nAnda memiliki **{days_remaining} hari** lagi untuk mengaktifkan kembali subscribetion Anda sebelum akun dan semua konfigurasi Anda dihapus secara permanen."
                    embed_data["color"] = 0xFF5555
                    view = ReactivateView(self, user)
                    
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.edit_original_response(embed=embed, view=view)
                    return
            
            view = BuyView(self, user)
            
            if not user:
                embed_data["description"] = "Halo! Anda belum memiliki subscribetion. Silakan pilih paket subscribetion yang Anda inginkan."
            else:
                embed_data["description"] = f"Halo {interaction.user.name}!\n\nAnda saat ini memiliki subscribetion: **{PRODUCTS.get(user['subscriptionType'], {}).get('name', user['subscriptionType'])}**"
                
                if user["subscriptionType"].find("limited") != -1:
                    embed_data["fields"] = [
                        {
                            "name": "📊 Limit Account",
                            "value": str(user.get("accountLimit", 0)),
                            "inline": True
                        }
                    ]
                
                if user["subscriptionType"].find("trial") != -1:
                    remaining_days = self.get_remaining_trial_days(user.get("expiresAt"))
                    if not embed_data.get("fields"):
                        embed_data["fields"] = []
                    embed_data["fields"].append({
                        "name": "⏰ Expiry Time Left",
                        "value": f"{remaining_days} hari",
                        "inline": True
                    })
            
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Error: {str(e)}")
    
    async def show_buy_menu(self, interaction: discord.Interaction, existing_user):
        options = []
        for key, product in PRODUCTS.items():
            description = f"{product['limitPrice']} IDR per limit" if product["isLimited"] else f"{product['basePrice']} IDR"
            emoji = "⏰" if product["isTrial"] else "🎁"
            
            options.append(discord.SelectOption(
                label=product["name"],
                description=description,
                value=key,
                emoji=emoji
            ))
        
        embed_data = {
            "title": "🎁 Select Subscribetion Type",
            "description": "Pilih paket yang ingin Anda beli:",
            "color": 0x00FFFF,
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        
        embed = discord.Embed.from_dict(enhance_embed(embed_data))
        
        select = discord.ui.Select(
            placeholder="Select Subscribetion",
            options=options,
            custom_id="buyProduct_select"
        )
        
        view = ProductSelectView(self, "buy")
        view.add_item(select)
        
        await interaction.edit_original_response(embed=embed, view=view)
    
    async def show_upgrade_menu(self, interaction: discord.Interaction, user: dict):
        upgrades = self.get_available_upgrades(user["subscriptionType"])
        
        if not upgrades:
            await interaction.response.send_message("❌ Tidak ada upgrade yang tersedia untuk paket Anda.", ephemeral=True)
            return
        
        options = []
        for upgrade in upgrades:
            description = f"{upgrade['limitPrice']} IDR per limit" if upgrade["isLimited"] else f"{upgrade['basePrice']} IDR"
            emoji = "⏰" if upgrade["isTrial"] else "🎁"
            
            options.append(discord.SelectOption(
                label=upgrade["name"],
                description=description,
                value=upgrade["key"],
                emoji=emoji
            ))
        
        embed_data = {
            "title": "⬆️ Upgrade Subscribetion",
            "description": "Pilih paket upgrade yang Anda inginkan:",
            "color": 0x00FFFF,
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        
        embed = discord.Embed.from_dict(enhance_embed(embed_data))
        
        select = discord.ui.Select(
            placeholder="Pilih paket upgrade",
            options=options,
            custom_id="upgradeProduct_select"
        )
        
        view = ProductSelectView(self, "upgrade", user)
        view.add_item(select)
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    async def show_payment_confirmation(self, interaction: discord.Interaction, action: str, plan_type: str, account_limit: int, current_plan: str = None):
        product = PRODUCTS[plan_type]
        
        total_price = 0
        if product["isLimited"]:
            total_price = account_limit * product["limitPrice"]
        else:
            total_price = product["basePrice"]
        
        embed_data = {
            "title": "💰 Payment Confirmation",
            "description": "Detail pembelian Anda:",
            "fields": [
                {
                    "name": "📦 Subscribetion Type",
                    "value": product["name"],
                    "inline": True
                },
                {
                    "name": "📊 Limit",
                    "value": str(account_limit) if product["isLimited"] else "Unlimited",
                    "inline": True
                },
                {
                    "name": "💵 Total Price",
                    "value": f"{total_price} IDR",
                    "inline": True
                }
            ],
            "color": 0x00FFFF,
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        
        embed = discord.Embed.from_dict(enhance_embed(embed_data))
        view = PaymentConfirmView(self, action, plan_type, account_limit, total_price, current_plan)
        
        if interaction.response.is_done():
            await interaction.edit_original_response(embed=embed, view=view)
        else:
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    async def show_upgrade_confirmation(self, interaction: discord.Interaction, plan_type: str, account_limit: int, user: dict):
        new_product = PRODUCTS[plan_type]
        current_product = PRODUCTS[user["subscriptionType"]]
        
        discount = self.calculate_discount(user["subscriptionType"])
        
        base_price = 0
        if new_product["isLimited"]:
            base_price = account_limit * new_product["limitPrice"]
        else:
            base_price = new_product["basePrice"]
        
        discount_amount = 0
        if current_product["isLimited"] and user.get("accountLimit"):
            discount_amount = int(user["accountLimit"] * current_product["limitPrice"] * discount)
        else:
            discount_amount = int(current_product["basePrice"] * discount)
        
        final_price = max(0, base_price - discount_amount)
        
        embed_data = {
            "title": "⬆️ Upgrade Confirmation",
            "description": "Detail upgrade langganan Anda:",
            "fields": [
                {
                    "name": "📦 Previous Subscribetion",
                    "value": current_product["name"],
                    "inline": True
                },
                {
                    "name": "📦 New Subscribetion",
                    "value": new_product["name"],
                    "inline": True
                },
                {
                    "name": "📊 Limit",
                    "value": str(account_limit) if new_product["isLimited"] else "Unlimited",
                    "inline": True
                },
                {
                    "name": "💰 Normal Price",
                    "value": f"{base_price} IDR",
                    "inline": True
                },
                {
                    "name": "🎁 Discount",
                    "value": f"{discount_amount} IDR ({int(discount * 100)}%)",
                    "inline": True
                },
                {
                    "name": "💵 Price Total",
                    "value": f"{final_price} IDR",
                    "inline": True
                }
            ],
            "color": 0x00FFFF,
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        
        embed = discord.Embed.from_dict(enhance_embed(embed_data))
        view = PaymentConfirmView(self, "upgrade", plan_type, account_limit, final_price, user["subscriptionType"])
        
        if interaction.response.is_done():
            await interaction.edit_original_response(embed=embed, view=view)
        else:
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    async def show_update_confirmation(self, interaction: discord.Interaction, user: dict):
        product = PRODUCTS[user["subscriptionType"]]
        total_price = product["limitPrice"] * (user.get("accountLimit", 0)) if product["isLimited"] else product["basePrice"]
        
        embed_data = {
            "title": "🔄 Update Subscription",
            "description": "Detail update langganan Anda:",
            "fields": [
                {
                    "name": "📦 Paket Saat Ini",
                    "value": product["name"],
                    "inline": True
                },
                {
                    "name": "💰 Harga Update",
                    "value": f"{total_price} IDR",
                    "inline": True
                },
                {
                    "name": "⏰ Waktu Baru",
                    "value": "30 hari",
                    "inline": True
                }
            ],
            "color": 0x00FFFF,
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        
        embed = discord.Embed.from_dict(enhance_embed(embed_data))
        view = PaymentConfirmView(self, "update", user["subscriptionType"], user.get("accountLimit", 0), total_price)
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    async def show_reactivation_payment(self, interaction: discord.Interaction, user: dict):
        if not user or not user["subscriptionType"].startswith("trial_") or not user.get("deactivatedAt"):
            await interaction.response.send_message("❌ Fitur ini hanya untuk pengguna trial yang telah dinonaktifkan.", ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        product = PRODUCTS[user["subscriptionType"]]
        total_price = 0
        
        if user["subscriptionType"] == "trial_limited" and user.get("accountLimit"):
            total_price = user["accountLimit"] * product["limitPrice"]
        elif user["subscriptionType"] == "trial_unlimited":
            total_price = product["basePrice"]
        
        embed_data = {
            "title": "🔄 Subscription Reactivation",
            "description": "Detail reaktivasi langganan Anda:",
            "fields": [
                {
                    "name": "📦 Paket",
                    "value": product["name"],
                    "inline": True
                },
                {
                    "name": "🔢 Limit",
                    "value": str(user.get("accountLimit", 0)) if user["subscriptionType"].find("limited") != -1 else "Unlimited",
                    "inline": True
                },
                {
                    "name": "💰 Total Harga",
                    "value": f"{total_price} IDR",
                    "inline": True
                },
                {
                    "name": "⏰ Durasi",
                    "value": "30 hari",
                    "inline": True
                }
            ],
            "color": 0x00FFFF,
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        
        embed = discord.Embed.from_dict(enhance_embed(embed_data))
        view = PaymentConfirmView(self, "reactivate", user["subscriptionType"], user.get("accountLimit", 0), total_price)
        
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

class BuyView(discord.ui.View):
    def __init__(self, command_instance, user):
        super().__init__(timeout=300)
        self.command = command_instance
        self.user = user
        
        if not user:
            self.add_item(BuyButton(label="🛍️ Buy Langganan", style=discord.ButtonStyle.primary))
        else:
            if user["subscriptionType"].find("limited") != -1:
                self.add_item(BuyButton(label="🛍️ Buy Limit", style=discord.ButtonStyle.primary, action="buyLimit"))
            
            if user["subscriptionType"].find("trial") != -1:
                remaining_days = self.command.get_remaining_trial_days(user.get("expiresAt"))
                if remaining_days <= 7:
                    self.add_item(BuyButton(label="🔄 Update Langganan", style=discord.ButtonStyle.secondary, action="update"))
            
            if user["subscriptionType"] != "perma_unlimited" and user.get("addedBy") != "redeem":
                self.add_item(BuyButton(label="⬆️ Upgrade Langganan", style=discord.ButtonStyle.success, action="upgrade"))

class ReactivateView(discord.ui.View):
    def __init__(self, command_instance, user):
        super().__init__(timeout=300)
        self.command = command_instance
        self.user = user
        
        self.add_item(BuyButton(label="🔄 Reaktivasi Langganan", style=discord.ButtonStyle.success, action="reactivate"))
        self.add_item(BuyButton(label="🗑️ Hapus Akun & Data", style=discord.ButtonStyle.danger, action="delete"))

class BuyButton(discord.ui.Button):
    def __init__(self, label: str, style: discord.ButtonStyle, action: str = "buy"):
        super().__init__(label=label, style=style)
        self.action = action
    
    async def callback(self, interaction: discord.Interaction):
        try:
            view = self.view
            command = view.command
            user = view.user
            
            if self.action == "buy":
                await interaction.response.defer()
                await command.show_buy_menu(interaction, user)
            elif self.action == "buyLimit":
                if not user or not user["subscriptionType"].find("limited") != -1:
                    await interaction.response.send_message("❌ Fitur ini hanya untuk pengguna dengan paket limited.", ephemeral=True)
                    return
                await interaction.response.send_modal(LimitModal(command, user["subscriptionType"], "buyLimit"))
            elif self.action == "update":
                if not user or not user["subscriptionType"].find("trial") != -1:
                    await interaction.response.send_message("❌ Fitur ini hanya untuk pengguna dengan paket trial.", ephemeral=True)
                    return
                
                remaining_days = command.get_remaining_trial_days(user.get("expiresAt"))
                if remaining_days > 7:
                    await interaction.response.send_message(f"❌ Update langganan hanya bisa dilakukan jika sisa trial ≤ 7 hari. Sisa trial Anda: {remaining_days} hari.", ephemeral=True)
                    return
                
                await command.show_update_confirmation(interaction, user)
            elif self.action == "upgrade":
                if not user:
                    await interaction.response.send_message("❌ Anda belum memiliki langganan untuk di-upgrade.", ephemeral=True)
                    return
                
                if user.get("addedBy") == "redeem":
                    await interaction.response.send_message("❌ Anda tidak dapat melakukan upgrade karena Anda mendaftar menggunakan kode redeem.", ephemeral=True)
                    return
                
                await command.show_upgrade_menu(interaction, user)
            elif self.action == "reactivate":
                await command.show_reactivation_payment(interaction, user)
            elif self.action == "delete":
                await interaction.response.send_modal(DeleteConfirmModal(command, user))
        except Exception as e:
            await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)

class ProductSelectView(discord.ui.View):
    def __init__(self, command_instance, action_type, user=None):
        super().__init__(timeout=300)
        self.command = command_instance
        self.action_type = action_type
        self.user = user
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.data["component_type"] == 3:
            custom_id = interaction.data["custom_id"]
            values = interaction.data["values"]
            
            if custom_id == "buyProduct_select":
                await self.handle_product_select(interaction, values[0], "buy")
            elif custom_id == "upgradeProduct_select":
                await self.handle_product_select(interaction, values[0], "upgrade")
            
            return True
        return False
    
    async def handle_product_select(self, interaction: discord.Interaction, selected_value: str, action: str):
        try:
            user_id = str(interaction.user.id)
            user = self.command.db.get_user_by_id(user_id)
            
            if user and user["subscriptionType"] == "perma_unlimited" and user["active"]:
                await interaction.response.defer()
                await interaction.followup.send("⭐ Anda telah memiliki langganan tertinggi dan tidak memerlukan upgrade lagi.", ephemeral=True)
                return
            
            if not PRODUCTS.get(selected_value):
                await interaction.response.defer()
                await interaction.edit_original_response(
                    content=f"❌ Terjadi kesalahan: Paket \"{selected_value}\" tidak ditemukan.",
                    embeds=[],
                    view=None
                )
                return
            
            product = PRODUCTS[selected_value]
            
            if product["isLimited"]:
                await interaction.response.send_modal(LimitModal(self.command, selected_value, action, user))
            else:
                await interaction.response.defer()
                if action == "upgrade":
                    await self.command.show_upgrade_confirmation(interaction, selected_value, 0, user)
                else:
                    await self.command.show_payment_confirmation(interaction, action, selected_value, 0)
        except Exception as e:
            if not interaction.response.is_done():
                await interaction.response.defer()
            await interaction.edit_original_response(
                content=f"❌ Terjadi kesalahan: {str(e)}",
                embeds=[],
                view=None
            )

class LimitModal(discord.ui.Modal):
    def __init__(self, command_instance, plan_type, action, user=None):
        super().__init__(title=f"Set Limit - {PRODUCTS.get(plan_type, {}).get('name', plan_type)}")
        self.command = command_instance
        self.plan_type = plan_type
        self.action = action
        self.user = user
        
        self.limit_input = discord.ui.TextInput(
            label="Jumlah Limit",
            placeholder="Masukkan angka (1-10)",
            style=discord.TextStyle.short,
            required=True,
            min_length=1,
            max_length=2
        )
        self.add_item(self.limit_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            account_limit = int(self.limit_input.value)
            
            if account_limit < 1 or account_limit > 10:
                await interaction.response.send_message("❌ Mohon masukkan angka yang valid antara 1 dan 10.", ephemeral=True)
                return
            
            if not PRODUCTS.get(self.plan_type):
                await interaction.response.send_message(f"❌ Terjadi kesalahan: Paket \"{self.plan_type}\" tidak ditemukan.", ephemeral=True)
                return
            
            if self.action in ["buy", "buyLimit"]:
                await interaction.response.send_message("Sedang memproses...", ephemeral=True)
                await self.command.show_payment_confirmation(interaction, self.action, self.plan_type, account_limit)
            elif self.action == "upgrade":
                if self.user and self.user.get("addedBy") == "redeem":
                    await interaction.response.send_message("❌ Anda tidak dapat melakukan upgrade karena Anda mendaftar menggunakan kode redeem.", ephemeral=True)
                    return
                
                await interaction.response.send_message("Sedang memproses...", ephemeral=True)
                await self.command.show_upgrade_confirmation(interaction, self.plan_type, account_limit, self.user)
        except ValueError:
            await interaction.response.send_message("❌ Mohon masukkan angka yang valid.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)

class DeleteConfirmModal(discord.ui.Modal):
    def __init__(self, command_instance, user):
        super().__init__(title="Hapus Akun & Data")
        self.command = command_instance
        self.user = user
        
        self.confirm_input = discord.ui.TextInput(
            label='Ketik "delete" untuk menghapus secara permanen',
            placeholder="delete",
            style=discord.TextStyle.short,
            required=True
        )
        self.add_item(self.confirm_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            if self.confirm_input.value.lower() != "delete":
                await interaction.response.send_message('❌ Konfirmasi gagal. Ketik "delete" untuk konfirmasi penghapusan.', ephemeral=True)
                return
            
            await interaction.response.defer(ephemeral=True)
            
            delete_embed_data = {
                "title": "⏳ Deletion In Progress",
                "description": f"Mulai menghapus **{self.user['username']}** dan semua data mereka...",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            delete_embed = discord.Embed.from_dict(enhance_embed(delete_embed_data))
            await interaction.edit_original_response(embed=delete_embed)
            
            await asyncio.sleep(2)
            
            user_id = self.user["id"]
            account_count = self.command.db.get_account_count_for_user(user_id)
            
            await self.command.remove_user_roles(interaction.guild, int(user_id), self.user["subscriptionType"])
            
            success = self.command.db.delete_user(user_id)
            
            if success:
                success_embed_data = {
                    "title": "✅ User Successfully Deleted",
                    "description": f"Pengguna **{self.user['username']}** dan semua data mereka telah dihapus.",
                    "fields": [
                        {
                            "name": "🆔 ID Pengguna",
                            "value": user_id,
                            "inline": True
                        },
                        {
                            "name": "📊 Akun Dihapus",
                            "value": str(account_count),
                            "inline": True
                        }
                    ],
                    "color": 0x00FF00,
                    "timestamp": datetime.now().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                success_embed = discord.Embed.from_dict(enhance_embed(success_embed_data))
                await interaction.edit_original_response(embed=success_embed)
            else:
                error_embed_data = {
                    "title": "❌ Deletion Failed",
                    "description": "Sistem mengalami kesalahan saat menghapus data pengguna.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
                await interaction.edit_original_response(embed=error_embed)
                
        except Exception as e:
            error_embed_data = {
                "title": "❌ Error During Deletion",
                "description": "Sistem mengalami kesalahan tak terduga selama proses penghapusan.",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
            await interaction.edit_original_response(embed=error_embed)

class PaymentConfirmView(discord.ui.View):
    def __init__(self, command_instance, action, plan_type, account_limit, total_price, current_plan=None):
        super().__init__(timeout=300)
        self.command = command_instance
        self.action = action
        self.plan_type = plan_type
        self.account_limit = account_limit
        self.total_price = total_price
        self.current_plan = current_plan
        
        confirm_button = discord.ui.Button(label="💳 Bayar", style=discord.ButtonStyle.success)
        confirm_button.callback = self.confirm_payment
        self.add_item(confirm_button)
        
        cancel_button = discord.ui.Button(label="❌ Batal", style=discord.ButtonStyle.danger)
        cancel_button.callback = self.cancel_payment
        self.add_item(cancel_button)
    
    async def confirm_payment(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        try:
            user_id = str(interaction.user.id)
            order_id = f"ORDER-{user_id}-{int(datetime.now().timestamp())}"
            
            payment_result = await self.command.create_qris_payment(order_id, self.total_price, user_id)
            
            order_data = {
                "userId": user_id,
                "type": self.action,
                "planType": self.plan_type,
                "accountLimit": self.account_limit,
                "totalAmount": self.total_price,
                "currentPlan": self.current_plan,
                "createdAt": datetime.now().isoformat(),
                "status": "pending"
            }
            
            self.command.order_manager.save_order(order_id, order_data)
            
            expiry_timestamp = int(datetime.fromisoformat(payment_result["expiryTime"]).timestamp())
            
            payment_embed_data = {
                "title": "💳 QRIS Payment",
                "description": f"Silakan scan QR code untuk membayar **{self.total_price} IDR**",
                "fields": [
                    {
                        "name": "📝 Order ID",
                        "value": order_id,
                        "inline": True
                    },
                    {
                        "name": "⏰ Kadaluarsa",
                        "value": f"<t:{expiry_timestamp}:R>",
                        "inline": True
                    }
                ],
                "image": {"url": payment_result["qrCodeUrl"]},
                "footer": {
                    "text": "FuHuu Auto Post",
                    "icon_url": config.images.get("footerIcon")
                }
            }
            
            payment_embed = discord.Embed.from_dict(payment_embed_data)
            check_view = PaymentCheckView(self.command, order_id)
            
            await interaction.edit_original_response(embed=payment_embed, view=check_view)
            
            asyncio.create_task(self.command.schedule_payment_check(order_id, interaction))
            
        except Exception as e:
            await interaction.edit_original_response(
                content=f"❌ Error membuat pembayaran: {str(e)}",
                embed=None,
                view=None
            )
    
    async def cancel_payment(self, interaction: discord.Interaction):
        await interaction.response.send_message("❌ Pembelian dibatalkan.", ephemeral=True)

class PaymentCheckView(discord.ui.View):
    def __init__(self, command_instance, order_id):
        super().__init__(timeout=3600)
        self.command = command_instance
        self.order_id = order_id
        
        check_button = discord.ui.Button(label="🔄 Cek Status Pembayaran", style=discord.ButtonStyle.primary)
        check_button.callback = self.check_payment
        self.add_item(check_button)
    
    async def check_payment(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        try:
            order_data = self.command.order_manager.get_order(self.order_id)
            
            if not order_data:
                await interaction.edit_original_response(
                    content="❌ Order tidak ditemukan.",
                    embed=None,
                    view=None
                )
                return
            
            payment_status = await self.command.check_payment_status(self.order_id)
            
            if payment_status["status"] == "settlement":
                await self.command.process_successful_payment(self.order_id, interaction)
            else:
                current_embed = interaction.message.embeds[0]
                embed_dict = current_embed.to_dict()
                
                if not embed_dict.get("fields"):
                    embed_dict["fields"] = []
                
                status_field = {
                    "name": "📊 Status",
                    "value": "⏳ Menunggu pembayaran" if payment_status["status"] == "pending" else "❌ Pembayaran gagal",
                    "inline": True
                }
                
                existing_status_field = None
                for i, field in enumerate(embed_dict["fields"]):
                    if field["name"] == "📊 Status":
                        existing_status_field = i
                        break
                
                if existing_status_field is not None:
                    embed_dict["fields"][existing_status_field] = status_field
                else:
                    embed_dict["fields"].append(status_field)
                
                updated_embed = discord.Embed.from_dict(embed_dict)
                
                await interaction.edit_original_response(
                    embed=updated_embed,
                    view=self
                )
                
        except Exception as e:
            await interaction.edit_original_response(
                content=f"❌ Error mengecek pembayaran: {str(e)}",
                embed=None,
                view=None
            )

async def setup(bot):
    await bot.add_cog(BuyCommand(bot))