import discord
from discord.ext import commands
from datetime import datetime, timezone, timedelta
from config import config
import database

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

class StopConfirmView(discord.ui.View):
    def __init__(self, user_id):
        super().__init__(timeout=60)
        self.user_id = user_id

    @discord.ui.button(label="Ya, Hentikan Semua", style=discord.ButtonStyle.danger, emoji="🛑")
    async def confirm_stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
            return

        await interaction.response.defer()
        
        try:
            result = await database.db.force_stop_all_services(hard_stop=True)
            
            if result.get('success'):
                embed_data = {
                    "title": "✅ All Services Stopped",
                    "description": f"Berhasil menghentikan {result.get('totalStopped', 0)} layanan secara paksa.",
                    "fields": [
                        {"name": "📊 Channels Stopped", "value": str(result.get('channelsStopped', 0)), "inline": True},
                        {"name": "👥 Users Processed", "value": str(result.get('usersProcessed', 0)), "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                
                await interaction.followup.edit_message(interaction.message.id, embeds=[embed], view=None)
            else:
                embed_data = {
                    "title": "⚠️ Stop Error",
                    "description": f"Terjadi error: {result.get('error', 'Unknown error')}",
                    "color": 0xFF0000,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                
                await interaction.followup.edit_message(interaction.message.id, embeds=[embed], view=None)
        except Exception as e:
            embed_data = {
                "title": "❌ Error",
                "description": f"Terjadi kesalahan: {str(e)}",
                "color": 0xFF0000,
                "timestamp": get_wib_time().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            
            await interaction.followup.edit_message(interaction.message.id, embeds=[embed], view=None)

    @discord.ui.button(label="Batal", style=discord.ButtonStyle.secondary, emoji="❌")
    async def cancel_stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Anda tidak dapat menggunakan kontrol ini.", ephemeral=True)
            return

        embed_data = {
            "title": "❌ Cancelled",
            "description": "Perintah dibatalkan. Tidak ada layanan yang dihentikan.",
            "color": 0xFF0000,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        enhance_embed(embed_data)
        embed = discord.Embed.from_dict(embed_data)
        
        await interaction.response.edit_message(embeds=[embed], view=None)

    async def on_timeout(self):
        embed_data = {
            "title": "⏰ Timeout",
            "description": "Konfirmasi penghentian layanan telah habis waktu. Tidak ada layanan yang dihentikan.",
            "color": 0xFFAA00,
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        enhance_embed(embed_data)
        embed = discord.Embed.from_dict(embed_data)
        
        try:
            await self.message.edit(embeds=[embed], view=None)
        except:
            pass

class StopCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="stop", description="Menghentikan semua layanan bot secara paksa")
    async def stop(self, interaction: discord.Interaction):
        if interaction.user.id != int(config.owner_id):
            await interaction.response.send_message("⛔ Perintah ini dibatasi hanya untuk pemilik bot.", ephemeral=True)
            return

        embed_data = {
            "title": "⚠️ Service Stop Confirmation",
            "description": "Anda akan menghentikan **SEMUA** layanan yang sedang berjalan, termasuk:\n\n"
                          "• Semua channel posting aktif\n"
                          "• Semua auto reply yang berjalan\n"
                          "• Semua koneksi selfbot\n\n"
                          "**Apakah Anda yakin ingin melanjutkan?**",
            "color": 0xFFAA00,
            "timestamp": get_wib_time().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        enhance_embed(embed_data)
        embed = discord.Embed.from_dict(embed_data)
        
        view = StopConfirmView(interaction.user.id)
        
        await interaction.response.send_message(embeds=[embed], view=view, ephemeral=True)
        
        view.message = await interaction.original_response()

async def setup(bot):
    await bot.add_cog(StopCommand(bot))