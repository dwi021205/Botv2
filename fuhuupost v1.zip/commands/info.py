import discord
from discord.ext import commands
from discord import app_commands
import psutil
import asyncio
import platform
import sys
import time
import threading
import warnings
from datetime import datetime
from typing import Dict, Any
from config import config
from database import enhance_embed
import speedtest

warnings.filterwarnings("ignore", category=ResourceWarning)
warnings.filterwarnings("ignore", message=".*SSL.*")
warnings.filterwarnings("ignore", message=".*Unverified HTTPS request.*")

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

def format_uptime(seconds: float) -> str:
    days = int(seconds // 86400)
    hours = int((seconds % 86400) // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    
    return f"{days}h {hours}j {minutes}m {secs}d"

def get_system_info() -> Dict[str, Any]:
    try:
        import psutil
        
        cpu_percent = psutil.cpu_percent(interval=1)
        
        memory = psutil.virtual_memory()
        ram_usage_gb = round(memory.used / (1024**3), 2)
        
        disk = psutil.disk_usage('/')
        storage_usage_gb = round(disk.used / (1024**3), 2)
        
        system_name = platform.system()
        system_version = platform.version()
        
        boot_time = psutil.boot_time()
        current_time = time.time()
        uptime_seconds = current_time - boot_time
        
        days = int(uptime_seconds // 86400)
        hours = int((uptime_seconds % 86400) // 3600)
        minutes = int((uptime_seconds % 3600) // 60)
        secs = int(uptime_seconds % 60)
        
        parts = []
        if days > 0:
            parts.append(f"{days} Hari")
        if hours > 0:
            parts.append(f"{hours} Jam")
        if minutes > 0:
            parts.append(f"{minutes} Menit")
        if secs > 0 or not parts:
            parts.append(f"{secs} Detik")
        
        system_uptime = ' '.join(parts)
        
        return {
            'system': f"{system_name} {system_version}",
            'ram_usage': ram_usage_gb,
            'storage_usage': storage_usage_gb,
            'cpu_usage': cpu_percent,
            'system_uptime': system_uptime
        }
    except Exception as e:
        return {
            'system': 'Unknown',
            'ram_usage': 0,
            'storage_usage': 0,
            'cpu_usage': 0,
            'system_uptime': 'Unknown'
        }

def test_speed() -> Dict[str, Any]:
    try:
        s = speedtest.Speedtest()
        s.get_best_server()
        
        ping = s.results.ping
        download_speed = s.download() / 1000000
        upload_speed = s.upload() / 1000000
        
        return {
            'success': True,
            'ping': round(ping, 1),
            'download': round(download_speed, 2),
            'upload': round(upload_speed, 2)
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'ping': 0,
            'download': 0,
            'upload': 0
        }

async def get_network_info() -> Dict[str, Any]:
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, test_speed)
        
        return {
            'ping': {
                'success': result['success'],
                'avg': result.get('ping', 0),
                'error': result.get('error', '')
            },
            'download': {
                'success': result['success'],
                'speed': result.get('download', 0),
                'error': result.get('error', '')
            },
            'upload': {
                'success': result['success'],
                'speed': result.get('upload', 0),
                'error': result.get('error', '')
            }
        }
    except Exception as e:
        return {
            'ping': {'success': False, 'error': str(e)},
            'download': {'success': False, 'error': str(e)},
            'upload': {'success': False, 'error': str(e)}
        }

async def get_bot_statistics() -> str:
    try:
        cpu_percent = psutil.cpu_percent(interval=1)
        
        memory = psutil.virtual_memory()
        used_memory_mb = memory.used / 1024 / 1024
        total_memory_mb = memory.total / 1024 / 1024
        memory_percentage = (used_memory_mb / total_memory_mb) * 100
        
        boot_time = psutil.boot_time()
        system_uptime = format_uptime(time.time() - boot_time)
        
        bot_start_time = getattr(get_bot_statistics, 'start_time', time.time())
        bot_uptime = format_uptime(time.time() - bot_start_time)
        
        try:
            network_info = await asyncio.wait_for(get_network_info(), timeout=30.0)
        except asyncio.TimeoutError:
            network_info = {
                'ping': {'success': False, 'error': 'Timeout'},
                'download': {'success': False, 'error': 'Timeout'},
                'upload': {'success': False, 'error': 'Timeout'}
            }
        
        ping_text = "❌ Gagal"
        if network_info['ping']['success']:
            ping_data = network_info['ping']
            ping_text = f"🟢 {ping_data['avg']}ms"
        elif 'error' in network_info['ping']:
            error_msg = network_info['ping']['error']
            if len(error_msg) > 30:
                error_msg = error_msg[:30] + "..."
            ping_text = f"❌ {error_msg}"
        
        download_text = "❌ Gagal"
        if network_info['download']['success']:
            download_text = f"🟢 {network_info['download']['speed']} Mbps"
        elif 'error' in network_info['download']:
            error_msg = network_info['download']['error']
            if len(error_msg) > 20:
                error_msg = error_msg[:20] + "..."
            download_text = f"❌ {error_msg}"
        
        upload_text = "❌ Gagal"
        if network_info['upload']['success']:
            upload_text = f"🟢 {network_info['upload']['speed']} Mbps"
        elif 'error' in network_info['upload']:
            error_msg = network_info['upload']['error']
            if len(error_msg) > 20:
                error_msg = error_msg[:20] + "..."
            upload_text = f"❌ {error_msg}"
        
        return (f"🖥️ Penggunaan CPU: {cpu_percent:.2f}%\n"
                f"💾 Penggunaan Memori: {used_memory_mb:.2f}MB / {total_memory_mb:.2f}MB ({memory_percentage:.2f}%)\n"
                f"🕒 Waktu Aktif Sistem: {system_uptime}\n"
                f"⏱️ Waktu Aktif Bot: {bot_uptime}\n"
                f"🌐 Ping: {ping_text}\n"
                f"⬇️ Download: {download_text}\n"
                f"⬆️ Upload: {upload_text}")
    except Exception as e:
        return f"Error mendapatkan statistik: {e}"

class InfoCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db
        
        get_bot_statistics.start_time = time.time()
    
    @app_commands.command(name="info", description="Menampilkan informasi tentang langganan dan status bot Anda")
    async def info(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            
            user_id = str(interaction.user.id)
            is_owner = user_id == config.owner_id
            
            user = self.db.get_user_by_id(user_id)
            
            user_info_text = ""
            
            if not user:
                user_info_text = "❌ Anda tidak terdaftar dalam database. Gunakan `/buy` untuk membeli langganan."
            else:
                has_active_subscription = self.db.has_active_subscription(user_id)
                
                user_info_text = f"👤 Nama Pengguna: {user['username']}\n"
                user_info_text += f"🆔 ID Pengguna: {user_id}\n"
                user_info_text += f"📅 Terdaftar pada: {datetime.fromisoformat(user['createdAt']).strftime('%Y-%m-%d %H:%M:%S')}\n"
                user_info_text += f"📊 Langganan: {user['subscriptionType']}\n"
                user_info_text += f"✅ Status: {'Aktif' if user['active'] else 'Tidak Aktif'}\n"
                
                if user.get('expiresAt'):
                    try:
                        expiry_date = datetime.fromisoformat(user['expiresAt'])
                        user_info_text += f"⏱️ Berakhir pada: {expiry_date.strftime('%Y-%m-%d %H:%M:%S')}\n"
                    except:
                        pass
                
                if user.get('accountLimit') is not None:
                    account_count = self.db.get_account_count_for_user(user_id)
                    user_info_text += f"📈 Akun: {account_count}/{user['accountLimit']}\n"
                else:
                    account_count = self.db.get_account_count_for_user(user_id)
                    user_info_text += f"📈 Akun: {account_count} (Tidak Terbatas)\n"
                
                if user.get('notes'):
                    user_info_text += f"📝 Catatan: {user['notes']}\n"
            
            try:
                bot_stats_text = await asyncio.wait_for(get_bot_statistics(), timeout=35.0)
            except asyncio.TimeoutError:
                bot_stats_text = "⚠️ Network test timeout - silakan coba lagi"
            except Exception as e:
                bot_stats_text = f"❌ Error getting statistics: {str(e)}"
            
            embed_data = {
                "title": "ℹ️ Information",
                "color": 0x3498db,
                "fields": [
                    {
                        "name": "📌 Informasi Pengguna",
                        "value": user_info_text,
                        "inline": False
                    },
                    {
                        "name": "🤖 Statistik Bot & Network",
                        "value": bot_stats_text,
                        "inline": False
                    }
                ],
                "timestamp": datetime.now().isoformat(),
                "footer": {
                    "text": f"Diminta oleh {interaction.user.name} • FuHuu Auto Post",
                    "icon_url": str(interaction.user.display_avatar.url) if interaction.user.display_avatar else None
                }
            }
            
            if is_owner:
                total_users = len(self.db.load_users())
                total_accounts = sum(self.db.get_account_count_for_user(user['id']) for user in self.db.load_users())
                active_channels = 0
                for user_data in self.db.load_users():
                    accounts = self.db.load_accounts_for_user(user_data['id'])
                    for account in accounts:
                        if account.get("channels"):
                            active_channels += len([ch for ch in account["channels"] if ch.get("status") == "online"])
                
                owner_stats = f"👥 Total Pengguna: {total_users}\n📊 Total Akun: {total_accounts}\n🟢 Channel Aktif: {active_channels}"
                embed_data["fields"].append({
                    "name": "👑 Statistik Owner",
                    "value": owner_stats,
                    "inline": False
                })
            
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

async def setup(bot):
    await bot.add_cog(InfoCommand(bot))