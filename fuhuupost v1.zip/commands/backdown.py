import discord
from discord.ext import commands
import os
import tempfile
import aiohttp
from datetime import datetime, timezone, timedelta
from config import config

WIB = timezone(timedelta(hours=7))

def get_wib_time():
    return datetime.now(WIB)

def enhance_embed(embed_data):
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

def format_file_size(bytes_size):
    if bytes_size < 1024:
        return f"{bytes_size} bytes"
    elif bytes_size < 1024 * 1024:
        return f"{bytes_size / 1024:.2f} KB"
    else:
        return f"{bytes_size / (1024 * 1024):.2f} MB"

async def download_latest_backup():
    try:
        headers = {
            'Authorization': f'token {config.github["token"]}',
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'Discord-Bot-Backup'
        }
        
        url = f'https://api.github.com/repos/{config.github["owner"]}/{config.github["repo"]}/contents/backups'
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as response:
                if response.status != 200:
                    if response.status == 404:
                        raise Exception('Tidak ada file backup yang ditemukan')
                    response_text = await response.text()
                    raise Exception(f"Failed to fetch backup list: {response.status} - {response_text}")
                
                files = await response.json()
                
                if not files or len(files) == 0:
                    raise Exception('Tidak ada file backup yang ditemukan')
                
                files.sort(key=lambda x: x['name'], reverse=True)
                latest_file = files[0]
                
                async with session.get(latest_file['download_url'], headers=headers) as download_response:
                    if download_response.status != 200:
                        response_text = await download_response.text()
                        raise Exception(f"Failed to download backup: {download_response.status} - {response_text}")
                    
                    file_content = await download_response.read()
                    
                    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.zip')
                    temp_file.write(file_content)
                    temp_file.close()
                    
                    return {
                        'success': True,
                        'filename': latest_file['name'],
                        'size': format_file_size(latest_file['size']),
                        'path': temp_file.name
                    }
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

class BDownloadCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="backdown", description="Mengunduh backup terbaru dari GitHub Repository")
    async def backdown(self, interaction: discord.Interaction):
        if interaction.user.id != int(config.owner_id):
            await interaction.response.send_message("❌ Perintah ini dibatasi hanya untuk pemilik bot.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)
        
        try:
            download_result = await download_latest_backup()
            
            if download_result['success']:
                embed_data = {
                    "title": "✅ Backup Downloaded Successfully",
                    "description": "Backup terbaru telah diunduh dari GitHub",
                    "fields": [
                        {"name": "📁 File Name", "value": download_result['filename'], "inline": True},
                        {"name": "📊 File Size", "value": download_result['size'], "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                
                file = discord.File(download_result['path'], filename=download_result['filename'])
                
                await interaction.followup.send(embeds=[embed], file=file)
                
                os.unlink(download_result['path'])
            else:
                embed_data = {
                    "title": "❌ Download Failed",
                    "description": "Terjadi kesalahan saat mengunduh backup",
                    "fields": [
                        {"name": "⚠️ Error Details", "value": download_result['error'], "inline": False}
                    ],
                    "color": 0xFF0000,
                    "timestamp": get_wib_time().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                
                await interaction.followup.send(embeds=[embed])
        except Exception as e:
            embed_data = {
                "title": "❌ Download Failed",
                "description": "Terjadi kesalahan saat mengunduh backup",
                "fields": [
                    {"name": "⚠️ Error Details", "value": str(e), "inline": False}
                ],
                "color": 0xFF0000,
                "timestamp": get_wib_time().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            
            await interaction.followup.send(embeds=[embed])

async def setup(bot):
    await bot.add_cog(BDownloadCommand(bot))