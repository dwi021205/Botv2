import discord
from discord.ext import commands
from discord import app_commands
import re
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from config import config
from database import enhance_embed

class EditUserCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db

    @app_commands.command(name="edit_user", description="Edit detail langganan pengguna")
    async def edit_user(self, interaction: discord.Interaction):
        if str(interaction.user.id) != config.owner_id:
            await interaction.response.send_message(
                "⛔ Perintah ini dibatasi hanya untuk pemilik bot.", 
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        
        try:
            embed, view = await self.generate_user_select_page(0)
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

    def smart_search(self, users: List[Dict], query: str) -> List[Dict]:
        if not query or query.strip() == '':
            return users
        
        search_query = query.lower().strip()
        search_words = search_query.split()
        
        filtered_users = []
        for user in users:
            username = user['username'].lower()
            
            if username == search_query:
                filtered_users.append((user, 100))
                continue
            
            if search_query in username:
                filtered_users.append((user, 90))
                continue
                
            username_words = re.split(r'[-_\s]+', username)
            match_count = sum(1 for word in search_words 
                            if any(word in user_word for user_word in username_words))
            
            if match_count > 0:
                score = match_count * 10
                if username.startswith(search_query):
                    score += 50
                filtered_users.append((user, score))
        
        filtered_users.sort(key=lambda x: x[1], reverse=True)
        return [user for user, score in filtered_users]

    async def generate_user_select_page(self, page: int = 0, search_query: str = '') -> tuple:
        users = self.db.load_users()
        
        if len(users) == 0:
            embed_data = {
                "title": "✏️ Edit User",
                "description": "Tidak ada pengguna yang terdaftar.",
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            return embed, None
        
        if search_query:
            users = self.smart_search(users, search_query)
        
        if len(users) == 0:
            embed_data = {
                "title": "✏️ Edit User",
                "description": f'Tidak ditemukan pengguna dengan username "{search_query}". Gunakan tombol pencarian untuk mencoba lagi.',
                "color": 0xFFAA00,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            view = EditUserView(self, page, search_query, [], 1, show_search_only=True)
            return embed, view
        
        users_per_page = 20
        page_count = (len(users) + users_per_page - 1) // users_per_page
        
        page = max(0, min(page, page_count - 1))
        
        start_index = page * users_per_page
        end_index = min(start_index + users_per_page, len(users))
        users_on_page = users[start_index:end_index]
        
        embed_data = {
            "title": "✏️ Edit User",
            "description": "Pilih pengguna yang ingin Anda edit dari daftar di bawah ini.",
            "color": 0x3498DB,
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
        }
        
        if search_query:
            embed_data["fields"] = [{
                "name": "🔍 Hasil Pencarian",
                "value": f'Menampilkan {len(users)} hasil untuk "{search_query}"',
                "inline": False
            }]
        
        if page_count > 1:
            embed_data["footer"]["text"] = f"Halaman {page + 1} dari {page_count} • FuHuu Auto Post"
        
        embed = discord.Embed.from_dict(enhance_embed(embed_data))
        view = EditUserView(self, page, search_query, users_on_page, page_count)
        return embed, view

    async def show_edit_modal(self, interaction: discord.Interaction, user_id: str):
        user = self.db.get_user_by_id(user_id)
        
        if not user:
            await interaction.response.send_message('Pengguna tidak ditemukan. Pengguna mungkin telah dihapus.', ephemeral=True)
            return
        
        modal = EditUserModal(self, user_id, user)
        await interaction.response.send_modal(modal)

    async def update_user_roles(self, guild: discord.Guild, user_id: str, subscription_type: str):
        try:
            role_mapping = {
                'trial_limited': 1327543942190862336,
                'trial_unlimited': 1327543942190862336,
                'perma_limited': 1327543532206035076,
                'perma_unlimited': 1327543532206035076
            }
            
            role_id = role_mapping.get(subscription_type)
            if not role_id:
                return
            
            member = await guild.fetch_member(int(user_id))
            if not member:
                return
            
            roles_to_remove = [guild.get_role(rid) for rid in role_mapping.values() if rid != role_id]
            
            for role in roles_to_remove:
                if role and role in member.roles:
                    await member.remove_roles(role)
            
            role = guild.get_role(role_id)
            if role:
                await member.add_roles(role)
        except Exception as e:
            if config.is_debug:
                print(f'Error updating user roles: {e}')

class EditUserView(discord.ui.View):
    def __init__(self, command_instance, page: int, search_query: str, users_on_page: List[Dict], page_count: int, show_search_only: bool = False):
        super().__init__(timeout=300)
        self.command = command_instance
        self.page = page
        self.search_query = search_query
        self.page_count = page_count
        
        if not show_search_only and users_on_page:
            user_options = []
            for user in users_on_page:
                is_active = user.get('active', False)
                
                option = discord.SelectOption(
                    label=user['username'][:100],
                    description=f"ID: {user['id']} | Tipe: {user['subscriptionType']} | {'✅ Aktif' if is_active else '❌ Tidak Aktif'}"[:100],
                    value=user['id'],
                    emoji="✅" if is_active else "❌"
                )
                user_options.append(option)
            
            if user_options:
                select = discord.ui.Select(placeholder="Pilih pengguna untuk diedit", options=user_options)
                select.callback = self.select_callback
                self.add_item(select)
        
        self.add_item(SearchButton())
        
        if page_count > 1:
            if page > 0:
                self.add_item(PrevPageButton())
            if page < page_count - 1:
                self.add_item(NextPageButton())
    
    async def select_callback(self, interaction: discord.Interaction):
        try:
            user_id = interaction.data['values'][0]
            await self.command.show_edit_modal(interaction, user_id)
        except Exception as e:
            await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)

class SearchButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="🔍 Cari Pengguna", style=discord.ButtonStyle.primary)
    
    async def callback(self, interaction: discord.Interaction):
        modal = SearchModal(self.view.command)
        await interaction.response.send_modal(modal)

class PrevPageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="⬅️ Sebelumnya", style=discord.ButtonStyle.secondary)
    
    async def callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            view = self.view
            new_page = view.page - 1
            embed, new_view = await view.command.generate_user_select_page(new_page, view.search_query)
            await interaction.edit_original_response(embed=embed, view=new_view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class NextPageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="➡️ Selanjutnya", style=discord.ButtonStyle.secondary)
    
    async def callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            view = self.view
            new_page = view.page + 1
            embed, new_view = await view.command.generate_user_select_page(new_page, view.search_query)
            await interaction.edit_original_response(embed=embed, view=new_view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class SearchModal(discord.ui.Modal):
    def __init__(self, command_instance):
        super().__init__(title="Cari Pengguna")
        self.command = command_instance
        
        self.search_query = discord.ui.TextInput(
            label="Username Pengguna",
            style=discord.TextStyle.short,
            placeholder="Masukkan username yang ingin dicari",
            required=True
        )
        self.add_item(self.search_query)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            
            search_query = self.search_query.value
            embed, view = await self.command.generate_user_select_page(0, search_query)
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class EditUserModal(discord.ui.Modal):
    def __init__(self, command_instance, user_id: str, user: Dict[str, Any]):
        super().__init__(title=f"Edit Pengguna: {user['username'][:45]}")
        self.command = command_instance
        self.user_id = user_id
        
        exp_days_value = "0d"
        if user.get('expiresAt'):
            try:
                expires_date = datetime.fromisoformat(user['expiresAt'])
                days_remaining = max(0, (expires_date - datetime.now()).days)
                exp_days_value = f"{days_remaining}d"
            except:
                exp_days_value = "0d"
        
        self.package_type = discord.ui.TextInput(
            label="Jenis Paket",
            style=discord.TextStyle.short,
            placeholder="permalimit, permaunli, triallimit, trialunli",
            required=True,
            default=user['subscriptionType']
        )
        self.add_item(self.package_type)
        
        self.exp_days = discord.ui.TextInput(
            label='Expired Time (dalam hari, "0" untuk permanen)',
            style=discord.TextStyle.short,
            placeholder="Contoh: 30d atau 30h",
            required=False,
            default=exp_days_value
        )
        self.add_item(self.exp_days)
        
        self.account_limit = discord.ui.TextInput(
            label="Limit Akun (kosongkan untuk unlimited)",
            style=discord.TextStyle.short,
            placeholder="Contoh: 5",
            required=False,
            default=str(user.get('accountLimit', '')) if user.get('accountLimit') else ''
        )
        self.add_item(self.account_limit)
        
        self.user_status = discord.ui.TextInput(
            label="Status (on/off)",
            style=discord.TextStyle.short,
            placeholder="on atau off",
            required=True,
            default='on' if user.get('active', False) else 'off'
        )
        self.add_item(self.user_status)
        
        self.notes = discord.ui.TextInput(
            label="Catatan (opsional)",
            style=discord.TextStyle.paragraph,
            placeholder="Catatan tambahan tentang pengguna ini",
            required=False,
            default=user.get('notes', '')
        )
        self.add_item(self.notes)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            user = self.command.db.get_user_by_id(self.user_id)
            if not user:
                await interaction.response.send_message('Pengguna tidak ditemukan. Pengguna mungkin sudah dihapus.', ephemeral=True)
                return
            
            package_type = self.package_type.value
            exp_days_input = self.exp_days.value
            account_limit_input = self.account_limit.value
            status_input = self.user_status.value
            notes = self.notes.value
            
            await interaction.response.defer()
            
            package_code_map = {
                "permalimit": "perma_limited",
                "permaunli": "perma_unlimited",
                "triallimit": "trial_limited",
                "trialunli": "trial_unlimited"
            }
            
            subscription_type = package_code_map.get(package_type, package_type)
            
            expires_at = None
            if exp_days_input and exp_days_input not in ['0', '0d', '0h']:
                days_match = re.match(r'^(\d+)(d|h)$', exp_days_input)
                if days_match:
                    days = int(days_match.group(1))
                    unit = days_match.group(2)
                    if days > 0:
                        now = datetime.now()
                        if unit == 'd':
                            expires_at = (now + timedelta(days=days)).isoformat()
                        elif unit == 'h':
                            expires_at = (now + timedelta(hours=days)).isoformat()
            
            account_limit = None
            if account_limit_input and account_limit_input.strip():
                try:
                    account_limit = int(account_limit_input)
                    if account_limit < 0:
                        embed_data = {
                            "title": "❌ Invalid Value",
                            "description": "Limit akun harus berupa angka positif.",
                            "color": 0xFF0000,
                            "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                        }
                        embed = discord.Embed.from_dict(enhance_embed(embed_data))
                        await interaction.edit_original_response(embed=embed)
                        return
                except ValueError:
                    embed_data = {
                        "title": "❌ Invalid Value",
                        "description": "Limit akun harus berupa angka positif.",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.edit_original_response(embed=embed)
                    return
            
            if status_input.lower() == 'on':
                active = True
            elif status_input.lower() == 'off':
                active = False
            else:
                embed_data = {
                    "title": "❌ Invalid Value",
                    "description": 'Status harus "on" atau "off".',
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            update_data = {
                "subscriptionType": subscription_type,
                "accountLimit": account_limit,
                "expiresAt": expires_at,
                "active": active,
                "notes": notes,
                "updatedAt": datetime.now().isoformat()
            }
            
            if not active and user.get('active'):
                update_data["deactivatedAt"] = datetime.now().isoformat()
                await self.command.db.stop_all_services_for_user(self.user_id)
            elif active and not user.get('active'):
                update_data["deactivatedAt"] = None
            
            success = self.command.db.update_user(self.user_id, update_data)
            
            if success:
                try:
                    if interaction.guild:
                        await self.command.update_user_roles(interaction.guild, self.user_id, subscription_type)
                    
                    discord_user = await self.command.bot.fetch_user(int(self.user_id))
                    notification_embed_data = {
                        "title": "📝 Subscription Details Updated",
                        "description": f"Langganan Anda untuk **{self.command.bot.user.name}** telah diperbarui oleh admin.",
                        "fields": [
                            {"name": "📊 Tipe Langganan", "value": subscription_type, "inline": True},
                            {"name": "📈 Batas Akun", "value": str(account_limit) if account_limit else "Tidak Terbatas", "inline": True},
                            {"name": "📋 Status", "value": "✅ Aktif" if active else "❌ Tidak Aktif", "inline": True}
                        ],
                        "color": 0x00FF00 if active else 0xFF0000,
                        "timestamp": datetime.now().isoformat(),
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    
                    if expires_at:
                        notification_embed_data["fields"].append({
                            "name": "⏳ Berakhir Pada",
                            "value": datetime.fromisoformat(expires_at).strftime('%Y-%m-%d'),
                            "inline": True
                        })
                    
                    notification_embed = discord.Embed.from_dict(enhance_embed(notification_embed_data))
                    try:
                        await discord_user.send(embed=notification_embed)
                    except:
                        pass
                except Exception:
                    pass
                
                user_info_embed_data = {
                    "title": "✅ User Successfully Updated",
                    "description": f"Pengguna **{user['username']}** telah diperbarui.",
                    "fields": [
                        {"name": "🆔 ID Pengguna", "value": self.user_id, "inline": True},
                        {"name": "📊 Tipe Langganan", "value": subscription_type, "inline": True},
                        {"name": "📈 Batas Akun", "value": str(account_limit) if account_limit else "Tidak Terbatas", "inline": True},
                        {"name": "⏳ Tanggal Kedaluwarsa", "value": datetime.fromisoformat(expires_at).strftime('%Y-%m-%d') if expires_at else "Tidak Pernah", "inline": True},
                        {"name": "📋 Status", "value": "✅ Aktif" if active else "❌ Tidak Aktif", "inline": True}
                    ],
                    "color": 0x00FF00,
                    "timestamp": datetime.now().isoformat(),
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                
                embed = discord.Embed.from_dict(enhance_embed(user_info_embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                
                try:
                    owner = await self.command.bot.fetch_user(int(config.owner_id))
                    owner_embed_data = {
                        "title": "🔄 User Updated",
                        "description": f"Pengguna **{user['username']}** telah diperbarui oleh {interaction.user.name}.",
                        "fields": [
                            {"name": "🆔 ID Pengguna", "value": self.user_id, "inline": True},
                            {"name": "📊 Tipe Langganan", "value": subscription_type, "inline": True},
                            {"name": "📈 Batas Akun", "value": str(account_limit) if account_limit else "Tidak Terbatas", "inline": True},
                            {"name": "⏳ Tanggal Kedaluwarsa", "value": datetime.fromisoformat(expires_at).strftime('%Y-%m-%d') if expires_at else "Tidak Pernah", "inline": True},
                            {"name": "📋 Status", "value": "✅ Aktif" if active else "❌ Tidak Aktif", "inline": True}
                        ],
                        "color": 0x3498DB,
                        "timestamp": datetime.now().isoformat(),
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    owner_embed = discord.Embed.from_dict(enhance_embed(owner_embed_data))
                    await owner.send(embed=owner_embed)
                except:
                    pass
            else:
                embed_data = {
                    "title": "❌ Failed to Update User",
                    "description": "Terjadi kesalahan saat memperbarui data pengguna.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
        except Exception as e:
            error_embed_data = {
                "title": "❌ An Error Occurred",
                "description": f"Error: {str(e)}",
                "color": 0xFF0000,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            error_embed = discord.Embed.from_dict(enhance_embed(error_embed_data))
            if interaction.response.is_done():
                await interaction.edit_original_response(embed=error_embed, view=None)
            else:
                await interaction.response.edit_message(embed=error_embed, view=None)

async def setup(bot):
    await bot.add_cog(EditUserCommand(bot))