import discord
from discord.ext import commands
from discord import app_commands
import httpx
import re
import asyncio
import random
from datetime import datetime
from typing import Dict, Any, Optional, List
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import config
from database import enhance_embed, start_single_channel_immediately, stop_single_channel_immediately

async def validate_token(token: str) -> Dict[str, Any]:
    try:
        headers = {'Authorization': token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get('https://discord.com/api/v10/users/@me', headers=headers)
            if response.status_code == 200:
                return {"valid": True, "user": response.json()}
            else:
                return {"valid": False, "error": response.text}
    except Exception as e:
        return {"valid": False, "error": str(e)}

async def fetch_channel_data(channel_id: str, user_token: str) -> Dict[str, Any]:
    try:
        headers = {'Authorization': user_token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f'https://discord.com/api/v10/channels/{channel_id}', headers=headers)
            if response.status_code == 200:
                data = response.json()
                return {
                    "name": data.get("name", f"Channel {channel_id}"),
                    "guildId": data.get("guild_id"),
                    "success": True
                }
            else:
                return {
                    "name": f"Channel {channel_id}",
                    "success": False
                }
    except Exception:
        return {
            "name": f"Channel {channel_id}",
            "success": False
        }

async def fetch_guild_name_from_channel(channel_id: str, user_token: str) -> str:
    try:
        headers = {'Authorization': user_token}
        async with httpx.AsyncClient(timeout=10.0) as client:
            channel_res = await client.get(f'https://discord.com/api/v10/channels/{channel_id}', headers=headers)
            if channel_res.status_code != 200:
                return 'Server Tidak Diketahui'
            
            channel_data = channel_res.json()
            guild_id = channel_data.get("guild_id")
            if not guild_id:
                return 'Server Tidak Diketahui'
            
            guild_res = await client.get(f'https://discord.com/api/v10/guilds/{guild_id}', headers=headers)
            if guild_res.status_code == 200:
                guild_data = guild_res.json()
                return guild_data.get("name", "Server Tidak Diketahui")
            else:
                return 'Server Tidak Diketahui'
    except Exception:
        return 'Server Tidak Diketahui'

def parse_delay(delay_str: str) -> Optional[int]:
    pattern = r'^(\d+)([smhdj])$'
    match = re.match(pattern, delay_str.strip())
    
    if not match:
        return None
    
    value = int(match.group(1))
    unit = match.group(2)
    
    if unit in ['s', 'd']:
        return value * 1000
    elif unit == 'm':
        return value * 60 * 1000
    elif unit in ['h', 'j']:
        return value * 60 * 60 * 1000
    
    return None

def format_delay(ms: int) -> str:
    if ms < 60000:
        return f"{ms // 1000}d"
    elif ms < 3600000:
        return f"{ms // 60000}m"
    else:
        return f"{ms // 3600000}j"

def truncate_text(text: str, max_length: int = 1000) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def truncate_label(text: str, max_length: int = 50) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def truncate_description(text: str, max_length: int = 100) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def is_channel_in_account(account: Dict[str, Any], channel_id: str) -> bool:
    channels = account.get("channels", [])
    return any(channel.get("id") == channel_id for channel in channels)

async def handle_start_all_with_delays(account_id: str, user_id: str, delays: List[int]):
    try:
        from database import db
        account = db.get_account_by_id(account_id, user_id)
        if not account or not account.get("channels"):
            return {'success': False, 'error': 'No channels found'}
        
        channels_to_start = []
        for i, channel in enumerate(account["channels"]):
            if channel.get("status") != "online":
                task_key = f"{account_id}_{i}"
                if task_key in db.active_tasks:
                    try:
                        if not db.active_tasks[task_key].done():
                            db.active_tasks[task_key].cancel()
                            await asyncio.sleep(0.1)
                    except:
                        pass
                    finally:
                        if task_key in db.active_tasks:
                            del db.active_tasks[task_key]
                
                channel["status"] = "online"
                channel["startedAt"] = datetime.now().isoformat()
                channels_to_start.append(i)
        
        db.save_account(user_id, account)
        
        if not channels_to_start:
            return {'success': True, 'started': 0}
        
        if not delays or len(delays) == 0:
            delays = [5000]
        
        download_promises = []
        for channel_index in channels_to_start:
            if channel_index < len(account["channels"]):
                channel = account["channels"][channel_index]
                if channel.get("imageUrls"):
                    download_promise = db.download_channel_images(user_id, channel["id"], channel["imageUrls"])
                    download_promises.append(download_promise)
        
        if download_promises:
            try:
                await asyncio.gather(*download_promises, return_exceptions=True)
            except Exception:
                pass
        
        success_count = 0
        
        await start_single_channel_immediately(account_id, channels_to_start[0], user_id)
        success_count += 1
        
        cumulative_delay = 0
        for i in range(1, len(channels_to_start)):
            channel_index = channels_to_start[i]
            current_delay = random.choice(delays) / 1000
            cumulative_delay += current_delay
            
            async def start_delayed_channel(ch_index, delay):
                await asyncio.sleep(delay)
                current_account = db.get_account_by_id(account_id, user_id)
                if (current_account and current_account.get("channels") and 
                    ch_index < len(current_account["channels"]) and 
                    current_account["channels"][ch_index].get("status") == "online"):
                    await start_single_channel_immediately(account_id, ch_index, user_id)
            
            asyncio.create_task(start_delayed_channel(channel_index, cumulative_delay))
            success_count += 1
        
        return {'success': True, 'started': success_count}
        
    except Exception as e:
        return {'success': False, 'error': str(e)}

class ChannelListManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        from database import db
        self.db = db
    
    @app_commands.command(name="list_channel", description="Lihat dan kelola saluran selfbot")
    async def list_channels(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            
            user_id = str(interaction.user.id)
            accounts = self.db.get_accounts(user_id)
            
            if not accounts:
                embed_data = {
                    "title": "⚠️ No Accounts Found",
                    "description": "Tambahkan akun terlebih dahulu dengan `/add_account`",
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            account_options = []
            for account in accounts:
                try:
                    validation = await validate_token(account["token"])
                    status = "Valid" if validation["valid"] else "Tidak Valid"
                    channel_count = len(account.get("channels", []))
                    
                    account_options.append(discord.SelectOption(
                        label=truncate_label(f"{account['username']} ({account['name']})"),
                        description=truncate_description(f"Status: {status} | Saluran: {channel_count}"),
                        value=account["id"],
                        emoji="✅" if validation["valid"] else "❌"
                    ))
                except Exception:
                    account_options.append(discord.SelectOption(
                        label=truncate_label(f"{account.get('username', 'Unknown')} ({account.get('name', 'Unknown')})"),
                        description=truncate_description(f"Status: Error | Saluran: {len(account.get('channels', []))}"),
                        value=account["id"],
                        emoji="❌"
                    ))
            
            if not account_options:
                embed_data = {
                    "title": "⚠️ No Valid Accounts",
                    "description": "Semua akun tidak valid atau tidak dapat diakses",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed)
                return
            
            embed_data = {
                "title": "📋 Channels List",
                "description": "Pilih akun selfbot terlebih dahulu",
                "color": 0x0099FF,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            view = ListAccountSelectView(self, account_options)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")
            except Exception:
                pass
    
    async def show_channel_dropdown(self, interaction: discord.Interaction, account_id: str, user_id: str, page: int = 0):
        try:
            account = self.db.get_account_by_id(account_id, user_id)
            
            if not account:
                await interaction.edit_original_response(content='❌ Akun tidak ditemukan. Mungkin sudah dihapus.', view=None)
                return
            
            validation = await validate_token(account["token"])
            if not validation["valid"]:
                embed_data = {
                    "title": "❌ Invalid Token",
                    "description": f"Token untuk akun {account['username']} sudah tidak valid.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            channels = account.get("channels", [])
            if not channels:
                embed_data = {
                    "title": "⚠️ No Channels Found",
                    "description": f"Akun {account['username']} belum memiliki saluran. Tambahkan saluran dengan /add_channel",
                    "color": 0xFFAA00,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.edit_original_response(embed=embed, view=None)
                return
            
            items_per_page = 24
            total_pages = (len(channels) + items_per_page - 1) // items_per_page
            start = page * items_per_page
            end = min(start + items_per_page, len(channels))
            
            channel_options = []
            
            for index in range(start, end):
                if index >= len(channels):
                    break
                
                channel = channels[index]
                is_online = channel.get("status") == "online"
                is_paused = channel.get("status") == "paused"
                
                label = f"#Saluran #{index + 1}"
                description = f"ID: {channel['id']} Server: {channel.get('guildName', 'Tidak Diketahui')}"
                
                if channel.get("channelName"):
                    label = f"#{channel['channelName']}"
                else:
                    try:
                        channel_data = await fetch_channel_data(channel["id"], account["token"])
                        if channel_data["success"]:
                            channel["channelName"] = channel_data["name"]
                            self.db.save_account(user_id, account)
                            label = f"#{channel_data['name']}"
                    except Exception:
                        pass
                
                label = truncate_label(label)
                description = truncate_description(description)
                
                if is_paused:
                    emoji = "⏸️"
                elif is_online:
                    emoji = "✅"
                else:
                    emoji = "❌"
                
                channel_options.append(discord.SelectOption(
                    label=label,
                    description=description,
                    value=f"{account_id}_{index}",
                    emoji=emoji
                ))
            
            view = ListChannelView(self, account_id, user_id, page, total_pages, channel_options)
            
            embed_data = {
                "title": f"📡 Channels for {account['username']}",
                "description": f"Halaman {page + 1}/{total_pages}\nTotal Saluran: {len(channels)}",
                "color": 0x0099FF,
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
        except Exception as e:
            await interaction.edit_original_response(content=f'❌ Terjadi kesalahan: {str(e)}', view=None)
    
    async def show_single_channel(self, interaction: discord.Interaction, account_id: str, channel_index: int, user_id: str):
        try:
            account = self.db.get_account_by_id(account_id, user_id)
            
            if not account or not account.get("channels") or channel_index >= len(account["channels"]):
                await interaction.followup.send(content='❌ Saluran tidak ditemukan. Mungkin sudah dihapus.', ephemeral=True)
                return
            
            channel = account["channels"][channel_index]
            is_online = channel.get("status") == "online"
            is_paused = channel.get("status") == "paused"
            
            message_count = self.db.get_message_count_by_index(user_id, account_id, channel_index)
            uptime = self.db.get_uptime(account_id, channel_index, user_id)
            
            channel_name = channel.get("channelName", f"Saluran #{channel_index + 1}")
            
            user_avatar_url = None
            try:
                validation = await validate_token(account["token"])
                if validation["valid"]:
                    user_data = validation["user"]
                    if user_data.get("avatar"):
                        user_avatar_url = f"https://cdn.discordapp.com/avatars/{user_data['id']}/{user_data['avatar']}.png?size=1024"
            except Exception:
                pass
            
            if is_paused:
                embed_color = 0xFFA500
                status_text = "⏸️ Paused"
            elif is_online:
                embed_color = 0x00FF00
                status_text = "✅ Online"
            else:
                embed_color = 0xFF0000
                status_text = "❌ Offline"
            
            embed_data = {
                "title": "🎮 Channel Auto Post Control",
                "description": "Kontrol auto post saluran dan edit atau hapus konfigurasi",
                "color": embed_color,
                "fields": [],
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            info_channel_text = f"Nama Saluran: <#{channel['id']}>\nID Saluran: {channel['id']}\nNama Server: {channel.get('guildName', 'Tidak Diketahui')}"
            embed_data["fields"].append({"name": "📢 Info Saluran", "value": info_channel_text, "inline": False})
            
            config_text = f"Status: {status_text}\nJeda Dasar: {format_delay(channel['baseDelay'])}\nJeda Tambahan: {', '.join(format_delay(d) for d in channel.get('additionalDelays', [])) if channel.get('additionalDelays') else 'Tidak Ada'}\nPesan Terkirim: {message_count}"
            
            if is_online and uptime:
                config_text += f"\nWaktu Aktif: {uptime}"
            elif is_paused and channel.get("resumeAt"):
                try:
                    resume_time = datetime.fromisoformat(channel["resumeAt"])
                    config_text += f"\nWill resume: {resume_time.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    config_text += f"\nWill resume soon"
            
            if channel.get("lastMessageTime"):
                try:
                    last_time = datetime.fromisoformat(channel["lastMessageTime"])
                    config_text += f"\nPesan Terakhir: {last_time.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    config_text += f"\nPesan Terakhir: {channel['lastMessageTime']}"
            
            embed_data["fields"].append({"name": "⚙️ Konfigurasi Saluran", "value": config_text, "inline": False})
            
            if channel.get("imageUrls"):
                media_links = '\n'.join(f"[Link ke Media {i+1}]({url})" for i, url in enumerate(channel["imageUrls"]))
                embed_data["fields"].append({"name": "🖼️ Link Media", "value": media_links, "inline": False})
            
            embed_data["fields"].append({
                "name": "💬 Teks Pesan", 
                "value": f"```{truncate_text(channel['message'], 200)}```", 
                "inline": False
            })
            
            if user_avatar_url:
                embed_data["thumbnail"] = {"url": user_avatar_url}
            
            view = SingleChannelView(self, account_id, channel_index, user_id, is_online, is_paused)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.followup.send(embed=embed, view=view, ephemeral=True)
        except Exception as e:
            await interaction.followup.send(content=f'❌ Terjadi kesalahan: {str(e)}', ephemeral=True)

    async def handle_toggle_button(self, interaction: discord.Interaction, account_id: str, channel_index: int, user_id: str):
        try:
            account = self.db.get_account_by_id(account_id, user_id)
            if not account or not account.get("channels") or channel_index >= len(account["channels"]):
                await interaction.edit_original_response(content='❌ Saluran tidak ditemukan. Mungkin sudah dihapus.', view=None)
                return
            
            channel = account["channels"][channel_index]
            current_status = channel.get("status", "offline")
            
            if current_status in ["online", "paused"]:
                success = await stop_single_channel_immediately(account_id, channel_index, user_id)
                if not success:
                    await interaction.edit_original_response(content='❌ Gagal menghentikan saluran.', view=None)
                    return
            else:
                if channel.get("imageUrls"):
                    try:
                        await self.db.download_channel_images(user_id, channel["id"], channel["imageUrls"])
                    except Exception:
                        pass
                
                success = await start_single_channel_immediately(account_id, channel_index, user_id)
                if not success:
                    await interaction.edit_original_response(content='❌ Gagal memulai saluran.', view=None)
                    return
            
            account = self.db.get_account_by_id(account_id, user_id)
            channel = account["channels"][channel_index]
            is_online = channel.get("status") == "online"
            is_paused = channel.get("status") == "paused"
            
            message_count = self.db.get_message_count_by_index(user_id, account_id, channel_index)
            uptime = self.db.get_uptime(account_id, channel_index, user_id)
            
            user_avatar_url = None
            try:
                validation = await validate_token(account["token"])
                if validation["valid"]:
                    user_data = validation["user"]
                    if user_data.get("avatar"):
                        user_avatar_url = f"https://cdn.discordapp.com/avatars/{user_data['id']}/{user_data['avatar']}.png?size=1024"
            except Exception:
                pass
            
            if is_paused:
                embed_color = 0xFFA500
                status_text = "⏸️ Paused"
            elif is_online:
                embed_color = 0x00FF00
                status_text = "✅ Online"
            else:
                embed_color = 0xFF0000
                status_text = "❌ Offline"
            
            embed_data = {
                "title": "🎮 Channel Auto Post Control",
                "description": "Kontrol auto post saluran dan edit atau hapus konfigurasi",
                "color": embed_color,
                "fields": [],
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            info_channel_text = f"Nama Saluran: <#{channel['id']}>\nID Saluran: {channel['id']}\nNama Server: {channel.get('guildName', 'Tidak Diketahui')}"
            embed_data["fields"].append({"name": "📢 Info Saluran", "value": info_channel_text, "inline": False})
            
            config_text = f"Status: {status_text}\nJeda Dasar: {format_delay(channel['baseDelay'])}\nJeda Tambahan: {', '.join(format_delay(d) for d in channel.get('additionalDelays', [])) if channel.get('additionalDelays') else 'Tidak Ada'}\nPesan Terkirim: {message_count}"
            
            if is_online and uptime:
                config_text += f"\nWaktu Aktif: {uptime}"
            elif is_paused and channel.get("resumeAt"):
                try:
                    resume_time = datetime.fromisoformat(channel["resumeAt"])
                    config_text += f"\nWill resume: {resume_time.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    config_text += f"\nWill resume soon"
            
            if channel.get("lastMessageTime"):
                try:
                    last_time = datetime.fromisoformat(channel["lastMessageTime"])
                    config_text += f"\nPesan Terakhir: {last_time.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    config_text += f"\nPesan Terakhir: {channel['lastMessageTime']}"
            
            embed_data["fields"].append({"name": "⚙️ Konfigurasi Saluran", "value": config_text, "inline": False})
            
            if channel.get("imageUrls"):
                media_links = '\n'.join(f"[Link ke Media {i+1}]({url})" for i, url in enumerate(channel["imageUrls"]))
                embed_data["fields"].append({"name": "🖼️ Link Media", "value": media_links, "inline": False})
            
            embed_data["fields"].append({
                "name": "💬 Teks Pesan", 
                "value": f"```{truncate_text(channel['message'], 200)}```", 
                "inline": False
            })
            
            if user_avatar_url:
                embed_data["thumbnail"] = {"url": user_avatar_url}
            
            view = SingleChannelView(self, account_id, channel_index, user_id, is_online, is_paused)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
            
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)

    async def show_edit_modal(self, interaction: discord.Interaction, account_id: str, channel_index: int, user_id: str):
        try:
            account = self.db.get_account_by_id(account_id, user_id)
            if not account or not account.get("channels") or channel_index >= len(account["channels"]):
                await interaction.response.send_message('❌ Saluran tidak ditemukan. Mungkin sudah dihapus.', ephemeral=True)
                return
            
            channel = account["channels"][channel_index]
            modal = EditChannelModal(self, account_id, channel_index, user_id, channel)
            await interaction.response.send_modal(modal)
        except Exception as e:
            try:
                await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
            except:
                await interaction.followup.send(content=f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)

    async def handle_delete_button(self, interaction: discord.Interaction, account_id: str, channel_index: int, user_id: str):
        try:
            account = self.db.get_account_by_id(account_id, user_id)
            if not account or not account.get("channels") or channel_index >= len(account["channels"]):
                await interaction.edit_original_response(content='❌ Saluran tidak ditemukan. Mungkin sudah dihapus.', view=None)
                return
            
            channel = account["channels"][channel_index]
            channel_id = channel["id"]
            
            if channel.get("status") == "online":
                await stop_single_channel_immediately(account_id, channel_index, user_id)
            
            self.db.cleanup_channel_images(user_id, channel_id)
            
            account["channels"].pop(channel_index)
            self.db.save_account(user_id, account)
            
            embed_data = {
                "title": "✅ Channel Successfully Deleted",
                "description": f"Saluran <#{channel_id}> telah dihapus dari akun **{account.get('username', 'Unknown')}**",
                "color": 0x00FF00,
                "timestamp": datetime.now().isoformat(),
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=None)
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)

    async def handle_start_all_button(self, interaction: discord.Interaction, account_id: str, page: int, user_id: str, delays: List[int]):
        try:
            await interaction.edit_original_response(content="🔄 Memulai semua saluran...", view=None)
            
            result = await handle_start_all_with_delays(account_id, user_id, delays)
            
            await asyncio.sleep(2)
            
            if result['success']:
                await self.show_channel_dropdown(interaction, account_id, user_id, page)
            else:
                await interaction.edit_original_response(content=f"❌ Gagal: {result['error']}")
            
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

    async def handle_stop_all_button(self, interaction: discord.Interaction, account_id: str, page: int, user_id: str):
        try:
            await interaction.edit_original_response(content="🛑 Menghentikan semua saluran...", view=None)
            
            account = self.db.get_account_by_id(account_id, user_id)
            if not account or not account.get("channels"):
                await interaction.edit_original_response(content='❌ Tidak ada saluran yang ditemukan.')
                return
            
            channels_to_stop = []
            for i, channel in enumerate(account["channels"]):
                if channel.get("status") == "online":
                    channels_to_stop.append(i)
            
            if not channels_to_stop:
                await asyncio.sleep(1)
                await self.show_channel_dropdown(interaction, account_id, user_id, page)
                return
            
            for channel_index in channels_to_stop:
                task_key = f"{account_id}_{channel_index}"
                
                if task_key in self.db.active_tasks:
                    try:
                        if not self.db.active_tasks[task_key].done():
                            self.db.active_tasks[task_key].cancel()
                    except Exception:
                        pass
                    finally:
                        if task_key in self.db.active_tasks:
                            del self.db.active_tasks[task_key]
                
                try:
                    channel = account["channels"][channel_index]
                    channel["status"] = "offline"
                    channel["stoppedAt"] = datetime.now().isoformat()
                    channel["errorReason"] = "Manual stop all"
                except Exception:
                    pass
            
            self.db.save_account(user_id, account)
            
            await asyncio.sleep(2)
            await self.show_channel_dropdown(interaction, account_id, user_id, page)
            
        except Exception as e:
            await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")

class ListAccountSelectView(discord.ui.View):
    def __init__(self, command_instance, account_options: List[discord.SelectOption]):
        super().__init__(timeout=300)
        self.command = command_instance
        
        select = discord.ui.Select(
            placeholder="Pilih akun selfbot",
            options=account_options,
            custom_id="listAccount_select"
        )
        select.callback = self.select_callback
        self.add_item(select)
    
    async def select_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            account_id = interaction.data['values'][0]
            user_id = str(interaction.user.id)
            await self.command.show_channel_dropdown(interaction, account_id, user_id, 0)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception:
                pass
    
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

class ListChannelView(discord.ui.View):
    def __init__(self, command_instance, account_id: str, user_id: str, page: int, total_pages: int, channel_options: List[discord.SelectOption]):
        super().__init__(timeout=300)
        self.command = command_instance
        self.account_id = account_id
        self.user_id = user_id
        self.page = page
        self.total_pages = total_pages
        
        if channel_options:
            select = discord.ui.Select(
                placeholder="Pilih saluran untuk dikelola",
                options=channel_options,
                custom_id="listChannel_select"
            )
            select.callback = self.select_callback
            self.add_item(select)
        
        start_all_button = discord.ui.Button(
            label="▶️ Mulai Semua",
            style=discord.ButtonStyle.success,
            custom_id="start_all",
            row=1
        )
        start_all_button.callback = self.start_all_callback
        self.add_item(start_all_button)
        
        stop_all_button = discord.ui.Button(
            label="⏹️ Hentikan Semua",
            style=discord.ButtonStyle.danger,
            custom_id="stop_all",
            row=1
        )
        stop_all_button.callback = self.stop_all_callback
        self.add_item(stop_all_button)
        
        if total_pages > 1:
            if page > 0:
                prev_button = discord.ui.Button(
                    label="◀️ Sebelumnya",
                    style=discord.ButtonStyle.secondary,
                    custom_id="prev_page",
                    row=1
                )
                prev_button.callback = self.prev_page_callback
                self.add_item(prev_button)
            
            if page < total_pages - 1:
                next_button = discord.ui.Button(
                    label="▶️ Berikutnya",
                    style=discord.ButtonStyle.secondary,
                    custom_id="next_page",
                    row=1
                )
                next_button.callback = self.next_page_callback
                self.add_item(next_button)
    
    async def select_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            values = interaction.data['values'][0].split('_')
            account_id = values[0]
            channel_index = int(values[1])
            await self.command.show_single_channel(interaction, account_id, channel_index, self.user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.followup.send(content=f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
            except Exception:
                pass
    
    async def start_all_callback(self, interaction: discord.Interaction):
        try:
            modal = StartAllModal(self.command, self.account_id, self.user_id, self.page)
            await interaction.response.send_modal(modal)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.followup.send(content=f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
            except Exception:
                pass
    
    async def stop_all_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            await self.command.handle_stop_all_button(interaction, self.account_id, self.page, self.user_id)
        except discord.errors.InteractionResponded:
            await self.command.handle_stop_all_button(interaction, self.account_id, self.page, self.user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}")
            except Exception:
                pass
    
    async def prev_page_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            new_page = self.page - 1
            await self.command.show_channel_dropdown(interaction, self.account_id, self.user_id, new_page)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.followup.send(content=f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
            except Exception:
                pass
    
    async def next_page_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            new_page = self.page + 1
            await self.command.show_channel_dropdown(interaction, self.account_id, self.user_id, new_page)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.followup.send(content=f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
            except Exception:
                pass
    
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

class SingleChannelView(discord.ui.View):
    def __init__(self, command_instance, account_id: str, channel_index: int, user_id: str, is_online: bool, is_paused: bool = False):
        super().__init__(timeout=300)
        self.command = command_instance
        self.account_id = account_id
        self.channel_index = channel_index
        self.user_id = user_id
        
        if is_paused:
            toggle_button = discord.ui.Button(
                label="▶️ Resume",
                style=discord.ButtonStyle.success,
                custom_id="toggle_button"
            )
        else:
            toggle_button = discord.ui.Button(
                label="⏹️ Hentikan" if is_online else "▶️ Mulai",
                style=discord.ButtonStyle.danger if is_online else discord.ButtonStyle.success,
                custom_id="toggle_button"
            )
        toggle_button.callback = self.toggle_callback
        self.add_item(toggle_button)
        
        edit_button = discord.ui.Button(
            label="✏️ Edit",
            style=discord.ButtonStyle.primary,
            custom_id="edit_button"
        )
        edit_button.callback = self.edit_callback
        self.add_item(edit_button)
        
        delete_button = discord.ui.Button(
            label="🗑️ Hapus",
            style=discord.ButtonStyle.danger,
            custom_id="delete_button"
        )
        delete_button.callback = self.delete_callback
        self.add_item(delete_button)
    
    async def toggle_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            await self.command.handle_toggle_button(interaction, self.account_id, self.channel_index, self.user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception:
                pass
    
    async def edit_callback(self, interaction: discord.Interaction):
        try:
            await self.command.show_edit_modal(interaction, self.account_id, self.channel_index, self.user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception:
                pass
    
    async def delete_callback(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            await self.command.handle_delete_button(interaction, self.account_id, self.channel_index, self.user_id)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except Exception:
                pass
    
    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

class StartAllModal(discord.ui.Modal):
    def __init__(self, command_instance, account_id: str, user_id: str, page: int):
        super().__init__(title="Set Delay untuk Start All")
        self.command = command_instance
        self.account_id = account_id
        self.user_id = user_id
        self.page = page
        
        self.start_delay = discord.ui.TextInput(
            label="Jeda antar saluran (mis., 5d/5s, 1m, 2j/2h)",
            style=discord.TextStyle.short,
            placeholder="Format: 5d/5s,1m,2j/2h (dipisah koma untuk acak)",
            required=True,
            max_length=200
        )
        self.add_item(self.start_delay)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            delay_input = self.start_delay.value
            delays = []
            
            for delay_str in delay_input.split(','):
                parsed = parse_delay(delay_str.strip())
                if parsed is not None:
                    delays.append(max(parsed, 1000))
            
            if not delays:
                embed_data = {
                    "title": "❌ Invalid Delay Format",
                    "description": "Format jeda harus: 5d/5s, 1m, 2j/2h",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            await interaction.response.defer()
            await self.command.handle_start_all_button(interaction, self.account_id, self.page, self.user_id, delays)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
                else:
                    await interaction.followup.send(content=f"❌ Terjadi kesalahan: {str(e)}", ephemeral=True)
            except Exception:
                pass

class EditChannelModal(discord.ui.Modal):
    def __init__(self, command_instance, account_id: str, channel_index: int, user_id: str, channel: Dict[str, Any]):
        super().__init__(title="Edit Saluran")
        self.command = command_instance
        self.account_id = account_id
        self.channel_index = channel_index
        self.user_id = user_id
        
        self.channel_id = discord.ui.TextInput(
            label="ID Saluran",
            style=discord.TextStyle.short,
            default=channel.get("id", ""),
            required=True,
            max_length=20
        )
        self.add_item(self.channel_id)
        
        self.base_delay = discord.ui.TextInput(
            label="Jeda Dasar (mis., 5d/5s, 1m, 2j/2h)",
            style=discord.TextStyle.short,
            default=format_delay(channel.get("baseDelay", 120000)),
            placeholder='Format: 5d/5s, 1m, 2j/2h atau "delete" untuk reset',
            required=False,
            max_length=50
        )
        self.add_item(self.base_delay)
        
        additional_delays_str = ','.join(format_delay(d) for d in channel.get("additionalDelays", []))
        self.additional_delay = discord.ui.TextInput(
            label="Jeda Tambahan (dipisahkan koma)",
            style=discord.TextStyle.short,
            default=additional_delays_str,
            placeholder='Contoh: 5d/5s,10d/10s,1m atau "delete" untuk hapus',
            required=False,
            max_length=200
        )
        self.add_item(self.additional_delay)
        
        image_urls_str = ','.join(channel.get("imageUrls", []))
        self.image_urls = discord.ui.TextInput(
            label="URL Gambar (dipisahkan koma)",
            style=discord.TextStyle.paragraph,
            default=image_urls_str,
            placeholder='https://example.com/image1.jpg,image2.png atau "delete" untuk hapus',
            max_length=4000,
            required=False
        )
        self.add_item(self.image_urls)
        
        self.message = discord.ui.TextInput(
            label="Pesan (maks 2000 karakter)",
            style=discord.TextStyle.paragraph,
            default=channel.get("message", ""),
            placeholder="Teks pesan yang akan dikirim otomatis",
            max_length=2000,
            required=True
        )
        self.add_item(self.message)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            account = self.command.db.get_account_by_id(self.account_id, self.user_id)
            if not account or not account.get("channels") or self.channel_index >= len(account["channels"]):
                await interaction.response.send_message(content='❌ Saluran tidak ditemukan. Mungkin sudah dihapus.', ephemeral=True)
                return
            
            new_channel_id = self.channel_id.value.strip()
            base_delay_input = self.base_delay.value.strip()
            additional_delay_input = self.additional_delay.value.strip()
            image_urls_input = self.image_urls.value.strip()
            message = self.message.value.strip()
            
            if not message:
                await interaction.response.send_message(content='❌ Pesan tidak boleh kosong.', ephemeral=True)
                return
            
            if not new_channel_id:
                await interaction.response.send_message(content='❌ ID Saluran tidak boleh kosong.', ephemeral=True)
                return
            
            old_channel = account["channels"][self.channel_index]
            current_channel_id = old_channel["id"]
            channel_id_changed = new_channel_id != current_channel_id
            
            if channel_id_changed and is_channel_in_account(account, new_channel_id):
                embed_data = {
                    "title": "❌ Channel Already Registered",
                    "description": "ID saluran ini sudah terdaftar pada akun ini. Setiap saluran hanya dapat ditambahkan sekali per akun.",
                    "color": 0xFF0000,
                    "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                }
                embed = discord.Embed.from_dict(enhance_embed(embed_data))
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            await interaction.response.defer(ephemeral=True)
            
            channel = account["channels"][self.channel_index]
            
            if base_delay_input:
                if base_delay_input.lower() == 'delete':
                    channel["baseDelay"] = 120000
                else:
                    parsed_delay = parse_delay(base_delay_input)
                    if parsed_delay is not None:
                        channel["baseDelay"] = max(parsed_delay, 5000)
            
            if additional_delay_input:
                if additional_delay_input.lower() == 'delete':
                    channel["additionalDelays"] = []
                else:
                    additional_delays = []
                    for delay_str in additional_delay_input.split(','):
                        parsed = parse_delay(delay_str.strip())
                        if parsed is not None:
                            additional_delays.append(max(parsed, 5000))
                    channel["additionalDelays"] = additional_delays
            
            if image_urls_input:
                if image_urls_input.lower() == 'delete':
                    if channel.get("imageUrls"):
                        self.command.db.cleanup_channel_images(self.user_id, channel["id"])
                    channel["imageUrls"] = []
                else:
                    image_urls = []
                    for url in image_urls_input.split(','):
                        url = url.strip()
                        if url and url.startswith(('http://', 'https://')):
                            image_urls.append(url)
                    channel["imageUrls"] = image_urls
            
            if channel_id_changed:
                try:
                    guild_name = await fetch_guild_name_from_channel(new_channel_id, account["token"])
                    channel_data = await fetch_channel_data(new_channel_id, account["token"])
                    
                    channel["guildName"] = guild_name
                    if channel_data["success"]:
                        channel["channelName"] = channel_data["name"]
                    
                    self.command.db.cleanup_channel_images(self.user_id, current_channel_id)
                    
                    channel["id"] = new_channel_id
                    channel["status"] = "offline"
                    channel["stoppedAt"] = datetime.now().isoformat()
                    
                except Exception as e:
                    embed_data = {
                        "title": "❌ Invalid Channel",
                        "description": f"Tidak dapat mengakses saluran dengan ID: {new_channel_id}. Pastikan ID benar dan token memiliki akses.",
                        "color": 0xFF0000,
                        "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
                    }
                    embed = discord.Embed.from_dict(enhance_embed(embed_data))
                    await interaction.edit_original_response(embed=embed, view=None)
                    return
            
            channel["message"] = message
            channel["updatedAt"] = datetime.now().isoformat()
            
            self.command.db.save_account(self.user_id, account)
            
            if channel.get("imageUrls"):
                try:
                    await self.command.db.download_channel_images(self.user_id, channel["id"], channel["imageUrls"])
                except Exception:
                    pass
            
            is_online = channel.get("status") == "online"
            is_paused = channel.get("status") == "paused"
            message_count = self.command.db.get_message_count_by_index(self.user_id, self.account_id, self.channel_index)
            uptime = self.command.db.get_uptime(self.account_id, self.channel_index, self.user_id)
            
            user_avatar_url = None
            try:
                validation = await validate_token(account["token"])
                if validation["valid"]:
                    user_data = validation["user"]
                    if user_data.get("avatar"):
                        user_avatar_url = f"https://cdn.discordapp.com/avatars/{user_data['id']}/{user_data['avatar']}.png?size=1024"
            except Exception:
                pass
            
            if is_paused:
                embed_color = 0xFFA500
                status_text = "⏸️ Paused"
            elif is_online:
                embed_color = 0x00FF00
                status_text = "✅ Online"
            else:
                embed_color = 0xFF0000
                status_text = "❌ Offline"
            
            embed_data = {
                "title": "🎮 Channel Auto Post Control",
                "description": "Kontrol auto post saluran dan edit atau hapus konfigurasi",
                "color": embed_color,
                "fields": [],
                "footer": {"text": "FuHuu Auto Post", "icon_url": config.images.get("footerIcon")}
            }
            
            info_channel_text = f"Nama Saluran: <#{channel['id']}>\nID Saluran: {channel['id']}\nNama Server: {channel.get('guildName', 'Tidak Diketahui')}"
            embed_data["fields"].append({"name": "📢 Info Saluran", "value": info_channel_text, "inline": False})
            
            config_text = f"Status: {status_text}\nJeda Dasar: {format_delay(channel['baseDelay'])}\nJeda Tambahan: {', '.join(format_delay(d) for d in channel.get('additionalDelays', [])) if channel.get('additionalDelays') else 'Tidak Ada'}\nPesan Terkirim: {message_count}"
            
            if is_online and uptime:
                config_text += f"\nWaktu Aktif: {uptime}"
            elif is_paused and channel.get("resumeAt"):
                try:
                    resume_time = datetime.fromisoformat(channel["resumeAt"])
                    config_text += f"\nWill resume: {resume_time.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    config_text += f"\nWill resume soon"
            
            if channel.get("lastMessageTime"):
                try:
                    last_time = datetime.fromisoformat(channel["lastMessageTime"])
                    config_text += f"\nPesan Terakhir: {last_time.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    config_text += f"\nPesan Terakhir: {channel['lastMessageTime']}"
            
            embed_data["fields"].append({"name": "⚙️ Konfigurasi Saluran", "value": config_text, "inline": False})
            
            if channel.get("imageUrls"):
                media_links = '\n'.join(f"[Link ke Media {i+1}]({url})" for i, url in enumerate(channel["imageUrls"]))
                embed_data["fields"].append({"name": "🖼️ Link Media", "value": media_links, "inline": False})
            
            embed_data["fields"].append({
                "name": "💬 Teks Pesan", 
                "value": f"```{truncate_text(channel['message'], 200)}```", 
                "inline": False
            })
            
            if user_avatar_url:
                embed_data["thumbnail"] = {"url": user_avatar_url}
            
            view = SingleChannelView(self.command, self.account_id, self.channel_index, self.user_id, is_online, is_paused)
            embed = discord.Embed.from_dict(enhance_embed(embed_data))
            await interaction.edit_original_response(embed=embed, view=view)
            
        except Exception as e:
            try:
                await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)
            except:
                await interaction.edit_original_response(content=f"❌ Terjadi kesalahan: {str(e)}", view=None)

async def setup(bot):
    cog = ChannelListManager(bot)
    if hasattr(bot, 'get_cog') and bot.get_cog('ChannelListManager'):
        await bot.remove_cog('ChannelListManager')
    await bot.add_cog(cog)