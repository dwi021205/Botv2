import json
import os
import asyncio
import aiofiles
import aiohttp
import requests
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
import discord
from discord.ext import tasks
import base64
import shutil
from urllib.parse import urlparse
import uuid
import logging
import random
from config import config
import weakref
import gc
import time
import contextlib
import mimetypes
import io
import platform
import threading
import warnings
import ssl
import speedtest

warnings.filterwarnings("ignore", category=ResourceWarning)
warnings.filterwarnings("ignore", message=".*SSL.*")
warnings.filterwarnings("ignore", message=".*Unverified HTTPS request.*")

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

logger = logging.getLogger(__name__)

WIB = timezone(timedelta(hours=7))

def get_wib_time() -> datetime:
    return datetime.now(WIB)

def get_utc_time() -> datetime:
    return datetime.now(timezone.utc)

def get_utc_timestamp_ms() -> int:
    return int(datetime.now(timezone.utc).timestamp() * 1000)

def format_wib_time(dt: datetime = None) -> str:
    if dt is None:
        dt = get_wib_time()
    elif dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc).astimezone(WIB)
    elif dt.tzinfo != WIB:
        dt = dt.astimezone(WIB)
    
    return dt.strftime('%H:%M:%S, %d-%m-%Y')

def calculate_uptime_duration(start_time: datetime, end_time: datetime = None) -> str:
    if end_time is None:
        end_time = get_wib_time()
    
    if start_time.tzinfo is None:
        start_time = start_time.replace(tzinfo=timezone.utc).astimezone(WIB)
    
    if end_time.tzinfo is None:
        end_time = end_time.replace(tzinfo=timezone.utc).astimezone(WIB)
    
    duration = end_time - start_time
    total_seconds = int(duration.total_seconds())
    
    if total_seconds < 0:
        return "0 detik"
    
    days = total_seconds // 86400
    hours = (total_seconds % 86400) // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    
    parts = []
    if days > 0:
        parts.append(f"{days} hari")
    if hours > 0:
        parts.append(f"{hours} jam")
    if minutes > 0:
        parts.append(f"{minutes} menit")
    if seconds > 0 or not parts:
        parts.append(f"{seconds} detik")
    
    return ", ".join(parts)

MOBILE_USER_AGENT = 'Discord-Android/126021;RNA'
MOBILE_SUPER_PROPERTIES = base64.b64encode(json.dumps({
    "os": "Android",
    "browser": "Discord Android",
    "device": "Samsung SM-G973F",
    "system_locale": "en-US",
    "client_version": "126.21",
    "release_channel": "stable",
    "device_vendor_id": "1234567890abcdef",
    "browser_version": "126.21",
    "browser_user_agent": "Discord-Android/126021;RNA",
    "client_build_number": 126021,
    "native_build_number": 126021
}).encode()).decode()

def get_mobile_headers(token: str) -> Dict[str, str]:
    return {
        'Authorization': token,
        'User-Agent': MOBILE_USER_AGENT,
        'X-Super-Properties': MOBILE_SUPER_PROPERTIES,
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'X-Discord-Locale': 'en-US',
        'X-Debug-Options': 'bugReporterEnabled',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin'
    }

def enhance_embed(embed_data: Dict[str, Any]) -> Dict[str, Any]:
    if config.images.get("globalEmbed"):
        embed_data["image"] = {"url": config.images["globalEmbed"]}
    
    if not embed_data.get("footer"):
        embed_data["footer"] = {
            "text": "FuHuu Auto Post",
            "icon_url": config.images.get("footerIcon")
        }
    elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
        embed_data["footer"]["icon_url"] = config.images["footerIcon"]
    
    return embed_data

def test_network_speed() -> Dict[str, Any]:
    try:
        s = speedtest.Speedtest()
        s.get_best_server()
        
        ping = s.results.ping
        download_speed = s.download() / 1000000
        upload_speed = s.upload() / 1000000
        
        return {
            'success': True,
            'ping': round(ping, 1),
            'download': round(download_speed, 2),
            'upload': round(upload_speed, 2)
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'ping': 0,
            'download': 0,
            'upload': 0
        }

async def get_network_status() -> Dict[str, Any]:
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, test_network_speed)
        
        return {
            'ping': {
                'success': result['success'],
                'avg': result.get('ping', 0),
                'error': result.get('error', '')
            },
            'download': {
                'success': result['success'],
                'speed': result.get('download', 0),
                'error': result.get('error', '')
            },
            'upload': {
                'success': result['success'],
                'speed': result.get('upload', 0),
                'error': result.get('error', '')
            }
        }
    except Exception as e:
        return {
            'ping': {'success': False, 'error': str(e)},
            'download': {'success': False, 'error': str(e)},
            'upload': {'success': False, 'error': str(e)}
        }

def get_system_info() -> Dict[str, Any]:
    try:
        import psutil
        
        cpu_percent = psutil.cpu_percent(interval=1)
        
        memory = psutil.virtual_memory()
        ram_usage_gb = round(memory.used / (1024**3), 2)
        
        disk = psutil.disk_usage('/')
        storage_usage_gb = round(disk.used / (1024**3), 2)
        
        system_name = platform.system()
        system_version = platform.version()
        
        boot_time = psutil.boot_time()
        system_uptime = calculate_uptime_duration(datetime.fromtimestamp(boot_time))
        
        return {
            'system': f"{system_name} {system_version}",
            'ram_usage': ram_usage_gb,
            'storage_usage': storage_usage_gb,
            'cpu_usage': cpu_percent,
            'system_uptime': system_uptime
        }
    except Exception as e:
        return {
            'system': 'Unknown',
            'ram_usage': 0,
            'storage_usage': 0,
            'cpu_usage': 0,
            'system_uptime': 'Unknown'
        }

def format_network_status(network_info: Dict[str, Any]) -> str:
    try:
        ping_text = "❌ Failed"
        if network_info['ping']['success']:
            ping_text = f"🟢 {network_info['ping']['avg']}ms"
        elif 'error' in network_info['ping']:
            error_msg = network_info['ping']['error']
            if len(error_msg) > 20:
                error_msg = error_msg[:20] + "..."
            ping_text = f"❌ {error_msg}"
        
        download_text = "❌ Failed"
        if network_info['download']['success']:
            download_text = f"🟢 {network_info['download']['speed']} Mbps"
        elif 'error' in network_info['download']:
            error_msg = network_info['download']['error']
            if len(error_msg) > 15:
                error_msg = error_msg[:15] + "..."
            download_text = f"❌ {error_msg}"
        
        upload_text = "❌ Failed"
        if network_info['upload']['success']:
            upload_text = f"🟢 {network_info['upload']['speed']} Mbps"
        elif 'error' in network_info['upload']:
            error_msg = network_info['upload']['error']
            if len(error_msg) > 15:
                error_msg = error_msg[:15] + "..."
            upload_text = f"❌ {error_msg}"
        
        return f"**Ping:** {ping_text}\n**Download:** {download_text}\n**Upload:** {upload_text}"
    except Exception as e:
        return f"**Network Error:** {str(e)[:30]}..."

db = None

def clean_log_file():
    try:
        log_file = 'bot.log'
        if os.path.exists(log_file) and os.path.getsize(log_file) > 5 * 1024 * 1024:
            with open(log_file, 'r+', encoding='utf-8', errors='ignore') as f:
                try:
                    f.seek(-100 * 1024, os.SEEK_END)
                    data = f.read()
                    f.seek(0)
                    f.truncate()
                    f.write(f"Log file cleaned at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Keeping last 100KB\n\n")
                    f.write(data)
                except:
                    f.seek(0)
                    f.truncate()
                    f.write(f"Log file cleaned at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    except Exception as e:
        pass

class Database:
    def __init__(self, data_folder: str):
        self.data_folder = data_folder
        self.users_folder = os.path.join(data_folder, 'users')
        
        self.active_tasks = {}
        self.error_notified_accounts = set()
        
        self._shutdown_event = asyncio.Event()
        
        self.discord_client = None
        self.autoreply_handler = None
        
        self.bot_log_channel = None
        self.last_status_message = None
        
        self._last_trial_check = 0
        self._trial_3day_notifications = set()
        
        os.makedirs(data_folder, exist_ok=True)
        os.makedirs(self.users_folder, exist_ok=True)
        
        self.initialize_users_file()
        self.migrate_existing_accounts()
        
        clean_log_file()

    def get_channel_stats_folder(self, user_id: str) -> str:
        stats_folder = os.path.join(self.get_user_data_folder(user_id), 'channel_stats')
        os.makedirs(stats_folder, exist_ok=True)
        return stats_folder

    def get_account_stats_file(self, user_id: str, account_id: str) -> str:
        stats_folder = self.get_channel_stats_folder(user_id)
        return os.path.join(stats_folder, f"{account_id}_stats.json")
    
    def delete_user_webhook(self, user_id: str) -> bool:
        try:
            users = self.load_users()
            for i, user in enumerate(users):
                if user["id"] == user_id:
                    if "webhookUrl" in users[i]:
                        del users[i]["webhookUrl"]
                    return self.save_users(users)
            return False
        except Exception as e:
            logger.error(f"Error deleting user webhook: {e}")
            return False

    def load_account_stats(self, user_id: str, account_id: str) -> Dict[str, Any]:
        try:
            stats_file = self.get_account_stats_file(user_id, account_id)
            if os.path.exists(stats_file):
                with open(stats_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            logger.error(f"Error loading account stats: {e}")
            return {}

    def save_account_stats(self, user_id: str, account_id: str, stats: Dict[str, Any]) -> bool:
        try:
            stats_file = self.get_account_stats_file(user_id, account_id)
            with open(stats_file, 'w', encoding='utf-8') as f:
                json.dump(stats, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Error saving account stats: {e}")
            return False

    def load_channel_stats(self, user_id: str, account_id: str, channel_id: str) -> Dict[str, Any]:
        try:
            account_stats = self.load_account_stats(user_id, account_id)
            return account_stats.get(channel_id, {
                "message_count": 0,
                "last_webhook_count": 0,
                "last_updated": get_wib_time().isoformat()
            })
        except Exception as e:
            logger.error(f"Error loading channel stats: {e}")
            return {
                "message_count": 0,
                "last_webhook_count": 0,
                "last_updated": get_wib_time().isoformat()
            }

    def save_channel_stats(self, user_id: str, account_id: str, channel_id: str, channel_stats: Dict[str, Any]) -> bool:
        try:
            account_stats = self.load_account_stats(user_id, account_id)
            channel_stats["last_updated"] = get_wib_time().isoformat()
            account_stats[channel_id] = channel_stats
            return self.save_account_stats(user_id, account_id, account_stats)
        except Exception as e:
            logger.error(f"Error saving channel stats: {e}")
            return False

    def ensure_channel_stats_exists(self, user_id: str, account_id: str, channel_id: str):
        try:
            stats = self.load_channel_stats(user_id, account_id, channel_id)
            if not stats or "message_count" not in stats:
                initial_stats = {
                    "message_count": 0,
                    "last_webhook_count": 0,
                    "last_updated": get_wib_time().isoformat()
                }
                self.save_channel_stats(user_id, account_id, channel_id, initial_stats)
        except Exception as e:
            logger.error(f"Error ensuring channel stats exists: {e}")

    def increment_message_count(self, user_id: str, account_id: str, channel_id: str) -> int:
        try:
            self.ensure_channel_stats_exists(user_id, account_id, channel_id)
            stats = self.load_channel_stats(user_id, account_id, channel_id)
            stats["message_count"] += 1
            self.save_channel_stats(user_id, account_id, channel_id, stats)
            return stats["message_count"]
        except Exception as e:
            logger.error(f"Error incrementing message count: {e}")
            return 0

    def get_message_count(self, user_id: str, account_id: str, channel_id: str) -> int:
        try:
            self.ensure_channel_stats_exists(user_id, account_id, channel_id)
            stats = self.load_channel_stats(user_id, account_id, channel_id)
            return stats.get("message_count", 0)
        except Exception as e:
            logger.error(f"Error getting message count: {e}")
            return 0

    def get_message_count_by_index(self, user_id: str, account_id: str, channel_index: int) -> int:
        try:
            account = self.get_account_by_id(account_id, user_id)
            if not account or not account.get("channels") or channel_index >= len(account["channels"]):
                return 0
            
            channel = account["channels"][channel_index]
            channel_id = channel.get("id")
            if not channel_id:
                return 0
            
            return self.get_message_count(user_id, account_id, channel_id)
        except Exception as e:
            logger.error(f"Error getting message count by index: {e}")
            return 0

    def should_send_webhook(self, user_id: str, account_id: str, channel_id: str, base_delay: int) -> bool:
        try:
            self.ensure_channel_stats_exists(user_id, account_id, channel_id)
            stats = self.load_channel_stats(user_id, account_id, channel_id)
            current_count = stats.get("message_count", 0)
            last_webhook_count = stats.get("last_webhook_count", 0)
            
            if base_delay < 60000:
                if current_count - last_webhook_count >= 20:
                    stats["last_webhook_count"] = current_count
                    self.save_channel_stats(user_id, account_id, channel_id, stats)
                    return True
                return False
            else:
                stats["last_webhook_count"] = current_count
                self.save_channel_stats(user_id, account_id, channel_id, stats)
                return True
        except Exception as e:
            logger.error(f"Error checking webhook condition: {e}")
            return True

    def delete_channel_stats(self, user_id: str, account_id: str, channel_id: str):
        try:
            account_stats = self.load_account_stats(user_id, account_id)
            if channel_id in account_stats:
                del account_stats[channel_id]
                self.save_account_stats(user_id, account_id, account_stats)
        except Exception as e:
            logger.error(f"Error deleting channel stats: {e}")

    def delete_account_stats(self, user_id: str, account_id: str):
        try:
            stats_file = self.get_account_stats_file(user_id, account_id)
            if os.path.exists(stats_file):
                os.remove(stats_file)
        except Exception as e:
            logger.error(f"Error deleting account stats: {e}")

    def delete_channel_from_account(self, account_id: str, channel_id: str, user_id: str) -> bool:
        try:
            account = self.get_account_by_id(account_id, user_id)
            if not account or not account.get("channels"):
                return False
            
            account["channels"] = [ch for ch in account["channels"] if ch.get("id") != channel_id]
            
            self.delete_channel_stats(user_id, account_id, channel_id)
            
            return self.save_account(user_id, account)
        except Exception as e:
            logger.error(f"Error deleting channel from account: {e}")
            return False

    def initialize_users_file(self):
        users_path = os.path.join(self.data_folder, 'users.json')
        if not os.path.exists(users_path):
            initial_users = {
                "users": [{
                    "id": config.owner_id,
                    "username": "Owner",
                    "subscriptionType": "perma_unlimited",
                    "accountLimit": None,
                    "createdAt": get_wib_time().isoformat(),
                    "expiresAt": None,
                    "notes": "Pemilik Bot",
                    "active": True,
                    "addedBy": config.owner_id
                }]
            }
            
            with open(users_path, 'w', encoding='utf-8') as f:
                json.dump(initial_users, f, indent=2)

    async def stop_all_account_services(self, account_id: str, user_id: str):
        try:
            account = self.get_account_by_id(account_id, user_id)
            if not account:
                return False

            channels_stopped = 0
            if account.get("channels"):
                for i, channel in enumerate(account["channels"]):
                    if channel.get("status") == "online":
                        await self.stop_posting(account_id, i)
                        channel["status"] = "offline"
                        channel["stoppedAt"] = get_wib_time().isoformat()
                        channel["errorReason"] = "Manual stop all services"
                        channels_stopped += 1

            self.save_account(user_id, account)
            
            if self.autoreply_handler:
                await self.autoreply_handler.stop_autoreply_client(user_id, account_id)
            
            return True

        except Exception as e:
            logger.error(f"Error stopping all account services: {e}")
            return False

    def migrate_existing_accounts(self):
        try:
            users_path = os.path.join(self.data_folder, 'users.json')
            if not os.path.exists(users_path):
                json_files = [f for f in os.listdir(self.data_folder) if f.endswith('.json') and f not in ['config.json', 'users.json']]
                
                if json_files:
                    owner_folder = os.path.join(self.users_folder, config.owner_id)
                    owner_accounts_folder = os.path.join(owner_folder, 'accounts')
                    
                    os.makedirs(owner_folder, exist_ok=True)
                    os.makedirs(owner_accounts_folder, exist_ok=True)
                    
                    for file in json_files:
                        old_path = os.path.join(self.data_folder, file)
                        new_path = os.path.join(owner_accounts_folder, file)
                        shutil.copy2(old_path, new_path)
                    
                    initial_users = {
                        "users": [{
                            "id": config.owner_id,
                            "username": "Owner",
                            "subscriptionType": "perma_unlimited",
                            "accountLimit": None,
                            "createdAt": get_wib_time().isoformat(),
                            "expiresAt": None,
                            "notes": "Pemilik Bot",
                            "active": True,
                            "addedBy": config.owner_id
                        }]
                    }
                    
                    with open(users_path, 'w', encoding='utf-8') as f:
                        json.dump(initial_users, f, indent=2)
            
            self.migrate_account_stats()
                        
        except Exception as e:
            logger.error(f"Error during migration: {e}")

    def migrate_account_stats(self):
        try:
            users = self.load_users()
            for user in users:
                accounts = self.load_accounts_for_user(user["id"])
                for account in accounts:
                    if account.get("channels"):
                        for channel in account["channels"]:
                            if channel.get("id"):
                                self.ensure_channel_stats_exists(user["id"], account["id"], channel["id"])
        except Exception as e:
            logger.error(f"Error migrating account stats: {e}")

    def load_users(self) -> List[Dict[str, Any]]:
        users_path = os.path.join(self.data_folder, 'users.json')
        try:
            if os.path.exists(users_path):
                with open(users_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('users', [])
        except Exception as e:
            logger.error(f"Error loading users: {e}")
        return []

    def save_users(self, users: List[Dict[str, Any]]) -> bool:
        users_path = os.path.join(self.data_folder, 'users.json')
        try:
            with open(users_path, 'w', encoding='utf-8') as f:
                json.dump({"users": users}, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Error saving users: {e}")
            return False

    def get_user_by_id(self, user_id: str) -> Optional[Dict[str, Any]]:
        try:
            users = self.load_users()
            return next((user for user in users if user["id"] == user_id), None)
        except Exception as e:
            logger.error(f"Error getting user by ID: {e}")
            return None

    def add_user(self, user_data: Dict[str, Any]) -> bool:
        try:
            users = self.load_users()
            if any(user["id"] == user_data["id"] for user in users):
                return False
            
            users.append(user_data)
            return self.save_users(users)
        except Exception as e:
            logger.error(f"Error adding user: {e}")
            return False

    def update_user(self, user_id: str, new_data: Dict[str, Any]) -> bool:
        try:
            users = self.load_users()
            for i, user in enumerate(users):
                if user["id"] == user_id:
                    users[i].update(new_data)
                    return self.save_users(users)
            return False
        except Exception as e:
            logger.error(f"Error updating user: {e}")
            return False

    def delete_user(self, user_id: str) -> bool:
        try:
            users = self.load_users()
            user_index = next((i for i, user in enumerate(users) if user["id"] == user_id), -1)
            
            if user_index == -1:
                return False
            
            user = users[user_index]
            users.pop(user_index)
            
            save_result = self.save_users(users)
            if not save_result:
                logger.error(f"Failed to save users after deleting user {user_id}")
                return False
            
            if self.autoreply_handler:
                self.autoreply_handler.delete_user_autoreply_data(user_id)
            
            user_folder = os.path.join(self.users_folder, user_id)
            if os.path.exists(user_folder):
                try:
                    shutil.rmtree(user_folder)
                except Exception as e:
                    logger.error(f"Error deleting user folder: {e}")
            
            return True
        except Exception as e:
            logger.error(f"Critical error in delete_user for {user_id}: {e}")
            return False

    def has_active_subscription(self, user_id: str) -> bool:
        try:
            if user_id == config.owner_id:
                return True
            
            user = self.get_user_by_id(user_id)
            if not user or not user.get("active"):
                return False
            
            if user["subscriptionType"].startswith("trial_") and user.get("expiresAt"):
                try:
                    expiry_date = datetime.fromisoformat(user["expiresAt"])
                    if expiry_date.tzinfo is None:
                        expiry_date = expiry_date.replace(tzinfo=timezone.utc).astimezone(WIB)
                    elif expiry_date.tzinfo != WIB:
                        expiry_date = expiry_date.astimezone(WIB)
                    
                    current_time = get_wib_time()
                    
                    if expiry_date < current_time:
                        self.update_user(user_id, {
                            "active": False,
                            "deactivatedAt": current_time.isoformat()
                        })
                        return False
                except Exception as e:
                    logger.error(f"Error parsing expiry date for user {user_id}: {e}")
                    return True
            
            return True
        except Exception as e:
            logger.error(f"Error checking subscription: {e}")
            return False

    def can_add_more_accounts(self, user_id: str) -> bool:
        try:
            if user_id == config.owner_id:
                return True
            
            user = self.get_user_by_id(user_id)
            if not user:
                return False
            
            if user["subscriptionType"].endswith("_unlimited"):
                return True
            
            if not user.get("accountLimit"):
                return True
            
            account_count = self.get_account_count_for_user(user_id)
            return account_count < user["accountLimit"]
        except Exception as e:
            logger.error(f"Error checking if user can add more accounts: {e}")
            return False

    def get_account_count_for_user(self, user_id: str) -> int:
        try:
            accounts = self.load_accounts_for_user(user_id)
            return len(accounts)
        except Exception as e:
            logger.error(f"Error getting account count: {e}")
            return 0

    def get_user_data_folder(self, user_id: str) -> str:
        user_folder = os.path.join(self.users_folder, user_id)
        os.makedirs(user_folder, exist_ok=True)
        
        accounts_folder = os.path.join(user_folder, 'accounts')
        os.makedirs(accounts_folder, exist_ok=True)
        
        dm_history_folder = os.path.join(user_folder, 'dm_history')
        os.makedirs(dm_history_folder, exist_ok=True)
        
        return user_folder

    def load_accounts_for_user(self, user_id: str) -> List[Dict[str, Any]]:
        try:
            accounts_folder = os.path.join(self.get_user_data_folder(user_id), 'accounts')
            if not os.path.exists(accounts_folder):
                return []
            
            files = [f for f in os.listdir(accounts_folder) if f.endswith('.json')]
            accounts = []
            
            for file in files:
                file_path = os.path.join(accounts_folder, file)
                with open(file_path, 'r', encoding='utf-8') as f:
                    account = json.load(f)
                    accounts.append(account)
            
            return accounts
        except Exception as e:
            logger.error(f"Error loading accounts for user {user_id}: {e}")
            return []

    def get_accounts(self, user_id: str = None) -> List[Dict[str, Any]]:
        if user_id is None:
            user_id = config.owner_id
        return self.load_accounts_for_user(user_id)

    def get_account_by_id(self, account_id: str, user_id: str = None) -> Optional[Dict[str, Any]]:
        try:
            if user_id is None:
                users = self.load_users()
                for user in users:
                    account = self.get_account_by_id(account_id, user["id"])
                    if account:
                        return account
                return None
            
            accounts_folder = os.path.join(self.get_user_data_folder(user_id), 'accounts')
            file_path = os.path.join(accounts_folder, f"{account_id}.json")
            
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            
            return None
        except Exception as e:
            logger.error(f"Error getting account by ID: {e}")
            return None

    def find_user_by_account_id(self, account_id: str) -> Optional[Dict[str, Any]]:
        try:
            users = self.load_users()
            for user in users:
                accounts = self.load_accounts_for_user(user["id"])
                if any(account["id"] == account_id for account in accounts):
                    return user
            return None
        except Exception as e:
            logger.error(f"Error finding user by account ID: {e}")
            return None

    def save_account(self, user_id: str, account: Dict[str, Any]) -> bool:
        try:
            accounts_folder = os.path.join(self.get_user_data_folder(user_id), 'accounts')
            file_path = os.path.join(accounts_folder, f"{account['id']}.json")
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(account, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Error saving account for user {user_id}: {e}")
            return False

    def add_account(self, user_id: str, account: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            user = self.get_user_by_id(user_id)
            if not user:
                return None
            
            if user["subscriptionType"].find("limited") != -1 and not self.can_add_more_accounts(user_id):
                return None
            
            self.save_account(user_id, account)
            return account
        except Exception as e:
            logger.error(f"Error adding account: {e}")
            return None

    def add_channel(self, account_id: str, channel: Dict[str, Any], user_id: str) -> bool:
        try:
            account = self.get_account_by_id(account_id, user_id)
            if not account:
                return False
            
            if not account.get("channels"):
                account["channels"] = []
            
            account["channels"].append(channel)
            
            if channel.get("id"):
                self.ensure_channel_stats_exists(user_id, account_id, channel["id"])
            
            return self.save_account(user_id, account)
        except Exception as e:
            logger.error(f"Error adding channel: {e}")
            return False

    def delete_account(self, account_id: str, user_id: str) -> bool:
        try:
            self.delete_account_stats(user_id, account_id)
            
            accounts_folder = os.path.join(self.get_user_data_folder(user_id), 'accounts')
            file_path = os.path.join(accounts_folder, f"{account_id}.json")
            
            if os.path.exists(file_path):
                os.remove(file_path)
                
            if self.autoreply_handler:
                self.autoreply_handler.delete_autoreply_data(user_id, account_id)
                
            return True
        except Exception as e:
            logger.error(f"Error deleting account: {e}")
            return False

    def is_token_duplicate(self, token: str, user_id: str = None) -> bool:
        try:
            if user_id:
                accounts = self.load_accounts_for_user(user_id)
                return any(account["token"] == token for account in accounts)
            
            users = self.load_users()
            for user in users:
                accounts = self.load_accounts_for_user(user["id"])
                if any(account["token"] == token for account in accounts):
                    return True
            
            return False
        except Exception as e:
            logger.error(f"Error checking token duplicate: {e}")
            return False

    async def send_message(self, token: str, channel_id: str, message: str, user_id: str, channel: Dict[str, Any]) -> Dict[str, Any]:
        try:
            images = self.get_channel_images(user_id, channel_id)
            
            headers = get_mobile_headers(token)
            timeout = aiohttp.ClientTimeout(
                connect=15.0,
                sock_read=30.0,
                sock_connect=15.0,
                total=45.0
            )
            connector = aiohttp.TCPConnector(
                limit=None,
                limit_per_host=None,
                keepalive_timeout=30.0,
                enable_cleanup_closed=True
            )
            
            if not images:
                async with aiohttp.ClientSession(
                    timeout=timeout, 
                    headers=headers, 
                    connector=connector
                ) as session:
                    
                    nonce = str(get_utc_timestamp_ms() << 22)
                    payload = {
                        "content": message,
                        "nonce": nonce,
                        "tts": False,
                        "flags": 0
                    }
                    
                    async with session.post(
                        f"https://discord.com/api/v10/channels/{channel_id}/messages",
                        json=payload
                    ) as response:
                        if response.status == 200:
                            return {"success": True, "data": await response.json()}
                        else:
                            try:
                                response_data = await response.json()
                            except:
                                response_data = {}
                            return {
                                "success": False,
                                "status": response.status,
                                "data": response_data,
                                "retry_after": response_data.get("retry_after"),
                                "message": response_data.get("message", str(response.status))
                            }
            else:
                form_data = aiohttp.FormData()
                attachments = []
                
                for i, image in enumerate(images):
                    if os.path.exists(image["path"]):
                        file_size = os.path.getsize(image["path"])
                        if file_size > 10 * 1024 * 1024:
                            logger.warning(f"Image too large ({file_size / 1024 / 1024:.2f}MB): {image['filename']}")
                            continue
                        
                        content_type = self.get_content_type(image["filename"])
                        
                        async with aiofiles.open(image["path"], 'rb') as img_file:
                            img_data = await img_file.read()
                            form_data.add_field(f"files[{i}]", 
                                              img_data, 
                                              filename=image["filename"], 
                                              content_type=content_type)
                        
                        attachments.append({
                            "id": i,
                            "filename": image["filename"]
                        })
                
                if not attachments:
                    async with aiohttp.ClientSession(
                        timeout=timeout, 
                        headers=headers, 
                        connector=connector
                    ) as session:
                        nonce = str(get_utc_timestamp_ms() << 22)
                        payload = {
                            "content": message,
                            "nonce": nonce,
                            "tts": False,
                            "flags": 0
                        }
                        
                        async with session.post(
                            f"https://discord.com/api/v10/channels/{channel_id}/messages",
                            json=payload
                        ) as response:
                            if response.status == 200:
                                return {"success": True, "data": await response.json()}
                            else:
                                try:
                                    response_data = await response.json()
                                except:
                                    response_data = {}
                                return {
                                    "success": False,
                                    "status": response.status,
                                    "data": response_data,
                                    "retry_after": response_data.get("retry_after"),
                                    "message": response_data.get("message", str(response.status))
                                }
                
                payload = {
                    "content": message,
                    "nonce": str(get_utc_timestamp_ms() << 22),
                    "tts": False,
                    "flags": 0,
                    "attachments": attachments
                }
                
                form_data.add_field("payload_json", json.dumps(payload))
                
                upload_headers = get_mobile_headers(token)
                if "Content-Type" in upload_headers:
                    del upload_headers["Content-Type"]
                
                async with aiohttp.ClientSession(
                    timeout=timeout, 
                    headers=upload_headers, 
                    connector=connector
                ) as session:
                    
                    async with session.post(
                        f"https://discord.com/api/v10/channels/{channel_id}/messages",
                        data=form_data
                    ) as response:
                        if response.status == 200:
                            return {"success": True, "data": await response.json()}
                        else:
                            try:
                                response_data = await response.json()
                            except:
                                response_data = {}
                            return {
                                "success": False,
                                "status": response.status,
                                "data": response_data,
                                "retry_after": response_data.get("retry_after"),
                                "message": response_data.get("message", str(response.status))
                            }
                
        except aiohttp.ClientError as e:
            return {"success": False, "message": f"Network error: {str(e)}"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def validate_token(self, token: str) -> Dict[str, Any]:
        try:
            headers = get_mobile_headers(token)
            timeout = aiohttp.ClientTimeout(total=10.0)
            connector = aiohttp.TCPConnector(enable_cleanup_closed=True)
            
            async with aiohttp.ClientSession(
                timeout=timeout, 
                headers=headers, 
                connector=connector
            ) as session:
                async with session.get('https://discord.com/api/v10/users/@me') as response:
                    if response.status == 200:
                        return {"success": True, "data": await response.json()}
                    else:
                        return {"success": False, "message": await response.text()}
        except aiohttp.ClientError as e:
            return {"success": False, "message": f"Network error: {str(e)}"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def start_posting(self, account_id: str, channel_index: int, user_id: str):
        try:
            account = self.get_account_by_id(account_id, user_id)
            if not account or not account.get("channels") or channel_index >= len(account["channels"]):
                return False
            
            channel = account["channels"][channel_index]
            if channel.get("status") != "online":
                return False
            
            task_key = f"{account_id}_{channel_index}"
            
            if task_key in self.active_tasks:
                try:
                    if not self.active_tasks[task_key].done():
                        self.active_tasks[task_key].cancel()
                except:
                    pass
                del self.active_tasks[task_key]
            
            task = asyncio.create_task(self._simple_posting_loop(account_id, channel_index, user_id))
            task.add_done_callback(lambda t: self.active_tasks.pop(task_key, None))
            self.active_tasks[task_key] = task
            
            return True
                
        except Exception as e:
            logger.error(f"Error starting posting for {account_id}_{channel_index}: {e}")
            return False

    async def _simple_posting_loop(self, account_id: str, channel_index: int, user_id: str):
        consecutive_failures = 0
        max_failures = 3
        
        try:
            while consecutive_failures < max_failures and not self._shutdown_event.is_set():
                current_account = self.get_account_by_id(account_id, user_id)
                if not current_account or not current_account.get("channels") or channel_index >= len(current_account["channels"]):
                    break
                
                current_channel = current_account["channels"][channel_index]
                if current_channel.get("status") != "online":
                    break
                
                try:
                    result = await self.send_message(
                        current_account["token"],
                        current_channel["id"],
                        current_channel["message"],
                        user_id,
                        current_channel
                    )
                except Exception as e:
                    logger.error(f"Unexpected error sending message for {account_id}_{channel_index}: {e}")
                    break
                
                current_account = self.get_account_by_id(account_id, user_id)
                if not current_account or not current_account.get("channels") or channel_index >= len(current_account["channels"]):
                    break
                
                current_channel = current_account["channels"][channel_index]
                if current_channel.get("status") != "online":
                    break
                
                if result["success"]:
                    consecutive_failures = 0
                    
                    message_count = self.increment_message_count(user_id, account_id, current_channel["id"])
                    
                    try:
                        current_channel["lastMessageTime"] = get_wib_time().isoformat()
                        self.save_account(user_id, current_account)
                        
                        base_delay = current_channel.get("baseDelay", 120000)
                        
                        if self.should_send_webhook(user_id, account_id, current_channel["id"], base_delay):
                            await self.send_webhook_message(current_account, current_channel, 'success', user_id)
                            
                    except Exception as e:
                        logger.error(f"Error updating account data for {account_id}_{channel_index}: {e}")
                    
                else:
                    consecutive_failures += 1
                    status_code = result.get("status", 0)
                    
                    if status_code == 429:
                        retry_after = result.get("retry_after", 60)
                        await asyncio.sleep(retry_after + random.uniform(5, 15))
                        consecutive_failures = max(0, consecutive_failures - 1)
                        continue
                        
                    elif status_code in [401, 403, 404]:
                        await self.stop_and_cleanup_channel(account_id, channel_index, user_id, result.get("message", f"HTTP {status_code}"))
                        
                        try:
                            if status_code == 401:
                                await self.handle_token_expired(account_id, user_id)
                            elif status_code == 403:
                                await self.send_error_notification(current_account, current_channel, result, user_id, "permission")
                            elif status_code == 404:
                                await self.send_error_notification(current_account, current_channel, result, user_id, "not_found")
                        except Exception as e:
                            logger.error(f"Error sending notification for {account_id}_{channel_index}: {e}")
                        break
                        
                    elif status_code == 502:
                        await asyncio.sleep(30)
                        consecutive_failures = max(0, consecutive_failures - 1)
                        continue
                        
                    else:
                        if consecutive_failures >= max_failures:
                            await self.stop_and_cleanup_channel(account_id, channel_index, user_id, "Too many consecutive failures")
                            break
                            
                        await asyncio.sleep(30)
                
                current_account = self.get_account_by_id(account_id, user_id)
                if not current_account or not current_account.get("channels") or channel_index >= len(current_account["channels"]):
                    break
                
                current_channel = current_account["channels"][channel_index]
                if current_channel.get("status") != "online":
                    break
                
                if current_channel.get("status") == "online" and consecutive_failures < max_failures and not self._shutdown_event.is_set():
                    try:
                        delay = self.calculate_delay(current_channel)
                        await asyncio.sleep(delay)
                        
                    except asyncio.CancelledError:
                        return
                    except Exception as e:
                        logger.error(f"Sleep error for {account_id}_{channel_index}: {e}")
                        break
                else:
                    break
            
            if consecutive_failures >= max_failures:
                await self.stop_and_cleanup_channel(account_id, channel_index, user_id, "Too many consecutive failures")
                    
        except asyncio.CancelledError:
            return
        except Exception as e:
            logger.error(f"Unexpected error in posting loop for {account_id}_{channel_index}: {e}")
            await self.stop_and_cleanup_channel(account_id, channel_index, user_id, f"Loop error: {str(e)}")

    async def stop_and_cleanup_channel(self, account_id: str, channel_index: int, user_id: str, reason: str = "Manual stop"):
        try:
            task_key = f"{account_id}_{channel_index}"
            
            account = self.get_account_by_id(account_id, user_id)
            if account and account.get("channels") and channel_index < len(account["channels"]):
                channel = account["channels"][channel_index]
                channel["status"] = "offline"
                channel["stoppedAt"] = get_wib_time().isoformat()
                channel["errorReason"] = reason
                self.save_account(user_id, account)
            
            if task_key in self.active_tasks:
                try:
                    task = self.active_tasks[task_key]
                    if not task.done():
                        task.cancel()
                        try:
                            await asyncio.wait_for(task, timeout=0.5)
                        except (asyncio.TimeoutError, asyncio.CancelledError):
                            pass
                except Exception as e:
                    logger.error(f"Error cancelling task for {task_key}: {e}")
                finally:
                    if task_key in self.active_tasks:
                        del self.active_tasks[task_key]
                
        except Exception as e:
            logger.error(f"Error in stop_and_cleanup_channel for {account_id}_{channel_index}: {e}")

    async def stop_posting(self, account_id: str, channel_index: int):
        try:
            task_key = f"{account_id}_{channel_index}"
            
            if task_key in self.active_tasks:
                try:
                    task = self.active_tasks[task_key]
                    if not task.done():
                        task.cancel()
                except Exception as e:
                    logger.error(f"Error cancelling posting task {task_key}: {e}")
                finally:
                    if task_key in self.active_tasks:
                        del self.active_tasks[task_key]
                
        except Exception as e:
            logger.error(f"Error stopping posting for {account_id}_{channel_index}: {e}")

    def calculate_delay(self, channel: Dict[str, Any]) -> float:
        base_delay = channel.get("baseDelay", 5000)
        additional_delays = channel.get("additionalDelays", [])
        
        if additional_delays:
            chosen_delay = random.choice(additional_delays)
            total_delay = base_delay + chosen_delay
        else:
            total_delay = base_delay
        
        variance = random.uniform(0.8, 1.2)
        jitter = random.uniform(500, 1500)
        
        return max((total_delay * variance + jitter) / 1000, 1.0)

    def generate_id(self) -> str:
        return str(uuid.uuid4()).replace('-', '')[:16]

    def get_uptime(self, account_id: str, channel_index: int, user_id: str = None) -> Optional[str]:
        try:
            if not user_id:
                user = self.find_user_by_account_id(account_id)
                user_id = user["id"] if user else config.owner_id
                
            account = self.get_account_by_id(account_id, user_id)
            if account and account.get("channels") and channel_index < len(account["channels"]):
                channel = account["channels"][channel_index]
                if channel.get("status") == "online" and channel.get("startedAt"):
                    start_time = datetime.fromisoformat(channel["startedAt"])
                    if start_time.tzinfo is None:
                        start_time = start_time.replace(tzinfo=timezone.utc).astimezone(WIB)
                    return calculate_uptime_duration(start_time, get_wib_time())
            return None
        except Exception as e:
            logger.error(f"Error getting uptime: {e}")
            return None

    def update_channel_status(self, account_id: str, channel_index: int, status: str, user_id: str):
        try:
            account = self.get_account_by_id(account_id, user_id)
            if account and account.get("channels") and channel_index < len(account["channels"]):
                current_time_wib = get_wib_time()
                account["channels"][channel_index]["status"] = status
                
                if status == "online":
                    account["channels"][channel_index]["startedAt"] = current_time_wib.isoformat()
                else:
                    account["channels"][channel_index]["stoppedAt"] = current_time_wib.isoformat()
                
                self.save_account(user_id, account)
        except Exception as e:
            logger.error(f"Error updating channel status: {e}")

    def get_user_temp_folder(self, user_id: str) -> str:
        user_folder = self.get_user_data_folder(user_id)
        temp_folder = os.path.join(user_folder, 'temp')
        os.makedirs(temp_folder, exist_ok=True)
        return temp_folder

    def get_channel_temp_folder(self, user_id: str, channel_id: str) -> str:
        temp_folder = self.get_user_temp_folder(user_id)
        channel_temp_folder = os.path.join(temp_folder, channel_id)
        os.makedirs(channel_temp_folder, exist_ok=True)
        return channel_temp_folder

    def clean_filename(self, url: str, channel_id: str, file_index: int) -> str:
        try:
            parsed = urlparse(url)
            original_filename = os.path.basename(parsed.path)
            
            file_extension = ''
            if '.' in original_filename:
                file_extension = '.' + original_filename.split('.')[-1]
            else:
                content_type = url.lower()
                if 'png' in content_type:
                    file_extension = '.png'
                elif 'jpg' in content_type or 'jpeg' in content_type:
                    file_extension = '.jpg'
                elif 'gif' in content_type:
                    file_extension = '.gif'
                elif 'webp' in content_type:
                    file_extension = '.webp'
                else:
                    file_extension = '.jpg'
            
            return f"{channel_id}_{file_index + 1}{file_extension}"
        except Exception:
            return f"{channel_id}_{file_index + 1}.jpg"

    def get_content_type(self, filename: str) -> str:
        content_type, _ = mimetypes.guess_type(filename)
        if not content_type:
            extension = os.path.splitext(filename)[1].lower()
            if extension in ['.jpg', '.jpeg']:
                return 'image/jpeg'
            elif extension == '.png':
                return 'image/png'
            elif extension == '.gif':
                return 'image/gif'
            elif extension == '.webp':
                return 'image/webp'
            else:
                return 'image/jpeg'
        return content_type

    async def download_image(self, url: str, channel_temp_folder: str, channel_id: str, file_index: int) -> Dict[str, str]:
        clean_name = self.clean_filename(url, channel_id, file_index)
        file_path = os.path.join(channel_temp_folder, clean_name)
        
        headers = {
            'User-Agent': MOBILE_USER_AGENT,
            'Accept': 'image/*,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        
        timeout = aiohttp.ClientTimeout(connect=10.0, sock_read=30.0, sock_connect=10.0, total=45.0)
        
        try:
            connector = aiohttp.TCPConnector(
                limit=None,
                limit_per_host=None,
                keepalive_timeout=30.0,
                enable_cleanup_closed=True
            )
            
            async with aiohttp.ClientSession(timeout=timeout, connector=connector) as client:
                async with client.get(url, headers=headers) as response:
                    response.raise_for_status()
                    
                    content_length = response.headers.get('content-length')
                    if content_length and int(content_length) > 10 * 1024 * 1024:
                        logger.warning(f"Image too large ({int(content_length) / 1024 / 1024:.2f}MB): {url}")
                        return None
                    
                    content = await response.read()
                    if len(content) > 10 * 1024 * 1024:
                        logger.warning(f"Image too large ({len(content) / 1024 / 1024:.2f}MB): {url}")
                        return None
                    
                    async with aiofiles.open(file_path, 'wb') as f:
                        await f.write(content)
            
            return {"path": file_path, "filename": clean_name}
        except Exception as e:
            logger.error(f"Error downloading image {url}: {e}")
            return None

    async def download_channel_images(self, user_id: str, channel_id: str, image_urls: List[str]) -> List[Dict[str, str]]:
        if not image_urls:
            return []
        
        channel_temp_folder = self.get_channel_temp_folder(user_id, channel_id)
        
        for existing_file in os.listdir(channel_temp_folder):
            if existing_file.startswith(f"{channel_id}_"):
                try:
                    os.remove(os.path.join(channel_temp_folder, existing_file))
                except:
                    pass
        
        downloaded_files = []
        
        for i, url in enumerate(image_urls):
            try:
                file_info = await self.download_image(url.strip(), channel_temp_folder, channel_id, i)
                if file_info:
                    downloaded_files.append(file_info)
            except Exception as e:
                logger.error(f"Failed to download image {url}: {e}")
        
        return downloaded_files

    def cleanup_channel_images(self, user_id: str, channel_id: str):
        try:
            channel_temp_folder = os.path.join(self.get_user_temp_folder(user_id), channel_id)
            if os.path.exists(channel_temp_folder):
                shutil.rmtree(channel_temp_folder)
        except Exception:
            pass

    def get_channel_images(self, user_id: str, channel_id: str) -> List[Dict[str, str]]:
        try:
            channel_temp_folder = os.path.join(self.get_user_temp_folder(user_id), channel_id)
            if not os.path.exists(channel_temp_folder):
                return []
            
            files = []
            for filename in os.listdir(channel_temp_folder):
                if filename.startswith(f"{channel_id}_"):
                    files.append({"path": os.path.join(channel_temp_folder, filename), "filename": filename})
            
            files.sort(key=lambda x: x["filename"])
            return files
        except Exception:
            return []

    async def send_webhook_with_retry(self, webhook_url: str, payload: Dict[str, Any], retries: int = 3) -> Dict[str, Any]:
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': MOBILE_USER_AGENT
        }
        
        timeout = aiohttp.ClientTimeout(connect=5.0, sock_read=10.0, sock_connect=5.0, total=15.0)
        connector = aiohttp.TCPConnector(
            limit=None,
            limit_per_host=None,
            keepalive_timeout=30.0,
            enable_cleanup_closed=True
        )
        
        for attempt in range(1, retries + 1):
            try:
                async with aiohttp.ClientSession(timeout=timeout, connector=connector) as client:
                    async with client.post(webhook_url, json=payload, headers=headers) as response:
                        if response.status == 200:
                            return {"success": True, "response": response}
                        else:
                            return {"success": False, "status": response.status, "error": await response.text()}
            except aiohttp.ClientError as e:
                if attempt == retries:
                    return {"success": False, "error": f"Network error: {str(e)}"}
                await asyncio.sleep(1)
            except Exception as e:
                if attempt == retries:
                    return {"success": False, "error": str(e)}
                await asyncio.sleep(1)
        
        return {"success": False, "error": "Max retries exceeded"}

    async def send_webhook_message(self, account: Dict[str, Any], channel: Dict[str, Any], status: str, user_id: str):
        try:
            account_id = account["id"]
            message_count = self.get_message_count(user_id, account_id, channel["id"])
            
            channel_index = None
            
            for idx, ch in enumerate(account.get("channels", [])):
                if ch["id"] == channel["id"]:
                    channel_index = idx
                    break
            
            if channel_index is None:
                return
            
            uptime = self.get_uptime(account_id, channel_index, user_id)
            
            current_time_wib = format_wib_time()
            
            user_avatar = None
            user_id_display = "Unknown"
            
            try:
                validation = await self.validate_token(account["token"])
                if validation["success"]:
                    user_data = validation["data"]
                    user_id_display = user_data.get("id", "Unknown")
                    if user_data.get("avatar"):
                        user_avatar = f"https://cdn.discordapp.com/avatars/{user_data['id']}/{user_data['avatar']}.png?size=1024"
            except:
                pass
            
            media_links_text = ""
            if channel.get("imageUrls"):
                media_links = '\n'.join(f"[Link ke Media {i+1}]({url})" for i, url in enumerate(channel["imageUrls"]))
                media_links_text = f"\n\n**🖼️ Link Media:**\n{media_links}"
            
            embed_data = {
                "title": "🤖 Auto Post Success",
                "color": 0x00FF00,
                "description": f"Pesan berhasil dikirim ke channel <#{channel['id']}>",
                "fields": [
                    {
                        "name": "👤 Sender Account",
                        "value": f"**Name:** {account.get('name', 'Unknown')}\n**Username:** {account.get('username', 'Unknown')}\n**User ID:** {user_id_display}",
                        "inline": False
                    },
                    {
                        "name": "📢 Channel Information", 
                        "value": f"**Channel:** <#{channel['id']}>\n**Channel ID:** {channel['id']}\n**Server:** {channel.get('guildName', 'Unknown Server')}",
                        "inline": False
                    },
                    {
                        "name": "⏰ Statistics & Message Info",
                        "value": f"**Messages Sent:** {message_count}\n**Send Time:** {current_time_wib}\n**Channel Uptime:** {uptime or 'Baru dimulai'}\n**Message Content:**\n```{channel['message'][:200] + '...' if len(channel['message']) > 200 else channel['message']}```{media_links_text}",
                        "inline": False
                    }
                ],
                "timestamp": get_wib_time().isoformat()
            }
            
            if user_avatar:
                embed_data["thumbnail"] = {"url": user_avatar}
            
            if config.images.get("successWebhook"):
                embed_data["image"] = {"url": config.images["successWebhook"]}
            
            if not embed_data.get("footer"):
                embed_data["footer"] = {
                    "text": "FuHuu Auto Post",
                    "icon_url": config.images.get("footerIcon")
                }
            elif not embed_data["footer"].get("icon_url") and config.images.get("footerIcon"):
                embed_data["footer"]["icon_url"] = config.images["footerIcon"]
            
            payload = {"embeds": [embed_data]}
            
            user = self.find_user_by_account_id(account_id)
            user_webhook = None
            
            if user and user["id"]:
                user_webhook = self.get_user_webhook(user["id"])
            
            if user_webhook:
                user_webhook_result = await self.send_webhook_with_retry(user_webhook, payload)
                
                if not user_webhook_result["success"]:
                    logger.debug(f"User webhook failed: {user_webhook_result.get('error', 'Unknown error')}")
            else:
                if config.webhook_url:
                    webhook_result = await self.send_webhook_with_retry(config.webhook_url, payload)
                    
                    if not webhook_result["success"]:
                        logger.debug(f"Webhook failed: {webhook_result.get('error', 'Unknown error')}")
                        
        except Exception as e:
            logger.debug(f"Error sending webhook message: {e}")

    async def get_channel_info(self, token: str, channel_id: str) -> Dict[str, Any]:
        try:
            headers = get_mobile_headers(token)
            timeout = aiohttp.ClientTimeout(total=10.0)
            connector = aiohttp.TCPConnector(enable_cleanup_closed=True)
            
            async with aiohttp.ClientSession(
                timeout=timeout, 
                headers=headers, 
                connector=connector
            ) as session:
                async with session.get(f'https://discord.com/api/v10/channels/{channel_id}') as response:
                    if response.status == 200:
                        return {"success": True, "data": await response.json()}
                    else:
                        return {"success": False, "message": await response.text()}
        except aiohttp.ClientError as e:
            return {"success": False, "message": f"Network error: {str(e)}"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def start_posting_immediately(self, account_id: str, channel_index: int, user_id: str):
        try:
            account = self.get_account_by_id(account_id, user_id)
            if not account or not account.get("channels") or channel_index >= len(account["channels"]):
                return False
            
            channel = account["channels"][channel_index]
            
            if channel.get("imageUrls"):
                try:
                    downloaded_files = await self.download_channel_images(user_id, channel["id"], channel["imageUrls"])
                except Exception as e:
                    logger.error(f"Error downloading images for channel {channel['id']}: {e}")
            
            return await self.start_posting(account_id, channel_index, user_id)
            
        except Exception as e:
            logger.error(f"Error in start_posting_immediately: {e}")
            await self.stop_and_cleanup_channel(account_id, channel_index, user_id, f"Unexpected error: {str(e)}")
            return False

    async def send_error_notification(self, account: Dict[str, Any], channel: Dict[str, Any], error_result: Dict[str, Any], user_id: str, error_type: str = "general"):
        try:
            if not self.discord_client or not self.discord_client.is_ready():
                return
            
            status_code = error_result.get("status", 0)
            error_message = error_result.get("message", "Unknown error")
            
            if status_code == 502:
                return
            
            try:
                user_obj = await self.discord_client.fetch_user(int(user_id))
            except:
                return
            
            error_title = "❌ Channel Error"
            error_description = "Terjadi masalah dengan channel anda"
            error_details = ""
            how_to_fix = ""
            
            if status_code == 401:
                error_title = "🔑 Token Expired"
                error_description = "Token Discord anda sudah tidak valid atau expired"
                error_details = f"""HTTP Status: 401 Unauthorized
Error Type: Authentication Failed
Token Status: Invalid or Expired
Raw Message: {error_message}
Timestamp: {format_wib_time()}
Channel ID: {channel['id']}
Account: {account.get('username', 'Unknown')}"""
                
                how_to_fix = "Ganti token ke token yang baru"
            
            elif status_code == 403:
                error_title = "🚫 Permission Denied"
                error_description = "Anda tidak memiliki izin untuk mengirim pesan"
                error_details = f"""HTTP Status: 403 Forbidden
Error Type: Permission Denied
Access Status: No Permission
Raw Message: {error_message}
Timestamp: {format_wib_time()}
Channel ID: {channel['id']}
Server: {channel.get('guildName', 'Unknown Server')}"""
                
                how_to_fix = "Cek apakah masih di server dan minta izin admin"
            
            elif status_code == 404:
                error_title = "🔍 Channel Not Found"
                error_description = "Channel sudah tidak ada lagi"
                error_details = f"""HTTP Status: 404 Not Found
Error Type: Resource Not Found
Channel Status: Not Found
Raw Message: {error_message}
Timestamp: {format_wib_time()}
Channel ID: {channel['id']}
Server: {channel.get('guildName', 'Unknown Server')}"""
                
                how_to_fix = "Hapus channel ini dari daftar anda"
            
            elif status_code == 429:
                error_title = "⏰ Rate Limited"
                error_description = "Discord meminta anda untuk memperlambat pengiriman"
                retry_after = error_result.get("retry_after", 60)
                error_details = f"""HTTP Status: 429 Too Many Requests
Error Type: Rate Limit
Rate Limit: {retry_after} seconds
Raw Message: {error_message}
Timestamp: {format_wib_time()}
Channel ID: {channel['id']}
Server: {channel.get('guildName', 'Unknown Server')}"""
                
                how_to_fix = f"Tunggu {retry_after} detik, channel akan otomatis lanjut"
            
            elif status_code >= 500:
                error_title = "🔧 Discord Server Error"
                error_description = "Server Discord sedang bermasalah"
                error_details = f"""HTTP Status: {status_code} Server Error
Error Type: Discord Server Issue
Server Status: Discord Issue
Raw Message: {error_message}
Timestamp: {format_wib_time()}
Channel ID: {channel['id']}
Server: {channel.get('guildName', 'Unknown Server')}"""
                
                how_to_fix = "Tunggu Discord memperbaiki masalah ini"
            
            else:
                error_details = f"""HTTP Status: {status_code}
Error Type: Unknown Error
System Message: {error_message}
Timestamp: {format_wib_time()}
Channel ID: {channel['id']}
Server: {channel.get('guildName', 'Unknown Server')}
Account: {account.get('username', 'Unknown')}"""
                
                how_to_fix = "Cek koneksi internet dan hubungi support jika masalah berlanjut"
            
            embed_data = {
                "title": error_title,
                "description": error_description,
                "fields": [
                    {
                        "name": "📢 Channel Information",
                        "value": f"**Channel:** <#{channel['id']}>\n**Server:** {channel.get('guildName', 'Unknown Server')}\n**Account:** {account.get('username', 'Unknown')}",
                        "inline": False
                    },
                    {
                        "name": "🔍 Error Details", 
                        "value": f"```{error_details}```",
                        "inline": False
                    },
                    {
                        "name": "🛠️ How To Fix",
                        "value": how_to_fix,
                        "inline": False
                    }
                ],
                "color": 0xFF0000,
                "timestamp": get_wib_time().isoformat()
            }
            enhance_embed(embed_data)
            embed = discord.Embed.from_dict(embed_data)
            
            await user_obj.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error sending error notification: {e}")

    async def handle_token_expired(self, account_id: str, user_id: str):
        try:
            account = self.get_account_by_id(account_id, user_id)
            if not account:
                return
            
            channels_stopped = 0
            if account.get("channels"):
                for i, channel in enumerate(account["channels"]):
                    if channel.get("status") == "online":
                        await self.stop_posting(account_id, i)
                        channel["status"] = "offline"
                        channel["stoppedAt"] = get_wib_time().isoformat()
                        channel["errorReason"] = "Token expired"
                        channels_stopped += 1
            
            if self.autoreply_handler:
                await self.autoreply_handler.stop_autoreply_client(user_id, account_id)
            
            self.save_account(user_id, account)
            
            try:
                user_obj = await self.discord_client.fetch_user(int(user_id))
                embed_data = {
                    "title": "🔑 All Channels Stopped",
                    "description": f"Semua {channels_stopped} channel untuk akun **{account.get('username', 'Unknown')}** telah dihentikan karena token expired.",
                    "fields": [
                        {
                            "name": "📋 What To Do Next",
                            "value": "1. Dapatkan token Discord yang baru\n2. Update pengaturan akun anda\n3. Channel siap untuk restart",
                            "inline": False
                        }
                    ],
                    "color": 0xFFA500,
                    "timestamp": get_wib_time().isoformat()
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await user_obj.send(embed=embed)
            except:
                pass
                
        except Exception as e:
            logger.error(f"Error handling token expired: {e}")

    async def force_stop_all_services(self, hard_stop: bool = False) -> Dict[str, Any]:
        total_stopped = 0
        channels_stopped = 0
        users_processed = 0
        
        try:
            self._shutdown_event.set()
            
            if self.autoreply_handler:
                await self.autoreply_handler.cleanup_all_clients()
            
            tasks_to_cancel = list(self.active_tasks.values())
            if tasks_to_cancel:
                for task in tasks_to_cancel:
                    try:
                        if not task.done():
                            task.cancel()
                    except:
                        pass
                
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*tasks_to_cancel, return_exceptions=True),
                        timeout=1.0
                    )
                except asyncio.TimeoutError:
                    pass
            
            self.active_tasks.clear()
            
            users = self.load_users()
            
            for user in users:
                users_processed += 1
                
                if not self.has_active_subscription(user["id"]) and not hard_stop:
                    continue
                
                accounts_folder = os.path.join(self.get_user_data_folder(user["id"]), 'accounts')
                if not os.path.exists(accounts_folder):
                    continue
                
                files = [f for f in os.listdir(accounts_folder) if f.endswith('.json')]
                
                for file in files:
                    try:
                        file_path = os.path.join(accounts_folder, file)
                        
                        with open(file_path, 'r', encoding='utf-8') as f:
                            account = json.load(f)
                        
                        is_modified = False
                        
                        if account.get("channels"):
                            for channel in account["channels"]:
                                if channel.get("status") == "online":
                                    channel["status"] = "offline"
                                    channel["stoppedAt"] = get_wib_time().isoformat()
                                    channel["stoppedReason"] = 'force_stop'
                                    channels_stopped += 1
                                    total_stopped += 1
                                    is_modified = True
                        
                        if is_modified:
                            with open(file_path, 'w', encoding='utf-8') as f:
                                json.dump(account, f, indent=2)
                    except Exception as e:
                        logger.error(f"Error processing file {file}: {e}")
            
            self._shutdown_event.clear()
            
            return {
                "success": True,
                "totalStopped": total_stopped,
                "channelsStopped": channels_stopped,
                "usersProcessed": users_processed
            }
        except Exception as e:
            logger.error(f"Error stopping all services: {e}")
            return {"success": False, "error": str(e)}

    async def cleanup_expired_trials_efficient(self):
        try:
            current_time = get_wib_time().timestamp()
            
            if current_time - self._last_trial_check < 3600:
                return
            
            self._last_trial_check = current_time
            
            users = self.load_users()
            has_changes = False
            users_to_delete = []
            
            for i, user in enumerate(users):
                if user["subscriptionType"].startswith("trial_") and user.get("expiresAt"):
                    try:
                        expiry_date = datetime.fromisoformat(user["expiresAt"])
                        if expiry_date.tzinfo is None:
                            expiry_date = expiry_date.replace(tzinfo=timezone.utc).astimezone(WIB)
                        elif expiry_date.tzinfo != WIB:
                            expiry_date = expiry_date.astimezone(WIB)
                        
                        current_wib = get_wib_time()
                        time_diff = expiry_date - current_wib
                        days_remaining = time_diff.days
                        
                        if days_remaining <= 0 and user.get("active"):
                            users[i]["active"] = False
                            users[i]["deactivatedAt"] = current_wib.isoformat()
                            has_changes = True
                            
                            await self.stop_all_services_for_user(users[i]["id"])
                            
                            if days_remaining <= -3:
                                users_to_delete.append(users[i]["id"])
                        
                        elif days_remaining <= 3 and days_remaining > 0 and user.get("active"):
                            notification_key = f"3day_{user['id']}"
                            if notification_key not in self._trial_3day_notifications:
                                self._trial_3day_notifications.add(notification_key)
                                await self.send_trial_3day_warning(user, days_remaining)
                                
                    except Exception as e:
                        logger.error(f"Error processing trial user {user.get('id', 'unknown')}: {e}")
                        continue
            
            if users_to_delete:
                for user_id in users_to_delete:
                    await self.auto_delete_expired_user(user_id)
                    users = [u for u in users if u["id"] != user_id]
                    has_changes = True
            
            if has_changes:
                self.save_users(users)
                
        except Exception as e:
            logger.error(f"Error cleaning up expired trials: {e}")

    async def send_trial_3day_warning(self, user: Dict[str, Any], days_remaining: int):
        try:
            if self.discord_client and self.discord_client.is_ready():
                user_obj = await self.discord_client.fetch_user(int(user["id"]))
                embed_data = {
                    "title": "⚠️ Trial Expiring Soon",
                    "description": f"Your trial subscription will expire in **{days_remaining} day(s)**. Please upgrade your subscription to continue using the service.",
                    "fields": [
                        {
                            "name": "📊 Current Plan",
                            "value": user["subscriptionType"],
                            "inline": True
                        },
                        {
                            "name": "⏰ Days Remaining",
                            "value": str(days_remaining),
                            "inline": True
                        },
                        {
                            "name": "🔄 Action Required",
                            "value": "Use `/buy` to upgrade your subscription",
                            "inline": False
                        }
                    ],
                    "color": 0xFFA500,
                    "timestamp": get_wib_time().isoformat()
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await user_obj.send(f"<@{user['id']}> Your trial subscription is expiring soon!", embed=embed)
        except Exception as e:
            logger.error(f"Error sending trial 3-day warning: {e}")

    async def auto_delete_expired_user(self, user_id: str):
        try:
            user = self.get_user_by_id(user_id)
            if not user:
                return
            
            await self.stop_all_services_for_user(user_id)
            
            try:
                discord_user = await self.discord_client.fetch_user(int(user_id))
                notification_embed_data = {
                    "title": "❌ Trial Expired - Account Deleted",
                    "description": f"Your trial subscription has expired and your account data has been automatically removed. Thank you for trying our service!",
                    "color": 0xFF0000,
                    "timestamp": get_wib_time().isoformat()
                }
                notification_embed = discord.Embed.from_dict(enhance_embed(notification_embed_data))
                try:
                    await discord_user.send(f"<@{user_id}> Your trial has expired.", embed=notification_embed)
                except:
                    pass
            except Exception:
                pass
            
            account_count = self.get_account_count_for_user(user_id)
            
            success = self.delete_user(user_id)
            
            if success:
                try:
                    owner = await self.discord_client.fetch_user(int(config.owner_id))
                    owner_embed_data = {
                        "title": "🗑️ Auto-Deleted Expired Trial User",
                        "description": f"User **{user['username']}** has been automatically deleted after trial expiration (3+ days).",
                        "fields": [
                            {"name": "🆔 User ID", "value": user_id, "inline": True},
                            {"name": "📊 Accounts Deleted", "value": str(account_count), "inline": True}
                        ],
                        "color": 0xFF6B6B,
                        "timestamp": get_wib_time().isoformat()
                    }
                    owner_embed = discord.Embed.from_dict(enhance_embed(owner_embed_data))
                    await owner.send(embed=owner_embed)
                except:
                    pass
                    
        except Exception as e:
            logger.error(f"Error auto-deleting expired user {user_id}: {e}")

    async def stop_all_services_for_user(self, user_id: str):
        try:
            accounts = self.load_accounts_for_user(user_id)
            
            for account in accounts:
                account_id = account["id"]
                
                if self.autoreply_handler:
                    await self.autoreply_handler.stop_autoreply_client(user_id, account_id)
                
                if account.get("channels"):
                    for index, channel in enumerate(account["channels"]):
                        if channel.get("status") == "online":
                            await self.stop_posting(account_id, index)
                            channel["status"] = "offline"
                            channel["stoppedAt"] = get_wib_time().isoformat()
                
                self.save_account(user_id, account)
                
        except Exception as e:
            logger.error(f"Error stopping services for user {user_id}: {e}")

    def get_bot_stats(self) -> Optional[Dict[str, Any]]:
        try:
            users = self.load_users()
            total_users = len(users)
            
            active_users = len([user for user in users if user.get("active")])
            trial_users = len([user for user in users if user.get("subscriptionType", "").startswith("trial_") and user.get("active")])
            perma_users = len([user for user in users if user.get("subscriptionType", "").startswith("perma_") and user.get("active")])
            
            total_accounts = 0
            active_channels = 0
            
            for user in users:
                accounts = self.load_accounts_for_user(user["id"])
                total_accounts += len(accounts)
                
                for account in accounts:
                    if account.get("channels"):
                        active_channels += len([ch for ch in account["channels"] if ch.get("status") == "online"])
            
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            
            if hasattr(self, 'start_time'):
                start_time = datetime.fromisoformat(self.start_time)
            else:
                start_time = get_wib_time()
                self.start_time = start_time.isoformat()
            
            if start_time.tzinfo is None:
                start_time = start_time.replace(tzinfo=timezone.utc).astimezone(WIB)
            
            uptime = get_wib_time() - start_time
            
            return {
                "users": {
                    "total": total_users,
                    "active": active_users,
                    "trial": trial_users,
                    "permanent": perma_users
                },
                "services": {
                    "accounts": total_accounts,
                    "activeChannels": active_channels,
                    "activeClients": len(self.active_tasks)
                },
                "system": {
                    "memoryUsage": {
                        "rss": round(memory_info.rss / 1024 / 1024),
                        "vms": round(memory_info.vms / 1024 / 1024),
                    },
                    "uptime": self.format_uptime(int(uptime.total_seconds() * 1000)),
                    "pythonVersion": f"{psutil.sys.version_info.major}.{psutil.sys.version_info.minor}.{psutil.sys.version_info.micro}",
                    "platform": psutil.sys.platform
                }
            }
        except Exception as e:
            logger.error(f'Error getting bot stats: {e}')
            return None

    def format_uptime(self, ms: int) -> str:
        seconds = ms // 1000
        minutes = seconds // 60
        hours = minutes // 60
        days = hours // 24
        
        seconds %= 60
        minutes %= 60
        hours %= 24
        
        result = []
        if days > 0:
            result.append(f"{days} Hari")
        if hours > 0:
            result.append(f"{hours} Jam")
        if minutes > 0:
            result.append(f"{minutes} Menit")
        if seconds > 0 or not result:
            result.append(f"{seconds} Detik")
        
        return ' '.join(result) or '0 Detik'

    def set_user_webhook(self, user_id: str, webhook_url: str) -> bool:
        try:
            users = self.load_users()
            for i, user in enumerate(users):
                if user["id"] == user_id:
                    users[i]["webhookUrl"] = webhook_url
                    return self.save_users(users)
            return False
        except Exception as e:
            logger.error(f"Error setting user webhook: {e}")
            return False

    def get_user_webhook(self, user_id: str) -> Optional[str]:
        try:
            user = self.get_user_by_id(user_id)
            return user.get("webhookUrl") if user else None
        except Exception as e:
            logger.error(f"Error getting user webhook: {e}")
            return None

    async def schedule_daily_backup(self):
        try:
            from commands.backup import create_backup
            
            now = get_wib_time()
            backup_time = now.replace(hour=18, minute=0, second=0, microsecond=0)
            
            if now > backup_time:
                backup_time += timedelta(days=1)
            
            time_until_backup = (backup_time - now).total_seconds()
            
            async def daily_backup_task():
                while not self._shutdown_event.is_set():
                    try:
                        await asyncio.sleep(time_until_backup if 'time_until_backup' in locals() else 24*60*60)
                        
                        if not self._shutdown_event.is_set():
                            try:
                                backup_result = await create_backup()
                                
                                if self.discord_client and self.discord_client.is_ready() and config.owner_id:
                                    try:
                                        owner = await self.discord_client.fetch_user(int(config.owner_id))
                                        if backup_result['success']:
                                            embed_data = {
                                                "title": "✅ Backup Otomatis Berhasil",
                                                "description": f"Backup harian telah dibuat dan disimpan di GitHub Repository\nNama File: {backup_result['filename']}\nUkuran: {backup_result['size']}",
                                                "color": 0x00FF00,
                                                "timestamp": get_wib_time().isoformat()
                                            }
                                            enhance_embed(embed_data)
                                            embed = discord.Embed.from_dict(embed_data)
                                            await owner.send(embed=embed)
                                        else:
                                            embed_data = {
                                                "title": "❌ Backup Otomatis Gagal",
                                                "description": f"Error: {backup_result['error']}",
                                                "color": 0xFF0000,
                                                "timestamp": get_wib_time().isoformat()
                                            }
                                            enhance_embed(embed_data)
                                            embed = discord.Embed.from_dict(embed_data)
                                            await owner.send(embed=embed)
                                    except Exception as notify_error:
                                        logger.error(f"Failed to send backup notification: {notify_error}")
                            except Exception as backup_error:
                                logger.error(f"Error in daily backup: {backup_error}")
                                
                                if self.discord_client and self.discord_client.is_ready() and config.owner_id:
                                    try:
                                        owner = await self.discord_client.fetch_user(int(config.owner_id))
                                        embed_data = {
                                            "title": "❌ Backup Otomatis Gagal",
                                            "description": f"Error: {str(backup_error)}",
                                            "color": 0xFF0000,
                                            "timestamp": get_wib_time().isoformat()
                                        }
                                        enhance_embed(embed_data)
                                        embed = discord.Embed.from_dict(embed_data)
                                        await owner.send(embed=embed)
                                    except Exception as notify_error:
                                        logger.error(f"Failed to send backup error notification: {notify_error}")
                        
                        time_until_backup = 24 * 60 * 60
                        
                    except asyncio.CancelledError:
                        break
                    except Exception as e:
                        logger.error(f"Error in daily backup task: {e}")
                        await asyncio.sleep(60)
            
            backup_task = asyncio.create_task(daily_backup_task())
            
        except Exception as e:
            logger.error(f"Error scheduling daily backup: {e}")

    def start_log_cleaner(self):
        try:
            async def log_cleaner_task():
                while not self._shutdown_event.is_set():
                    try:
                        await asyncio.sleep(3600)
                        if not self._shutdown_event.is_set():
                            clean_log_file()
                    except asyncio.CancelledError:
                        break
                    except Exception as e:
                        logger.error(f"Error in log cleaner task: {e}")
            
            asyncio.create_task(log_cleaner_task())
            
        except Exception as e:
            logger.error(f"Error starting log cleaner: {e}")

    async def init_bot_monitoring(self):
        try:
            if not self.discord_client or not self.discord_client.is_ready():
                return
            
            BOT_LOG_CHANNEL_ID = '1301030606976716831'
            self.bot_log_channel = None
            self.last_status_message = None
            
            try:
                channel = await self.discord_client.fetch_channel(int(BOT_LOG_CHANNEL_ID))
                if channel:
                    self.bot_log_channel = channel
                    
                    try:
                        messages = []
                        async for message in channel.history(limit=10):
                            if message.author.id == self.discord_client.user.id:
                                messages.append(message)
                        
                        for message in messages:
                            try:
                                await message.delete()
                                await asyncio.sleep(0.5)
                            except:
                                pass
                        
                        await self.send_bot_status_update()
                        
                        async def periodic_update():
                            while not self._shutdown_event.is_set():
                                try:
                                    await asyncio.sleep(120)
                                    if not self._shutdown_event.is_set() and self.bot_log_channel:
                                        await self.send_bot_status_update()
                                except asyncio.CancelledError:
                                    break
                                except Exception as e:
                                    await asyncio.sleep(120)
                        
                        task = asyncio.create_task(periodic_update())
                        
                    except discord.Forbidden:
                        self.bot_log_channel = None
            except (discord.Forbidden, discord.NotFound) as e:
                pass
        except Exception as e:
            pass

    async def send_bot_status_update(self):
        if not hasattr(self, 'bot_log_channel') or not self.bot_log_channel:
            return
        
        try:
            stats = self.get_bot_stats()
            if not stats:
                return
            
            system_info = get_system_info()
            
            try:
                network_info = await asyncio.wait_for(get_network_status(), timeout=20.0)
                
                ping_text = "❌ Failed"
                if network_info['ping']['success']:
                    ping_text = f"{network_info['ping']['avg']}ms"
                
                download_text = "❌ Failed"
                if network_info['download']['success']:
                    download_text = f"{network_info['download']['speed']}mbps"
                
                upload_text = "❌ Failed"
                if network_info['upload']['success']:
                    upload_text = f"{network_info['upload']['speed']}mbps"
                    
            except asyncio.TimeoutError:
                ping_text = "Timeout"
                download_text = "Timeout"
                upload_text = "Timeout"
            except Exception as e:
                ping_text = "Error"
                download_text = "Error"
                upload_text = "Error"
            
            embed_data = {
                "title": "Bot Status",
                "color": 0x00FF88,
                "description": "Berikut info lengkap bot",
                "fields": [
                    {
                        "name": "OS",
                        "value": f"**System:** {system_info['system']}\n**RAM Usage:** {system_info['ram_usage']}GB\n**Storage Usage:** {system_info['storage_usage']}GB\n**CPU Usage:** {system_info['cpu_usage']}%",
                        "inline": False
                    },
                    {
                        "name": "User",
                        "value": f"**Perma User:** {stats['users']['permanent']}\n**Trial User:** {stats['users']['trial']}",
                        "inline": False
                    },
                    {
                        "name": "Network",
                        "value": f"**Network Ping:** {ping_text}\n**Upload Speed:** {upload_text}\n**Download Speed:** {download_text}",
                        "inline": False
                    },
                    {
                        "name": "Uptime Info",
                        "value": f"**System Up Time:** {system_info['system_uptime']}\n**Bot Uptime:** {stats['system']['uptime']}",
                        "inline": False
                    }
                ],
                "timestamp": get_wib_time().isoformat(),
                "footer": {
                    "text": "Apostle AutoPost",
                    "icon_url": config.images.get("footerIcon")
                }
            }
            
            if config.images.get("globalEmbed"):
                embed_data["image"] = {"url": config.images["globalEmbed"]}
            
            embed = discord.Embed.from_dict(embed_data)
            
            if self.last_status_message:
                try:
                    await self.last_status_message.edit(embed=embed)
                except (discord.NotFound, discord.HTTPException):
                    self.last_status_message = await self.bot_log_channel.send(embed=embed)
            else:
                self.last_status_message = await self.bot_log_channel.send(embed=embed)
            
        except discord.Forbidden:
            self.bot_log_channel = None
            self.last_status_message = None
        except discord.HTTPException as e:
            pass
        except Exception as e:
            pass

    async def shutdown_bot_monitoring(self):
        try:
            if hasattr(self, 'bot_log_channel') and self.bot_log_channel:
                try:
                    final_embed_data = {
                        "title": "🔴 Bot System Offline",
                        "description": "**Bot is shutting down for maintenance**",
                        "color": 0xFF0000,
                        "fields": [
                            {
                                "name": "System Status",
                                "value": "🔴 Offline\n🔄 Performing shutdown sequence\n⏰ All services stopped",
                                "inline": False
                            }
                        ],
                        "timestamp": get_wib_time().isoformat(),
                        "footer": {
                            "text": "Apostle AutoPost",
                            "icon_url": config.images.get("footerIcon")
                        }
                    }
                    
                    if config.images.get("globalEmbed"):
                        final_embed_data["image"] = {"url": config.images["globalEmbed"]}
                    
                    final_embed = discord.Embed.from_dict(final_embed_data)
                    
                    if self.last_status_message:
                        try:
                            await self.last_status_message.edit(embed=final_embed)
                        except:
                            await self.bot_log_channel.send(embed=final_embed)
                    else:
                        await self.bot_log_channel.send(embed=final_embed)
                    
                except Exception as e:
                    logger.debug(f"Could not send final status update: {e}")
        except Exception as e:
            logger.error(f"Error in shutdown bot monitoring: {e}")
        finally:
            self.bot_log_channel = None
            self.last_status_message = None

    async def update_owner_username(self):
        if self.discord_client and self.discord_client.is_ready():
            owner_user = self.get_user_by_id(config.owner_id)
            if owner_user and not owner_user.get("username"):
                try:
                    owner = await self.discord_client.fetch_user(int(config.owner_id))
                    self.update_user(config.owner_id, {"username": owner.name})
                except Exception as e:
                    logger.error(f"Failed to update owner username: {e}")

    async def perform_daily_backup(self):
        try:
            clean_log_file()
        except Exception as e:
            logger.error(f"Error performing daily backup: {e}")

    async def init_autoreply_handler(self):
        try:
            autoreply_folder = os.path.join(os.path.dirname(__file__), 'autoreply')
            if os.path.exists(autoreply_folder):
                import sys
                sys.path.append(autoreply_folder)
                
                try:
                    from autoreply.autoreplyHandler import AutoReplyHandler
                    self.autoreply_handler = AutoReplyHandler(self)
                    await self.autoreply_handler.start_daily_cleanup_task()
                except ImportError as e:
                    logger.error(f"Failed to import autoreplyHandler: {e}")
                    self.autoreply_handler = None
            else:
                self.autoreply_handler = None
        except Exception as e:
            logger.error(f"Error initializing autoreply handler: {e}")
            self.autoreply_handler = None

    async def cleanup_autoreply_on_shutdown(self):
        try:
            if hasattr(self, 'autoreply_handler') and self.autoreply_handler:
                await self.autoreply_handler.cleanup_all_clients()
        except Exception as e:
            logger.error(f"Error cleaning up autoreply on shutdown: {e}")

    async def cleanup_all_resources(self):
        try:
            self._shutdown_event.set()
            
            await self.shutdown_bot_monitoring()
            
            await self.cleanup_autoreply_on_shutdown()
            
            tasks_to_cancel = list(self.active_tasks.values())
            
            if tasks_to_cancel:
                for task in tasks_to_cancel:
                    try:
                        if not task.done():
                            task.cancel()
                    except:
                        pass
                
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*tasks_to_cancel, return_exceptions=True),
                        timeout=1.0
                    )
                except asyncio.TimeoutError:
                    pass
            
            self.active_tasks.clear()
            
            gc.collect()
            
        except Exception as e:
            logger.error(f"Error during resource cleanup: {e}")

    async def init(self, discord_client):
        self.discord_client = discord_client
        self.start_time = get_wib_time().isoformat()
        
        await self.update_owner_username()
        
        stop_result = await self.force_stop_all_services(hard_stop=True)
        
        await self.init_autoreply_handler()
        
        self.start_log_cleaner()
        
        async def trial_cleanup_loop():
            while not self._shutdown_event.is_set():
                try:
                    await asyncio.wait_for(asyncio.sleep(3600), timeout=3600)
                    if not self._shutdown_event.is_set():
                        await self.cleanup_expired_trials_efficient()
                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error in trial cleanup loop: {e}")
        
        asyncio.create_task(trial_cleanup_loop())
        
        await self.schedule_daily_backup()
        
        await self.init_bot_monitoring()
        
        try:
            if discord_client and discord_client.is_ready() and config.owner_id:
                owner = await discord_client.fetch_user(int(config.owner_id))
                embed_data = {
                    "title": "✅ Bot Successfully Initialized",
                    "description": "All systems have been restarted and are now operational. Previous services have been automatically stopped for safety.",
                    "fields": [
                        {
                            "name": "🔄 Services Reset", 
                            "value": f"Channels stopped: {stop_result.get('channelsStopped', 0)}",
                            "inline": True
                        },
                        {
                            "name": "📊 Monitoring Status",
                            "value": "Bot monitoring initialized\nStatus updates every 2 minutes",
                            "inline": True
                        },
                        {
                            "name": "⚙️ Automated Systems",
                            "value": "✅ Daily backup scheduled\n✅ Trial cleanup active\n✅ Log cleaner running\n✅ Status monitoring active\n✅ AutoReply handler initialized",
                            "inline": False
                        }
                    ],
                    "color": 0x00FF00,
                    "timestamp": get_wib_time().isoformat()
                }
                enhance_embed(embed_data)
                embed = discord.Embed.from_dict(embed_data)
                await owner.send(embed=embed)
        except Exception as e:
            pass

    def is_channel_id_duplicate(self, channel_id: str) -> bool:
        try:
            users = self.load_users()
            for user in users:
                accounts = self.load_accounts_for_user(user["id"])
                
                for account in accounts:
                    if account.get("channels"):
                        if any(channel.get("id") == channel_id for channel in account["channels"]):
                            return True
            return False
        except Exception as e:
            logger.error(f"Error checking channel ID duplicate: {e}")
            return False

    def has_active_channels(self, account_id: str) -> bool:
        account = self.get_account_by_id(account_id)
        if not account or not account.get("channels"):
            return False
        
        return any(channel.get("status") == "online" for channel in account["channels"])

db = Database('data')

async def handle_start_all_with_delays(account_id: str, user_id: str, delays: List[int]):
    try:
        account = db.get_account_by_id(account_id, user_id)
        if not account or not account.get("channels"):
            return {'success': False, 'error': 'No channels found'}
        
        channels_to_start = []
        for i, channel in enumerate(account["channels"]):
            if channel.get("status") != "online":
                task_key = f"{account_id}_{i}"
                if task_key in db.active_tasks:
                    try:
                        if not db.active_tasks[task_key].done():
                            db.active_tasks[task_key].cancel()
                            await asyncio.sleep(0.1)
                    except:
                        pass
                    finally:
                        if task_key in db.active_tasks:
                            del db.active_tasks[task_key]
                
                channel["status"] = "online"
                channel["startedAt"] = get_wib_time().isoformat()
                channels_to_start.append(i)
        
        db.save_account(user_id, account)
        
        if not channels_to_start:
            return {'success': True, 'started': 0}
        
        if not delays or len(delays) == 0:
            delays = [5000]
        
        download_promises = []
        for channel_index in channels_to_start:
            if channel_index < len(account["channels"]):
                channel = account["channels"][channel_index]
                if channel.get("imageUrls"):
                    download_promise = db.download_channel_images(user_id, channel["id"], channel["imageUrls"])
                    download_promises.append(download_promise)
        
        if download_promises:
            try:
                await asyncio.gather(*download_promises, return_exceptions=True)
            except Exception as e:
                logger.error(f"Error downloading media for start all: {e}")
        
        success_count = 0
        
        await db.start_posting(account_id, channels_to_start[0], user_id)
        success_count += 1
        
        cumulative_delay = 0
        for i in range(1, len(channels_to_start)):
            channel_index = channels_to_start[i]
            current_delay = random.choice(delays) / 1000
            cumulative_delay += current_delay
            
            async def start_delayed_channel(ch_index, delay):
                await asyncio.sleep(delay)
                current_account = db.get_account_by_id(account_id, user_id)
                if (current_account and current_account.get("channels") and 
                    ch_index < len(current_account["channels"]) and 
                    current_account["channels"][ch_index].get("status") == "online"):
                    await db.start_posting(account_id, ch_index, user_id)
            
            asyncio.create_task(start_delayed_channel(channel_index, cumulative_delay))
            success_count += 1
        
        return {'success': True, 'started': success_count}
        
    except Exception as e:
        logger.error(f"Error in handle_start_all_with_delays: {e}")
        return {'success': False, 'error': str(e)}

async def force_stop_all_immediately():
    try:
        db._shutdown_event.set()
        
        tasks_to_cancel = list(db.active_tasks.values())
        
        users = db.load_users()
        total_stopped = 0
        
        for user in users:
            accounts_folder = os.path.join(db.get_user_data_folder(user["id"]), 'accounts')
            if not os.path.exists(accounts_folder):
                continue
            
            files = [f for f in os.listdir(accounts_folder) if f.endswith('.json')]
            
            for file in files:
                try:
                    file_path = os.path.join(accounts_folder, file)
                    
                    with open(file_path, 'r', encoding='utf-8') as f:
                        account = json.load(f)
                    
                    is_modified = False
                    
                    if account.get("channels"):
                        for i, channel in enumerate(account["channels"]):
                            if channel.get("status") == "online":
                                channel["status"] = "offline"
                                channel["stoppedAt"] = get_wib_time().isoformat()
                                channel["stoppedReason"] = 'force_stop_immediate'
                                total_stopped += 1
                                is_modified = True
                    
                    if is_modified:
                        with open(file_path, 'w', encoding='utf-8') as f:
                            json.dump(account, f, indent=2)
                            
                except Exception as e:
                    logger.error(f"Error processing file {file}: {e}")
        
        if tasks_to_cancel:
            for task in tasks_to_cancel:
                try:
                    if not task.done():
                        task.cancel()
                except Exception:
                    pass
            
            try:
                await asyncio.wait_for(
                    asyncio.gather(*tasks_to_cancel, return_exceptions=True),
                    timeout=1.0
                )
            except asyncio.TimeoutError:
                pass
        
        db.active_tasks.clear()
        
        db._shutdown_event.clear()
        
        gc.collect()
        
        return {'success': True, 'stopped': total_stopped}
        
    except Exception as e:
        logger.error(f"Error in force_stop_all_immediately: {e}")
        return {'success': False, 'error': str(e)}

async def start_single_channel_immediately(account_id: str, channel_index: int, user_id: str):
    try:
        account = db.get_account_by_id(account_id, user_id)
        if not account or not account.get("channels") or channel_index >= len(account["channels"]):
            return False
        
        task_key = f"{account_id}_{channel_index}"
        if task_key in db.active_tasks:
            try:
                if not db.active_tasks[task_key].done():
                    db.active_tasks[task_key].cancel()
            except:
                pass
            del db.active_tasks[task_key]
        
        channel = account["channels"][channel_index]
        channel["status"] = "online"
        channel["startedAt"] = get_wib_time().isoformat()
        
        db.save_account(user_id, account)
        
        if channel.get("imageUrls"):
            try:
                downloaded_files = await db.download_channel_images(user_id, channel["id"], channel["imageUrls"])
            except Exception as e:
                logger.error(f"Error downloading images for single channel start: {e}")
        
        try:
            return await db.start_posting(account_id, channel_index, user_id)
        except Exception as e:
            logger.error(f"Error starting single channel: {e}")
            await db.stop_and_cleanup_channel(account_id, channel_index, user_id, f"Start error: {str(e)}")
            return False
        
    except Exception as e:
        logger.error(f"Error in start_single_channel_immediately: {e}")
        return False

async def stop_single_channel_immediately(account_id: str, channel_index: int, user_id: str):
    try:
        account = db.get_account_by_id(account_id, user_id)
        if not account or not account.get("channels") or channel_index >= len(account["channels"]):
            return False
        
        task_key = f"{account_id}_{channel_index}"
        
        channel = account["channels"][channel_index]
        channel["status"] = "offline"
        channel["stoppedAt"] = get_wib_time().isoformat()
        channel["errorReason"] = "Manual stop"
        
        db.save_account(user_id, account)
        
        if task_key in db.active_tasks:
            try:
                task = db.active_tasks[task_key]
                if not task.done():
                    task.cancel()
                try:
                    await asyncio.wait_for(task, timeout=0.5)
                except (asyncio.TimeoutError, asyncio.CancelledError):
                    pass
            except Exception as e:
                logger.error(f"Error cancelling single channel task {task_key}: {e}")
            finally:
                if task_key in db.active_tasks:
                    del db.active_tasks[task_key]
        
        return True
        
    except Exception as e:
        logger.error(f"Error in stop_single_channel_immediately: {e}")
        return False

def get_active_channels_count():
    try:
        return len([task for task in db.active_tasks.values() if not task.done()])
    except Exception as e:
        logger.error(f"Error in get_active_channels_count: {e}")
        return 0

def get_total_messages_sent():
    try:
        total = 0
        users = db.load_users()
        for user in users:
            accounts = db.load_accounts_for_user(user["id"])
            for account in accounts:
                account_stats = db.load_account_stats(user["id"], account["id"])
                for channel_id, stats in account_stats.items():
                    total += stats.get("message_count", 0)
        return total
    except Exception as e:
        logger.error(f"Error in get_total_messages_sent: {e}")
        return 0

async def cleanup_inactive_sessions():
    try:
        return True
    except Exception as e:
        logger.error(f"Error cleaning up sessions: {e}")
        return False

async def bulk_update_channel_status(user_id: str, account_id: str, status: str):
    try:
        account = db.get_account_by_id(account_id, user_id)
        if not account or not account.get("channels"):
            return False
        
        current_time = get_wib_time().isoformat()
        modified = False
        
        for i, channel in enumerate(account["channels"]):
            if status == "online" and channel.get("status") != "online":
                channel["status"] = "online"
                channel["startedAt"] = current_time
                modified = True
            elif status == "offline" and channel.get("status") == "online":
                channel["status"] = "offline"
                channel["stoppedAt"] = current_time
                await db.stop_posting(account_id, i)
                modified = True
        
        if modified:
            db.save_account(user_id, account)
        
        return modified
        
    except Exception as e:
        logger.error(f"Error in bulk_update_channel_status: {e}")
        return False

def get_channel_statistics(account_id: str, channel_index: int, user_id: str = None):
    try:
        task_key = f"{account_id}_{channel_index}"
        
        account = db.get_account_by_id(account_id, user_id)
        if not account or not account.get("channels") or channel_index >= len(account["channels"]):
            return {
                'message_count': 0,
                'uptime': None,
                'is_active': False,
                'start_time': None
            }
        
        channel = account["channels"][channel_index]
        if not user_id:
            user = db.find_user_by_account_id(account_id)
            user_id = user["id"] if user else config.owner_id
        
        message_count = db.get_message_count_by_index(user_id, account_id, channel_index)
        uptime = db.get_uptime(account_id, channel_index, user_id)
        is_active = task_key in db.active_tasks and not db.active_tasks[task_key].done()
        
        start_time = None
        if channel.get("startedAt"):
            start_time = datetime.fromisoformat(channel["startedAt"])
        
        return {
            'message_count': message_count,
            'uptime': uptime,
            'is_active': is_active,
            'start_time': start_time
        }
    except Exception as e:
        logger.error(f"Error getting channel statistics: {e}")
        return {
            'message_count': 0,
            'uptime': None,
            'is_active': False,
            'start_time': None
        }

async def test_channel_connectivity(token: str, channel_id: str):
    try:
        result = await db.validate_token(token)
        if not result["success"]:
            return {'success': False, 'error': 'Invalid token'}
        
        channel_info = await db.get_channel_info(token, channel_id)
        if not channel_info["success"]:
            return {'success': False, 'error': 'Cannot access channel'}
        
        test_result = await db.send_message(token, channel_id, "🤖 Test message - Bot connectivity check", "", {})
        
        return {
            'success': test_result["success"],
            'token_valid': True,
            'channel_accessible': True,
            'can_send_messages': test_result["success"]
        }
        
    except Exception as e:
        return {'success': False, 'error': str(e)}

def reset_all_counters():
    try:
        users = db.load_users()
        for user in users:
            stats_folder = db.get_channel_stats_folder(user["id"])
            if os.path.exists(stats_folder):
                for filename in os.listdir(stats_folder):
                    if filename.endswith('_stats.json'):
                        stats_file = os.path.join(stats_folder, filename)
                        account_stats = {}
                        try:
                            with open(stats_file, 'r', encoding='utf-8') as f:
                                current_stats = json.load(f)
                            for channel_id in current_stats.keys():
                                account_stats[channel_id] = {
                                    "message_count": 0,
                                    "last_webhook_count": 0,
                                    "last_updated": get_wib_time().isoformat()
                                }
                            with open(stats_file, 'w', encoding='utf-8') as f:
                                json.dump(account_stats, f, indent=2)
                        except Exception as e:
                            logger.error(f"Error resetting stats file {filename}: {e}")
        return True
    except Exception as e:
        logger.error(f"Error in reset_all_counters: {e}")
        return False

async def emergency_shutdown():
    try:
        db._shutdown_event.set()
        
        tasks_to_cancel = list(db.active_tasks.values())
        if tasks_to_cancel:
            for task in tasks_to_cancel:
                try:
                    task.cancel()
                except:
                    pass
        
        db.active_tasks.clear()
        
        return True
        
    except Exception as e:
        logger.error(f"Error in emergency shutdown: {e}")
        return False

def get_system_performance():
    try:
        import psutil
        
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        
        return {
            'cpu_usage': cpu_percent,
            'memory_usage': memory.percent,
            'memory_available': round(memory.available / (1024**3), 2),
            'active_tasks': len(db.active_tasks),
            'total_messages': get_total_messages_sent(),
            'active_channels': get_active_channels_count()
        }
    except Exception as e:
        logger.error(f"Error getting system performance: {e}")
        return {
            'cpu_usage': 0,
            'memory_usage': 0,
            'memory_available': 0,
            'active_tasks': 0,
            'total_messages': 0,
            'active_channels': 0
        }