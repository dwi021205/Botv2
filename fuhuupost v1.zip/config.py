import json
import os
from typing import Dict, Any

class Config:
    def __init__(self, config_path: str = "config.json"):
        self.config_path = config_path
        self._config = {}
        self._load_config()
    
    def _load_config(self):
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self._config = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Config file '{self.config_path}' not found.")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in config file: {e}")
        except Exception as e:
            raise RuntimeError(f"Failed to load config: {e}")
    
    @property
    def token(self) -> str:
        return self._config.get("token", "")
    
    @property
    def client_id(self) -> str:
        return self._config.get("clientId", "")
    
    @property
    def owner_id(self) -> str:
        return self._config.get("ownerId", "")
    
    @property
    def webhook_url(self) -> str:
        return self._config.get("webhookUrl", "")
    
    @property
    def mode(self) -> str:
        return self._config.get("mode", "app")
    
    @property
    def is_debug(self) -> bool:
        return self.mode.lower() == "debug"
    
    @property
    def github(self) -> Dict[str, Any]:
        return self._config.get("github", {})
    
    @property
    def midtrans(self) -> Dict[str, Any]:
        return self._config.get("midtrans", {})
    
    @property
    def images(self) -> Dict[str, Any]:
        return self._config.get("images", {})
    
    @property
    def rate_limits(self) -> Dict[str, Any]:
        return self._config.get("rate_limits", {
            "min_delay": 5,
            "max_delay": 15,
            "burst_limit": 3,
            "cooldown_multiplier": 2.5,
            "max_retries": 5
        })

config = Config()